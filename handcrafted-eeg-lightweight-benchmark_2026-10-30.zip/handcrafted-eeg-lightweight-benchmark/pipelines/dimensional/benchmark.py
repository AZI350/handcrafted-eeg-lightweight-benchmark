"""Profile representative checkpoints in fresh subprocesses, CPU and optional CUDA."""
import argparse,json,os,subprocess,sys,time,threading
from pathlib import Path
import numpy as np
import torch,psutil
import run_experiment as core

def measure(path,device):
 folder=path.parent;r=json.loads((folder/'metrics.json').read_text())
 parent=next(p for p in folder.parents if (p/'command_config.json').exists())
 cfg=json.loads((parent/'command_config.json').read_text())
 pred=np.load(folder/'test_predictions.npz');subject=str(pred['subject'][0]);trial=pred['trial'][0];window=pred['window'][0]
 with np.load(Path(cfg['data_root'])/r['dataset']/(subject+'.npz')) as z:
  ids=np.flatnonzero(z['quality_ok']&(z['trial_index']==trial)&(z['window_in_trial']==window));assert len(ids)==1
  x=z['eeg_uv'][ids].astype(np.float32)
 with np.load(folder.parents[2]/'normalization.npz') as z:stats={k:z[k] for k in z.files}
 method='baseline' if r['method']=='aux_supervision' else r['method']
 features=tuple(r['feature_set']) if method=='direct_fusion' else ()
 model=core.ExperimentNet(method,x.shape[1],r['feature_dimensions'] if features else 0,r['backbone']).to(device)
 model.load_state_dict(torch.load(path,map_location=device,weights_only=True));model.eval()
 def inputs():
  f=None
  if features:
   values=core.compute_features(x,250,set(features))
   f=torch.from_numpy(np.concatenate([(values[k]-stats[k+'_mean'])/stats[k+'_std'] for k in features],axis=1).astype(np.float32)).to(device)
  tx=torch.from_numpy(((x-stats['eeg_mean'])/stats['eeg_std']).astype(np.float32)).to(device)
  return tx,f
 def sync():
  if device=='cuda':torch.cuda.synchronize()
 tx,f=inputs()
 with torch.no_grad():
  check=model(tx,f)[0].softmax(1)[0,1].item()
  assert abs(check-float(pred['probability'][0]))<1e-4,(check,pred['probability'][0])
  for _ in range(20):model(tx,f)
  sync()
  if device=='cuda':torch.cuda.reset_peak_memory_stats()
  proc=psutil.Process();rss_start=proc.memory_info().rss;rss_peak=[rss_start];stop=threading.Event()
  def monitor():
   while not stop.wait(.002):rss_peak[0]=max(rss_peak[0],proc.memory_info().rss)
  worker=threading.Thread(target=monitor,daemon=True);worker.start()
  model_times=[];full_times=[]
  try:
   for _ in range(100):
    sync();start=time.perf_counter();model(tx,f);sync();model_times.append((time.perf_counter()-start)*1000)
   for _ in range(50):
    sync();start=time.perf_counter();xx,ff=inputs();model(xx,ff);sync();full_times.append((time.perf_counter()-start)*1000)
  finally:stop.set();worker.join()
 result=dict(checkpoint=str(path),dataset=r['dataset'],target=r['target'],protocol=r['protocol'],method=r['method'],
  device=device,device_name=torch.cuda.get_device_name() if device=='cuda' else 'CPU',torch=torch.__version__,threads=4,batch=1,
  parameters=sum(p.numel() for p in model.parameters()),weight_file_bytes=path.stat().st_size,
  model_ms_median=float(np.median(model_times)),model_ms_p95=float(np.percentile(model_times,95)),
  feature_normalize_transfer_model_ms_median=float(np.median(full_times)),feature_normalize_transfer_model_ms_p95=float(np.percentile(full_times,95)),
  process_rss_before_bytes=rss_start,process_rss_sampled_peak_bytes=rss_peak[0],rss_poll_interval_ms=2,
  cuda_peak_allocated_bytes=torch.cuda.max_memory_allocated() if device=='cuda' else None,
  excludes='Disk I/O, upstream filtering/resampling, quality screening, window accumulation; RSS sampling can miss short peaks')
 core.json_dump(folder/f'profile_{device}.json',result)
 print(json.dumps(result),flush=True)

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path);p.add_argument('--checkpoint',type=Path);p.add_argument('--device',choices=['cpu','cuda'],default='cpu');a=p.parse_args()
 torch.set_num_threads(4)
 if a.checkpoint:return measure(a.checkpoint,a.device)
 if a.root is None:p.error('--root required')
 seen=set()
 for path in sorted((a.root/'final').rglob('deploy.pt')):
  name=path.relative_to(a.root/'final').parts[0]
  if not (name.endswith('_selected') or name.endswith('_references')):continue
  r=json.loads((path.parent/'metrics.json').read_text())
  key=(r['dataset'],r['target'],r['protocol'],r['method'])
  if key in seen:continue
  seen.add(key)
  for device in (['cpu','cuda'] if torch.cuda.is_available() else ['cpu']):
   if not (path.parent/f'profile_{device}.json').exists():subprocess.run([sys.executable,str(Path(__file__).resolve()),'--checkpoint',str(path),'--device',device],check=True)

if __name__=='__main__':main()
