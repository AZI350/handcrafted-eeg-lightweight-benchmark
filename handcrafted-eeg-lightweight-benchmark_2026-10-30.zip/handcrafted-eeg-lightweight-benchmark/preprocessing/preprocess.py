"""Offline pilot preprocessing. Originals are read-only; no fitted cross-subject statistics."""
from pathlib import Path
import zipfile,io,json,csv,shutil,tempfile,argparse,traceback
from fractions import Fraction
import numpy as np
from scipy.io import loadmat
from scipy.signal import butter,sosfiltfilt,resample_poly,iirnotch,filtfilt
import mne
mne.set_log_level('ERROR')
ROOT=Path(__file__).parent
OUT=ROOT/'data'
TMP=ROOT/'tmp'
FS=250
SCORES=['Joy','Tenderness','Inspiration','Amusement','Anger','Disgust','Fear','Sadness','Arousal','Valence','Familiarity','Liking']
CHANNELS=['Fp1','Fp2','Fz','F3','F4','F7','F8','FC1','FC2','FC5','FC6','Cz','C3','C4','T7','T8','CP1','CP2','CP5','CP6','Pz','P3','P4','P7','P8','PO3','PO4','Oz','O1','O2']
RENAME={'T3':'T7','T4':'T8','T5':'P7','T6':'P8'}

def extract(z,n,d):
 p=d/Path(n).name
 with z.open(n) as a,p.open('wb') as b:shutil.copyfileobj(a,b,8*1024*1024)
 return p

def process_trial(x,sf):
 assert x.ndim==2 and np.isfinite(x).all()
 if x.shape[1]/sf<30:raise ValueError('trial shorter than 30 seconds')
 # Filter within each video only; never bridge unrelated trials.
 x=sosfiltfilt(butter(4,[1,45],fs=sf,btype='bandpass',output='sos'),x,axis=-1)
 ratio=Fraction(FS/int(sf))
 if sf!=FS:x=resample_poly(x,ratio.numerator,ratio.denominator,axis=-1)
 x=x[:,-7500:]
 x=x-x.mean(axis=0,keepdims=True)
 b,a=iirnotch(50,30,fs=FS)
 x=filtfilt(b,a,x,axis=-1)
 assert x.shape[-1]==7500 and np.isfinite(x).all()
 return x.astype(np.float32)

def save(dataset,subject,trials,labels,meta):
 x=np.stack(trials)
 n,c,t=x.shape
 win=x.reshape(n,c,30,250).transpose(0,2,1,3).reshape(n*30,c,250)
 peak=np.ptp(win,axis=-1).max(axis=-1)
 flat=(np.std(win,axis=-1)<0.1).any(axis=-1)
 good=(peak<=500)&(~flat)
 p=OUT/dataset;p.mkdir(parents=True,exist_ok=True)
 # Only store windows; trial grouping is losslessly retained.
 np.savez(p/(subject+'.npz'),eeg_uv=win,trial_index=np.repeat(np.arange(n),30),window_in_trial=np.tile(np.arange(30),n),quality_ok=good,peak_to_peak_uv=peak,flat_channel_flag=flat,scores=np.array(labels,dtype=np.float32),channel_names=np.array(meta['channels']),sfreq=np.array(FS))
 meta.update(subject=subject,dataset=dataset,trials=n,windows=n*30,shape=list(win.shape),quality_ok_windows=int(good.sum()),quality_flagged_windows=int((~good).sum()),quality_rule='Any channel PTP >500 uV or STD <0.1 uV; flag only, no automatic deletion.',unit='microvolt',notch50_applied=True)
 (p/(subject+'.json')).write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf8')
 check=np.load(p/(subject+'.npz'),allow_pickle=False)
 assert check['eeg_uv'].shape==win.shape and np.isfinite(check['eeg_uv']).all()
 return meta

def faced(z,s,d):
 prefix='Data/'+s+'/'
 bdf=extract(z,prefix+'data.bdf',d);evt=extract(z,prefix+'evt.bdf',d)
 raw=mne.io.read_raw_bdf(bdf,preload=False,verbose='ERROR')
 sf=raw.info['sfreq']; ann=mne.read_annotations(evt)
 names=[RENAME.get(c,c) for c in raw.ch_names]
 picks=[names.index(c) for c in CHANNELS]
 # MNE converts physical dimensions from BDF headers to volts. Record scale checks.
 probe=raw.get_data(picks=picks,start=0,stop=int(sf*10))
 scale=1e6 if np.mean(np.abs(probe))<1 else 1.0
 remarks=loadmat(io.BytesIO(z.read(prefix+'After_remarks.mat')),simplify_cells=True)['After_remark']
 scores={int(v['vid']):v for v in remarks}
 segments=[];pending=None; start=None
 for onset,desc in zip(ann.onset,ann.description):
  try:code=int(desc)
  except ValueError:continue
  if 1<=code<=28:pending=code;start=None
  elif code==101 and pending is not None:start=float(onset)
  elif code==102 and pending is not None and start is not None:
   segments.append((pending,start,float(onset)));pending=None;start=None
 assert len(segments)==28 and {a[0] for a in segments}==set(scores), 'video/event mismatch'
 assert [a[0] for a in segments]==[int(v['vid']) for v in remarks], 'presentation/rating order mismatch'
 trials=[]; labels=[]; info=[]
 for vid,start,end in sorted(segments):
  lo=int(round(start*sf));hi=int(round(end*sf))
  assert 0<=lo<hi<=raw.n_times
  # Last 35 seconds supplies 5 seconds of preceding context for the filter.
  lo=max(lo,hi-int(35*sf))
  x=raw.get_data(picks=picks,start=lo,stop=hi)*scale
  trials.append(process_trial(x,sf));labels.append(scores[vid]['score'])
  info.append(dict(video_id=vid,presentation_trial=int(scores[vid]['trial']),video_start_s=start,video_end_s=end,retained_start_s=end-30))
 raw.close()
 return save('FACED',s,trials,labels,dict(channels=CHANNELS,score_columns=SCORES,source_sfreq=sf,mne_to_uv_multiplier=scale,probe_abs_mean=float(np.abs(probe).mean()),video_info=info,source_archive=Path(z.filename).name,unit_policy='MNE BDF units; official FACED mean-amplitude heuristic (<1 => V to uV) recorded for review.'))

def dens(z,s,d):
 names=z.namelist(); sub=[n for n in names if n.startswith(s+'/')]
 sets=[n for n in sub if n.endswith('.set')];behs=[n for n in sub if n.endswith('_beh.tsv')]
 reasons=[]
 if not sets:reasons.append('missing SET/FDT EEG')
 if not behs:reasons.append('missing behavioral ratings')
 if not sets:raise ValueError('; '.join(reasons))
 e=loadmat(io.BytesIO(z.read(sets[0])),simplify_cells=True);e=e.get('EEG',e)
 data=sets[0].rsplit('/',1)[0]+'/'+str(e['data'])
 expected=int(e['nbchan'])*int(e['pnts'])*int(e['trials'])*4
 actual=z.getinfo(data).file_size if data in names else None
 if actual!=expected:reasons.append(f'FDT byte mismatch: expected {expected}, actual {actual}')
 if reasons:raise ValueError('; '.join(reasons))
 rows=list(csv.DictReader(io.StringIO(z.read(behs[0]).decode()),delimiter='\t'))
 locs=e['chanlocs'];channels=[x['labels'] for x in locs]
 target=['E'+str(i) for i in range(1,129)]
 picks=[channels.index(x) for x in target]
 events=e['event'];segments=[];pending=None
 for event in events:
  if event.get('type')=='stm':pending=event
  elif event.get('type')=='vlnc' and pending is not None:
   segments.append((pending,event));pending=None
 assert len(segments)==len(rows),'rating/event count mismatch'
 f=extract(z,data,d);mm=np.memmap(f,dtype='<f4',mode='r',shape=(int(e['nbchan']),int(e['pnts'])),order='F')
 sf=float(e['srate']);trials=[];labels=[];info=[]
 cols=['valence','arousal','dominance','liking','familiarity','relevance']
 for idx,((beg,end),row) in enumerate(zip(segments,rows)):
  # SET latency is 1-based samples. TSV onset in this release reproduces latency, not seconds.
  stim=str(beg['label']).rsplit('_',1)[0]
  assert stim==Path(row['stimuliName']).stem, 'stimulus identity mismatch'
  lo=int(round(float(beg['latency'])))-1;hi=int(round(float(end['latency'])))-1
  assert 0<=lo<hi<=mm.shape[1]
  lo=max(lo,hi-int(35*sf))
  x=np.asarray(mm[picks,lo:hi],dtype=np.float64)
  trials.append(process_trial(x,sf));labels.append([float(row[c]) for c in cols])
  info.append(dict(video_id=row['stimuliName'],presentation_trial=idx+1,video_start_s=(float(beg['latency'])-1)/sf,video_end_s=(float(end['latency'])-1)/sf,retained_start_s=(hi-7500)/sf))
 del mm
 return save('DENS',s,trials,labels,dict(channels=target,score_columns=cols,source_sfreq=sf,video_info=info,source_archive='E:/数据集/v1.0.0.zip',unit_policy='EEGLAB FDT standard microvolt values; retain E1-E128; discard reference/ECG/EMG channels.',timing_policy='SET latency (1-based samples), matched to behavioral stimulus name.'))

def main():
 global OUT,TMP
 ap=argparse.ArgumentParser();ap.add_argument('--limit',type=int);ap.add_argument('--dataset',choices=['FACED'],default='FACED')
 ap.add_argument('--archive',type=Path,required=True,help='Licensed FACED Data.zip')
 ap.add_argument('--output-root',type=Path,required=True,help='Receives FACED/*.npz')
 args=ap.parse_args();OUT=args.output_root;TMP=OUT.parent/'scratch'
 OUT.mkdir(parents=True,exist_ok=True);TMP.mkdir(exist_ok=True)
 config=dict(version='baseline_v1_notch50',filter='4th order Butterworth 1-45Hz SOS zero-phase per video; final up to35s context then last30s',notch='50Hz Q=30 zero-phase, per retained 30-second trial after reference',sfreq=250,reference='mean of retained scalp channels',window_s=1,overlap=0,ica=False,interpolation=False,normalization=False,offline_only=True)
 (OUT.parent/'preprocessing_config.json').write_text(json.dumps(config,indent=2),encoding='utf8')
 result=[]
 for dataset,archive,func in [('FACED',args.archive,faced)]:
  with zipfile.ZipFile(archive) as z:
   ids=sorted({n.split('/')[1] for n in z.namelist() if n.startswith('Data/sub')})
   for s in ids[:args.limit]:
    try:
     existing=OUT/dataset/(s+'.json')
     if existing.exists():meta=json.loads(existing.read_text(encoding='utf8'))
     else:
      with tempfile.TemporaryDirectory(prefix=dataset+'_'+s+'_',dir=TMP) as td:meta=func(z,s,Path(td))
     row=dict(dataset=dataset,subject=s,status='ok',trials=meta['trials'],windows=meta['windows'],quality_ok_windows=meta['quality_ok_windows'])
    except Exception as ex:
     row=dict(dataset=dataset,subject=s,status='excluded',reason=str(ex));traceback.print_exc()
    result.append(row); print(json.dumps(row,ensure_ascii=False),flush=True)
    (OUT.parent/('manifest_'+dataset+'.json')).write_text(json.dumps([r for r in result if r['dataset']==dataset],ensure_ascii=False,indent=2),encoding='utf8')
 print('FINISHED',flush=True)

if __name__=='__main__':main()
