"""Saved-model efficiency/visualization and test-only perturbation evaluation."""
import argparse,hashlib,json,time
from pathlib import Path
import numpy as np
import torch
import cloud
from cloud import engine

def read(p):return json.loads(p.read_text())
def load_run(checkpoint):
    folder=checkpoint.parent;d=read(folder/'metrics.json')
    parent=next(p for p in folder.parents if (p/'command_config.json').exists())
    cfg=read(parent/'command_config.json');cloud.configure(d['dataset'])
    splitfile='subject_splits.json' if d['protocol']=='subject_independent' else 'trial_splits.json'
    selections=read(next(parent.rglob(splitfile)))[d['fold']-1]['test']
    adapter=cloud.Adapter(d['dataset'],Path(cfg['data_root']),'emotion',None,cfg.get('channel_mode','all'))
    raw=engine.load_split(adapter,selections,set(),parent/'unused','test')
    fold=folder.parents[2]
    with np.load(fold/'normalization.npz') as z:stats={k:z[k] for k in z.files}
    method='baseline' if d['method']=='aux_supervision' else d['method']
    features=tuple(d['feature_set']) if method in ['direct_fusion','feature_only'] else ()
    model=cloud.Model(method,raw['x'].shape[1],d['feature_dimensions'] if features else 0,cfg['backbone']).cuda()
    model.load_state_dict(torch.load(checkpoint,map_location='cuda',weights_only=True));model.eval()
    return d,cfg,raw,stats,features,model

def normalize_test(x,raw,stats,features):
    if features:
        fs=engine.compute_features(x,250,set(features))
        f=np.concatenate([(fs[k]-stats[k+'_mean'])/stats[k+'_std'] for k in features],axis=1).astype(np.float32)
        f=torch.from_numpy(f)
    else:f=None
    test={'x':torch.from_numpy(((x-stats['eeg_mean'])/stats['eeg_std']).astype(np.float32)),
          'y_cpu':raw['y'],'subject':raw['subject'],'trial':raw['trial']}
    return test,f

def perturb(x,condition,seed):
    rng=np.random.default_rng(seed);z=x.copy()
    if condition.startswith('snr'):
        snr=int(condition[3:])
        for start in range(0,len(z),256):
            block=z[start:start+256];n=rng.normal(size=block.shape).astype(np.float32);n-=n.mean(-1,keepdims=True)
            power=np.mean(block.astype(np.float64)**2,axis=-1,keepdims=True)
            npower=np.mean(n.astype(np.float64)**2,axis=-1,keepdims=True)
            block+=(n*np.sqrt(power/(10**(snr/10)*np.maximum(npower,1e-20)))).astype(np.float32)
    elif condition.startswith('drop'):
        n=max(1,round(z.shape[1]*int(condition[4:])/100));z[:,rng.choice(z.shape[1],n,replace=False),:]=0
    elif condition!='clean':raise ValueError(condition)
    return z

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--mode',choices=['profile','robustness'],required=True)
    p.add_argument('--limit',type=int,default=0);p.add_argument('--threads',type=int,default=4)
    a=p.parse_args();torch.set_num_threads(a.threads);seen=set();done=0
    for checkpoint in sorted(a.root.rglob('deploy.pt')):
        d0=read(checkpoint.parent/'metrics.json')
        if a.mode=='robustness' and not (d0['method']=='baseline' or (d0['method']=='direct_fusion' and d0['feature_set']==['dtcwt_energy'])):continue
        key=(d0['dataset'],d0['protocol'],d0['backbone'],d0.get('channel_mode','all'),d0['method'],tuple(d0['feature_set']))
        if a.mode=='profile':
            if key in seen:continue
            seen.add(key)
            if (checkpoint.parent/'profile.json').exists():continue
        print('POSTPROCESS',checkpoint,flush=True)
        d,cfg,raw,stats,features,model=load_run(checkpoint)
        if a.mode=='robustness':
            for condition in ['clean','snr20','snr10','snr0','drop25','drop50']:
                for repeat in ([0] if condition=='clean' else [101,307,509]):
                    output=checkpoint.parent/'robustness'/f'{condition}_{repeat}.json'
                    if output.exists():continue
                    identity=f"{d['dataset']}/{d['protocol']}/{d['fold']}/{repeat}"
                    seed=int.from_bytes(hashlib.sha256(identity.encode()).digest()[:8],'little')
                    x=perturb(raw['x'],condition,seed);test,f=normalize_test(x,raw,stats,features)
                    metrics,pr,prob=cloud.evaluate(model,test,f)
                    if condition=='clean':
                        with np.load(checkpoint.parent/'test_predictions.npz') as saved:
                            assert np.array_equal(saved['y'],raw['y']) and np.array_equal(saved['trial'],raw['trial']) and np.array_equal(saved['subject'],raw['subject'])
                            assert np.allclose(saved['probability'],prob,atol=1e-5,rtol=1e-5)
                    engine.json_dump(output,{'condition':condition,'repeat':repeat,'effective_seed':seed,'test':metrics})
                    print('SAVED',output,flush=True)
                    del test,f,x
        else:
            import matplotlib
            matplotlib.use('Agg')
            import matplotlib.pyplot as plt
            import psutil
            from sklearn.manifold import TSNE
            x=raw['x'][:1];dummy={k:v[:1] for k,v in raw.items()}
            test,f=normalize_test(x,dummy,stats,features);tx=test['x'].cuda();tf=None if f is None else f.cuda()
            with torch.no_grad():
                for _ in range(20):model(tx,tf)
                torch.cuda.synchronize();torch.cuda.reset_peak_memory_stats();times=[]
                for _ in range(100):
                    start=time.perf_counter();model(tx,tf);torch.cuda.synchronize();times.append((time.perf_counter()-start)*1000)
                total=[]
                for _ in range(20):
                    start=time.perf_counter();ts,fs=normalize_test(x,dummy,stats,features)
                    model(ts['x'].cuda(),None if fs is None else fs.cuda());torch.cuda.synchronize();total.append((time.perf_counter()-start)*1000)
            engine.json_dump(checkpoint.parent/'profile.json',{'device':torch.cuda.get_device_name(),'torch':torch.__version__,'batch':1,'threads':a.threads,
                             'model_latency_ms_median':float(np.median(times)),'feature_normalize_transfer_model_ms_median':float(np.median(total)),
                             'excludes':'raw loading, filtering/resampling, quality detection and window buffering',
                             'gpu_peak_allocated_bytes':torch.cuda.max_memory_allocated(),'process_rss_snapshot_bytes':psutil.Process().memory_info().rss,
                             'weight_file_bytes':checkpoint.stat().st_size,'deployment_parameters':d['deployment_parameters']})
            cm=np.array(d['test']['trial']['overall']['confusion_matrix']);fig,ax=plt.subplots();im=ax.imshow(cm,cmap='Blues');fig.colorbar(im,ax=ax)
            ax.set(xlabel='Predicted class',ylabel='True class',title=f"{d['dataset']} trial confusion; fold {d['fold']} seed {d['seed']}")
            for i in range(len(cm)):
                for j in range(len(cm)):ax.text(j,i,str(cm[i,j]),ha='center',va='center')
            fig.savefig(checkpoint.parent/'confusion_matrix.png',dpi=160,bbox_inches='tight');plt.close(fig)
            ix=np.random.default_rng(20261020).choice(len(raw['x']),min(500,len(raw['x'])),replace=False)
            sub={k:v[ix] for k,v in raw.items()};ts,fs=normalize_test(sub['x'],sub,stats,features)
            with torch.no_grad():emb=model.encode(ts['x'].cuda(),None if fs is None else fs.cuda()).cpu().numpy()
            if len(ix)>5:
                pts=TSNE(n_components=2,random_state=20261020,perplexity=min(30,len(ix)-1),init='pca').fit_transform(emb)
                fig,ax=plt.subplots();ax.scatter(pts[:,0],pts[:,1],c=sub['y'],s=8,cmap='tab10');ax.set(title='Test-window t-SNE (illustrative; not significance evidence)')
                fig.savefig(checkpoint.parent/'tsne.png',dpi=160,bbox_inches='tight');plt.close(fig)
        del model,raw;done+=1
        if a.limit and done>=a.limit:break
    print('POSTPROCESS COMPLETE',done,flush=True)

if __name__=='__main__':main()
