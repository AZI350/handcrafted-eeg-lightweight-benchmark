import csv,json,collections
from pathlib import Path
import numpy as np
T975_DF4 = 2.7764451051977987
ROOT=Path('E:/EEG实验/SEED系列本机七项实验_2026-10-21/results/formal')
HERE=Path(__file__).resolve().parent
rows=list(csv.DictReader((ROOT/'all_runs.csv').open(encoding='utf-8')))
groups=collections.defaultdict(dict)
for r in rows:
 k=(r['run'],r['dataset'],r['protocol'],r['method'],r['features']);ident=(int(r['seed']),int(r['fold']))
 assert ident not in groups[k]
 groups[k][ident]=float(r['macro_f1'])*100
expected={(s,f) for s in [60013,70001,80021,90001,100003] for f in range(1,6)}
for k,g in groups.items():assert set(g)==expected,k
assert len(rows)==6300
def ref(ds,pr,method,features):return groups[(f'e1_main_{ds}_{pr}',ds,pr,method,features)]
def stats(g,reference):
 seeds=sorted({s for s,f in g});v=np.array([np.mean([g[s,f]-reference[s,f] for f in range(1,6)]) for s in seeds])
 half=float(T975_DF4*v.std(ddof=1)/np.sqrt(5))
 return dict(f1=float(np.mean(list(g.values()))),delta=float(v.mean()),ci=[float(v.mean()-half),float(v.mean()+half)])
out=[];lines=['# SEED 系列七项实验完整分析（2026-10-24）','','训练6300/6300；每配置核对五折五种子均完整，无重复。下表为试次Macro-F1百分比及配对差值（百分点）。种子内先平均五折；95%区间采用自由度4的t区间，仅反映固定划分的训练随机性。多重比较未经校正。测试集最高均值是探索性观察，不是验证集选优。','']
for exp in range(1,8):
 lines += [f'## 实验{exp}','','| 数据集 | 协议 | 配置 | 方法 | 特征 | F1 | 参考组 | 差值及95%区间 |','|---|---|---|---|---|---:|---|---|']
 for k,g in sorted(groups.items()):
  run,ds,pr,m,feat=k
  if not run.startswith(f'e{exp}_'):continue
  rm='baseline' if exp==1 else m
  rf='' if rm=='baseline' else 'dtcwt_energy'
  reference=ref(ds,pr,rm,rf);s=stats(g,reference)
  label=run.removeprefix(f'e{exp}_').removesuffix(f'_{ds}_{pr}')
  row=dict(exp=exp,dataset=ds,protocol=pr,config=label,method=m,features=feat,reference=rm+'/'+rf,**s);out.append(row)
  lo,hi=s['ci'];lines.append(f'| {ds} | {pr} | {label} | {m} | {feat} | {s["f1"]:.2f} | {rm}/{rf} | {s["delta"]:+.2f} [{lo:+.2f},{hi:+.2f}] |')
profiles=[];noise=collections.defaultdict(list);nnoise=0
for p in ROOT.rglob('profile.json'):
 d=json.loads((p.parent/'metrics.json').read_text(encoding='utf-8'));v=json.loads(p.read_text(encoding='utf-8'))
 profiles.append(dict(dataset=d['dataset'],protocol=d['protocol'],method=d['method'],features=d['feature_set'],backbone=d['backbone'],experiment=p.relative_to(ROOT).parts[0],**v))
for folder in (ROOT/'exp1').rglob('robustness'):
 d=json.loads((folder.parent/'metrics.json').read_text(encoding='utf-8'))
 for p in folder.glob('*.json'):
  v=json.loads(p.read_text());nnoise+=1
  noise[(d['dataset'],d['protocol'],d['method'],v['condition'])].append(v['test']['trial']['overall']['macro_f1']*100)
assert nnoise==4800,nnoise
lines+=['','## 扰动评价','','300模型×16条件/重复，共4800条。clean每模型一次，其余每条件三次，按条件分别平均；不将重复噪声当作独立受试者。噪声在滤波后添加，通道缺失用原始微伏置零，手工特征重新计算。','','| 数据集 | 协议 | 方法 | 条件 | F1 |','|---|---|---|---|---:|']
for k,v in sorted(noise.items()):lines.append('| '+' | '.join(k)+f' | {np.mean(v):.2f} |')
lines+=['','## 部署测量边界','',f'代表模型测量 {len(profiles)} 份；混淆矩阵 {len(list(ROOT.rglob("confusion_matrix.png")))} 张；t-SNE {len(list(ROOT.rglob("tsne.png")))} 张。','模型及特征处理延迟不含磁盘读取、滤波和窗口积累；GPU allocated峰值不是全部显存；CPU RSS为快照不是峰值。没有FLOPs/MACs。模型对比不是各骨干穷尽调参后的最优性能。','']
(HERE/'七项实验完整分析_2026-10-24.md').write_text('\n'.join(lines),encoding='utf-8')
(HERE/'complete_analysis.json').write_text(json.dumps(dict(rows=out,profiles=profiles,noise=[dict(dataset=k[0],protocol=k[1],method=k[2],condition=k[3],f1=float(np.mean(v))) for k,v in noise.items()],counts=dict(training=6300,noise=nnoise,profiles=len(profiles))),ensure_ascii=False,indent=2),encoding='utf-8')
for ds in ['SEED','SEED_IV','SEED_V']:
 for pr in ['subject_dependent','subject_independent']:
  print('\n',ds,pr)
  for exp in range(2,8):
   items=[r for r in out if r['exp']==exp and r['dataset']==ds and r['protocol']==pr and r['method']==('aux_supervision' if exp==4 else 'direct_fusion')]
   for r in (items if exp in [2,6,7] else [max(items,key=lambda x:x['f1'])]):print(json.dumps(r))
print('counts',6300,nnoise,len(profiles))
