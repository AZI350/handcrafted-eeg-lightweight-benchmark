"""CPU synthetic integration test; does not start a real-data experiment."""
import argparse,json,subprocess,sys,tempfile
from pathlib import Path
import numpy as np
import torch
import staged
core=staged.core

def child(case):
 torch.set_num_threads(1)
 torch.Tensor.cuda=lambda self,*a,**k:self
 torch.nn.Module.cuda=lambda self,*a,**k:self
 original_tensor=torch.tensor
 def tensor(*a,**k):
  if k.get('device')=='cuda':k['device']='cpu'
  return original_tensor(*a,**k)
 torch.tensor=tensor
 with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent,prefix='selftest_') as td:
  folder=Path(td)/'run';arrays={}
  rng=np.random.default_rng(1)
  for split in ['train','val','test']:
   x=rng.normal(size=(12,4,250)).astype(np.float32);y=np.tile([0,0,1,1],3)
   arrays[split]=dict(x=torch.from_numpy(x),y=torch.from_numpy(y),y_cpu=y,subject=np.repeat(['a','b','c'],4),trial=np.tile([0,0,1,1],3),window=np.tile([0,1],6),hjorth=torch.from_numpy(rng.normal(size=(12,12)).astype(np.float32)))
  def fake_main():
   args=core.build_parser().parse_args([]);args.max_epochs=2;args.batch_size=4;args.selection_metric='trial_macro_f1';args.learning_rate=.001;args.patience=1
   result=core.train_run(args,{'dataset':'DREAMER','target':'valence','channels':4},1,'aux_supervision',('hjorth',),17,arrays,folder)
   assert result['epochs_run']==2
   if case!='reference':assert result['stage1_updates']==6 and result['stage2_updates']==6
   if case=='validation':assert result['validation_only'] and 'test' not in result and not (folder/'test_predictions.npz').exists()
   else:
    assert (folder/'deploy.pt').exists()
    model=core.ExperimentNet('baseline',4,0)
    model.load_state_dict(torch.load(folder/'deploy.pt',weights_only=True))
    with torch.no_grad():assert torch.isfinite(model(arrays['test']['x'])[0]).all()
  core.main=fake_main
  sys.argv=['staged.py','--pretrain-epochs','2','--freeze-epochs','1']
  if case=='classification':sys.argv+=['--stage1-objective','classification']
  if case=='validation':sys.argv+=['--validation-only']
  staged.main()
 print('PASS',case)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--case');a=p.parse_args()
 if a.case:child(a.case)
 else:
  for case in ['features','classification','validation']:subprocess.run([sys.executable,__file__,'--case',case],check=True)
  print('PASS: fixed budgets, freeze/unfreeze, deployment restoration, validation-only selection')
