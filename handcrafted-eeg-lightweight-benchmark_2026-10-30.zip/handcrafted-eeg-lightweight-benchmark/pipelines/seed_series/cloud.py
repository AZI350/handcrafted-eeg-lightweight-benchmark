"""Multiclass SEED adapter around the archived experimental trainer."""
import sys
from pathlib import Path
import numpy as np
import torch
from torch import nn
from sklearn.metrics import confusion_matrix, accuracy_score, f1_score, roc_auc_score, matthews_corrcoef, cohen_kappa_score, average_precision_score
import run_experiment as engine

CLASSES={'SEED':['negative','neutral','positive'], 'SEED_IV':['neutral','sad','fear','happy'], 'SEED_V':['disgust','fear','sad','neutral','happy']}
K=3
BaseAdapter=engine.DatasetAdapter
BaseModel=engine.ExperimentNet

class Adapter(BaseAdapter):
    def load_subject(self,path,selected_features,cache_root):
        result=super().load_subject(path,selected_features,cache_root)
        with np.load(path,allow_pickle=False) as z:
            result['y']=z['scores'][result['trial'],0].astype(np.int64)
        assert set(np.unique(result['y'])).issubset(set(range(K)))
        return result
    def inspect(self):
        d=super().inspect();d['class_names']=CLASSES[self.name];d['threshold']=None
        return d

class Model(BaseModel):
    def __init__(self,method,channels,feature_dim,backbone='compact'):
        super().__init__(method,channels,feature_dim,backbone)
        self.classifier=nn.Linear(self.classifier.in_features,K)

def metrics(y,pred,prob):
    cm=confusion_matrix(y,pred,labels=np.arange(K))
    tp=np.diag(cm);fn=cm.sum(1)-tp;fp=cm.sum(0)-tp;tn=cm.sum()-tp-fn-fp
    recall=tp/np.maximum(tp+fn,1);specificity=tn/np.maximum(tn+fp,1)
    aucs=[]
    for k in range(K):
        if len(np.unique(y==k))==2:aucs.append(roc_auc_score(y==k,prob[:,k]))
    return {'accuracy':float(accuracy_score(y,pred)),'macro_f1':float(f1_score(y,pred,labels=np.arange(K),average='macro',zero_division=0)),
            'balanced_accuracy':float(recall.mean()),'macro_recall':float(recall.mean()),'sensitivity':float(recall.mean()),'specificity':float(specificity.mean()),
            'roc_auc':float(np.mean(aucs)) if len(aucs)==K else None,'mcc':float(matthews_corrcoef(y,pred)),
            'weighted_f1':float(f1_score(y,pred,labels=np.arange(K),average='weighted',zero_division=0)),
            'pr_auc':float(average_precision_score(np.eye(K)[y],prob,average='macro')) if len(np.unique(y))==K else None,
            'cohen_kappa':engine.finite_or_none(cohen_kappa_score(y,pred)), 'confusion_matrix':cm.tolist(),
            'per_class_recall':recall.tolist(),'per_class_specificity':specificity.tolist()}

def grouped(y,pred,prob,group):
    rows=[]
    for s in np.unique(group):
        ix=group==s;r=metrics(y[ix],pred[ix],prob[ix]);r['group']=str(s);rows.append(r)
    return {'mean':{k:float(np.mean([r[k] for r in rows])) for k in ['macro_f1','accuracy','balanced_accuracy','sensitivity','specificity']},'per_group':rows}

def trial_metrics(y,pred,prob,subjects,trials):
    ys=[];ps=[];ss=[]
    for subject in np.unique(subjects):
        for trial in np.unique(trials[subjects==subject]):
            mask=(subjects==subject)&(trials==trial)
            assert len(np.unique(y[mask]))==1
            ys.append(y[mask][0]);ps.append(prob[mask].mean(0));ss.append(subject)
    ys=np.asarray(ys);ps=np.asarray(ps);ss=np.asarray(ss);pr=ps.argmax(1)
    return {'overall':metrics(ys,pr,ps),'per_subject':grouped(ys,pr,ps,ss),'trials':len(ys)}

@torch.no_grad()
def evaluate(model,split,features):
    model.eval();ps=[]
    device=next(model.parameters()).device
    for start in range(0,len(split['y_cpu']),256):
        end=start+256
        logits,_=model(split['x'][start:end].to(device),None if features is None else features[start:end].to(device))
        ps.append(logits.softmax(1).cpu().numpy())
    prob=np.concatenate(ps);pred=prob.argmax(1);y=split['y_cpu']
    return {'window':metrics(y,pred,prob),'subject':grouped(y,pred,prob,split['subject']),
            'trial':trial_metrics(y,pred,prob,split['subject'],split['trial'])},pred,prob

def within_splits(adapter,folds,seed):
    parts={}
    for index,path in enumerate(adapter.subject_files):
        with np.load(path) as z:
            trials=np.unique(z['trial_index'][z['quality_ok']]).astype(int)
            # SEED repeats the same 15 videos across sessions; bind repetitions.
            groupids=trials%15 if adapter.name=='SEED' else trials
            bins=[[] for _ in range(folds)]
            for label in range(K):
                units=np.unique(groupids[z['scores'][trials,0]==label])
                np.random.default_rng(seed+index*1009+label*97).shuffle(units)
                for f,items in enumerate(np.array_split(units,folds)):
                    bins[f].extend(trials[np.isin(groupids,items)].tolist())
            parts[path.stem]=[sorted(set(v)) for v in bins]
    out=[]
    for f in range(folds):
        split={'train':{},'val':{},'test':{}}
        for s,bins in parts.items():
            split['test'][s]=bins[f];split['val'][s]=bins[(f+1)%folds]
            split['train'][s]=sorted(t for i,b in enumerate(bins) if i not in [f,(f+1)%folds] for t in b)
            assert not set(split['train'][s]) & set(split['test'][s])
        out.append(split)
    return out

def configure(dataset):
    global K
    K=len(CLASSES[dataset])
    engine.DATASET_SPECS={d:{'emotion':(0,0)} for d in CLASSES}
    engine.DatasetAdapter=Adapter;engine.ExperimentNet=Model
    engine.core_metrics=metrics;engine.grouped_metrics=grouped;engine.trial_metrics=trial_metrics;engine.evaluate=evaluate
    engine.make_subject_dependent_splits=within_splits

def main():
    # One dataset per invocation ensures the output layer cannot silently mix class counts.
    i=sys.argv.index('--datasets') if '--datasets' in sys.argv else -1
    if i<0 or sys.argv[i+1] not in CLASSES:raise SystemExit('Specify --datasets SEED, SEED_IV, or SEED_V (one per invocation)')
    if i+2<len(sys.argv) and not sys.argv[i+2].startswith('--'):raise SystemExit('Use one dataset per invocation')
    configure(sys.argv[i+1]);engine.main()

if __name__=='__main__':main()
