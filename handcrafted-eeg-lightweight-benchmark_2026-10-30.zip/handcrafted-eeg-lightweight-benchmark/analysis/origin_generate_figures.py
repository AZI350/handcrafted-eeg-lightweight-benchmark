"""Build editable Origin figures from the manuscript's real experiment CSV files.

Run this file inside Origin's embedded Python Console after changing the
working directory to this repository's ``analysis`` directory.

No simulated observations are created. Small deterministic horizontal offsets are
used only to prevent overlapping seed markers in the paired-difference display.
"""

from __future__ import annotations

import csv
import math
import statistics
import traceback
from collections import defaultdict
from pathlib import Path

import numpy as np
import originpro as op


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
OUT = ROOT / "origin_figures"
OUT.mkdir(parents=True, exist_ok=True)

TASKS = ["D-A", "D-V", "F-A", "F-V", "SEED", "SEED-IV", "SEED-V"]
METHODS = ["EEG only", "Feature only", "Direct fusion", "Auxiliary"]
METHOD_COLORS = ["#4477AA", "#DDAA33", "#228877", "#AA4499"]
PALE = "#CCD6DB"
DARK = "#263238"
GRID = "#E4EAED"
RED = "#C75B5B"


def read_csv(name: str):
    with (DATA / name).open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def task_code(dataset: str, target: str) -> str:
    dataset = dataset.replace("_", "-")
    if dataset == "DREAMER":
        return "D-A" if target == "arousal" else "D-V"
    if dataset == "FACED":
        return "F-A" if target == "arousal" else "F-V"
    return dataset


def percentile(values, p):
    ordered = sorted(float(v) for v in values)
    if not ordered:
        return math.nan
    position = (len(ordered) - 1) * p / 100.0
    low = int(math.floor(position))
    high = int(math.ceil(position))
    if low == high:
        return ordered[low]
    return ordered[low] + (ordered[high] - ordered[low]) * (position - low)


def setup_sheet(book, name, columns):
    wks = book.add_sheet(name)
    wks.cols = len(columns)
    for i, (label, values) in enumerate(columns):
        wks.from_list(i, values)
        wks.set_label(i, label, "L")
    return wks


def style_layer(layer, xlabel, ylabel, y_range=None):
    layer.axis("x").title = xlabel
    layer.axis("y").title = ylabel
    if y_range:
        layer.set_ylim(*y_range)
    # Keep graph styling conservative and journal-friendly. Unsupported settings
    # on older Origin builds are deliberately ignored without affecting the data.
    for command in (
        "layer.x.showgrids=0;",
        "layer.y.showgrids=1;",
        "layer.y.grid.color=ltgray;",
        "layer.y.grid.width=0.4;",
        "layer.x.label.fsize=18; layer.y.label.fsize=18;",
        "layer.x.title.fsize=20; layer.y.title.fsize=20;",
        "layer.x.title.font=Arial; layer.y.title.font=Arial;",
    ):
        try:
            layer.lt_exec(command)
        except Exception:
            pass


def delete_legend(layer):
    """Remove Origin's auto legend when the visual encoding is self-explanatory."""
    try:
        legend = layer.label("Legend")
        if legend:
            layer.remove_label(legend)
    except Exception:
        try:
            layer.lt_exec("label -r Legend;")
        except Exception:
            pass


def shrink_legend(layer, size=12):
    try:
        legend = layer.label("Legend")
        if legend:
            legend.set_int("fsize", size)
    except Exception:
        pass


def move_legend(layer, x, y, size=11):
    try:
        layer.lt_exec(f"legend.x={x}; legend.y={y}; legend.fsize={size};")
    except Exception:
        pass


def categorical_ticks(layer, labels, start=1):
    """Use exact manuscript labels instead of numeric category indices."""
    escaped = " ".join(f'\"{label}\"' if " " in label else label for label in labels)
    layer.lt_exec(
        f'layer.x.from={start - 0.45}; layer.x.to={start + len(labels) - 0.55}; '
        f'layer.x.inc=1; layer.x.label.type=10; layer.x.label.string$="{escaped}";'
    )


def categorical_ticks_y(layer, labels, start=1):
    escaped = " ".join(f'\"{label}\"' if " " in label else label for label in labels)
    layer.lt_exec(
        f'layer.y.from={start - 0.45}; layer.y.to={start + len(labels) - 0.55}; '
        f'layer.y.inc=1; layer.y.label.type=10; layer.y.label.string$="{escaped}";'
    )


def export_graph(graph, stem, width=1800):
    for suffix in (".pdf", ".svg", ".png"):
        try:
            graph.save_fig(str(OUT / f"{stem}{suffix}"), width=width)
        except TypeError:
            graph.save_fig(str(OUT / f"{stem}{suffix}"))


def main_scores(book, protocol, stem, title):
    rows = read_csv("fine_grained_seed_means.csv")
    lookup = defaultdict(list)
    for row in rows:
        if row["protocol"] != protocol:
            continue
        lookup[(task_code(row["dataset"], row["target"]), row["method"])].append(
            100.0 * float(row["trial_macro_f1"])
        )

    task_series = []
    method_values = defaultdict(list)
    for task in TASKS:
        values = []
        for method in METHODS:
            seeds = lookup[(task, method)]
            if len(seeds) != 5:
                raise RuntimeError(f"Expected five seed means for {protocol}/{task}/{method}")
            value = statistics.mean(seeds)
            values.append(value)
            method_values[method].append(value)
        task_series.append(values)

    medians = [statistics.median(method_values[m]) for m in METHODS]
    q1 = [percentile(method_values[m], 25) for m in METHODS]
    q3 = [percentile(method_values[m], 75) for m in METHODS]
    wks = setup_sheet(
        book,
        stem[:20],
        [("Method", METHODS)]
        + [(task, values) for task, values in zip(TASKS, task_series)]
        + [("Median", medians), ("Q1", q1), ("Q3", q3)],
    )

    graph = op.new_graph(template="scatter")
    layer = graph[0]
    for i in range(len(TASKS)):
        plot = layer.add_plot(wks, coly=1 + i, colx=0, type="y")
        plot.color = PALE
        plot.symbol_size = 7
        plot.symbol_kind = 20 + (i % 4)
        plot.symbol_interior = 0
        try:
            plot.transparency = 18
            plot.set_float("line.width", 0.7)
        except Exception:
            pass

    summary = layer.add_plot(wks, coly=8, colx=0, type="s")
    summary.color = DARK
    summary.symbol_size = 11
    summary.symbol_kind = 2
    for x, low, high in zip(range(1, 5), q1, q3):
        line = layer.add_line(x, low, x, high)
        line.color = DARK
        line.width = 2
        cap1 = layer.add_line(x - 0.10, low, x + 0.10, low)
        cap2 = layer.add_line(x - 0.10, high, x + 0.10, high)
        cap1.color = DARK
        cap2.color = DARK
        cap1.width = cap2.width = 2
    style_layer(layer, "Feature-participation mode", "Trial Macro-F1 / %", (20, 85))
    layer.rescale()
    layer.set_ylim(20, 85)
    move_legend(layer, 70, 67, 10)
    export_graph(graph, stem)


def paired_delta(book, protocol, stem, title):
    rows = read_csv("fine_grained_fusion_deltas.csv")
    summary = read_csv("fine_grained_fusion_delta_summary.csv")
    offsets = [-0.12, -0.06, 0.0, 0.06, 0.12]
    x_all, y_all, labels = [], [], []
    means, lows, highs = [], [], []
    for i, task in enumerate(TASKS, start=1):
        values = [
            float(r["fusion_minus_eeg_pp"])
            for r in rows
            if r["protocol"] == protocol and task_code(r["dataset"], r["target"]) == task
        ]
        if len(values) != 5:
            raise RuntimeError(f"Expected five paired seed differences for {protocol}/{task}")
        for off, value in zip(offsets, values):
            x_all.append(i + off)
            y_all.append(value)
            labels.append(task)
        rec = next(
            r
            for r in summary
            if r["protocol"] == protocol and task_code(r["dataset"], r["target"]) == task
        )
        means.append(float(rec["mean_delta_pp"]))
        lows.append(float(rec["ci95_low_pp"]))
        highs.append(float(rec["ci95_high_pp"]))

    wks = setup_sheet(
        book,
        stem[:20],
        [
            ("Seed x", x_all),
            ("Seed delta", y_all),
            ("Task", labels),
            ("Task x", list(range(1, 8))),
            ("Mean delta", means),
            ("CI95 low", lows),
            ("CI95 high", highs),
        ],
    )
    graph = op.new_graph(template="scatter")
    layer = graph[0]
    raw = layer.add_plot(wks, coly=1, colx=0, type="s")
    raw.color = "#228877"
    raw.symbol_size = 8
    raw.symbol_kind = 1
    raw.symbol_interior = 0
    mean_plot = layer.add_plot(wks, coly=4, colx=3, type="s")
    mean_plot.color = DARK
    mean_plot.symbol_size = 11
    mean_plot.symbol_kind = 2
    zero = layer.add_line(0.55, 0, 7.45, 0)
    zero.color = "#7B878D"
    zero.width = 1
    try:
        zero.set_int("style", 1)
    except Exception:
        pass
    for x, low, high in zip(range(1, 8), lows, highs):
        line = layer.add_line(x, low, x, high)
        line.color = DARK
        line.width = 2
        for y in (low, high):
            cap = layer.add_line(x - 0.09, y, x + 0.09, y)
            cap.color = DARK
            cap.width = 2
    style_layer(layer, "Task",
                "Direct fusion - EEG only / percentage points", (-8, 15))
    categorical_ticks(layer, TASKS)
    layer.rescale()
    layer.set_xlim(0.55, 7.45)
    layer.set_ylim(-8, 15)
    move_legend(layer, 67, 4, 10)
    export_graph(graph, stem)


def robustness(book):
    rows = read_csv("robustness_summary.csv")
    datasets = ["SEED", "SEED-IV", "SEED-V"]

    def get(field, condition):
        return [
            float(next(r for r in rows if r["dataset"] == ds and r["condition"] == condition)[field])
            for ds in datasets
        ]

    clean = get("trial_macro_f1_pct", "clean")
    noise = get("trial_macro_f1_pct", "snr10")
    dropout = get("trial_macro_f1_pct", "drop25")
    dom_noise = get("dominant_predicted_class_pct", "snr10")
    dom_dropout = get("dominant_predicted_class_pct", "drop25")
    uniform = [100 / 3, 25, 20]
    wks = setup_sheet(
        book,
        "Robustness",
        [
            ("Dataset", datasets),
            ("Clean", clean),
            ("10-dB noise", noise),
            ("25% dropout", dropout),
            ("Dominant noise", dom_noise),
            ("Dominant dropout", dom_dropout),
            ("Uniform reference", uniform),
        ],
    )

    graph = op.new_graph(template="Column")
    layer = graph[0]
    colors = ["#377E9F", "#E5962D", RED]
    for col, color in zip((1, 2, 3), colors):
        plot = layer.add_plot(wks, coly=col, colx=0, type="c")
        plot.color = color
    try:
        layer.group(True, 0, 2)
    except Exception:
        pass
        try:
            plot.transparency = 5
        except Exception:
            pass
    style_layer(layer, "", "Trial Macro-F1 / %", (0, 86))
    layer.rescale()
    layer.set_ylim(0, 86)
    move_legend(layer, 55, 12, 11)
    try:
        layer.lt_exec("set %C -vg 45;")
    except Exception:
        pass
    export_graph(graph, "origin_robustness_performance")

    graph2 = op.new_graph(template="Column")
    layer2 = graph2[0]
    for col, color in zip((4, 5), ("#DDAA33", RED)):
        plot = layer2.add_plot(wks, coly=col, colx=0, type="c")
        plot.color = color
    try:
        layer2.group(True, 0, 1)
    except Exception:
        pass
    ref = layer2.add_plot(wks, coly=6, colx=0, type="y")
    ref.color = "#7B878D"
    ref.symbol_size = 7
    ref.symbol_kind = 1
    style_layer(layer2, "", "Dominant predicted class / %", (0, 105))
    layer2.rescale()
    layer2.set_ylim(0, 105)
    move_legend(layer2, 50, 12, 11)
    try:
        ref.set_int("line.style", 2)
        ref.set_float("line.width", 1.4)
        layer2.lt_exec("set %C -vg 55;")
    except Exception:
        pass
    export_graph(graph2, "origin_robustness_collapse")


def confusion_heatmaps():
    rows = read_csv("confusion_matrices_long.csv")
    tasks = [
        ("DREAMER arousal", "origin_cm_dreamer_arousal", False),
        ("DREAMER valence", "origin_cm_dreamer_valence", False),
        ("FACED arousal", "origin_cm_faced_arousal", False),
        ("FACED valence", "origin_cm_faced_valence", True),
        ("SEED", "origin_cm_seed", False),
        ("SEED-IV", "origin_cm_seed_iv", False),
        ("SEED-V", "origin_cm_seed_v", True),
    ]
    for task, stem, show_scale in tasks:
        task_rows = [row for row in rows if row["task"] == task]
        labels = sorted(
            {row["true_class"] for row in task_rows},
            key=lambda label: min(
                int(row["true_index"]) for row in task_rows if row["true_class"] == label
            ),
        )
        n = len(labels)
        arr = np.zeros((n, n), dtype=float)
        for row in task_rows:
            arr[int(row["true_index"]), int(row["pred_index"])] = float(row["row_percent"])

        # Origin maps matrix row zero to the bottom of the y axis. Reverse the
        # matrix rows so that the first true class appears at the top.
        mat = op.new_sheet(type="m", lname=f"CM {task}")
        mat.from_np(np.round(arr[::-1], 1))
        mat.set_label(0, "Row-normalized / %")
        mat.xymap = (0.5, n + 0.5, 0.5, n + 0.5)

        graph = op.new_graph(
            template="Heat_Map"
        )
        layer = graph[0]
        plot = layer.add_mplot(mat, 0, type=105)
        plot.colormap = "Viridis.PAL"
        levels = plot.zlevels
        levels["minors"] = 9
        levels["levels"] = [0, 50, 100]
        plot.zlevels = levels
        layer.set_xlim(0.5, n + 0.5, 1)
        layer.set_ylim(0.5, n + 0.5, 1)
        categorical_ticks(layer, labels)
        categorical_ticks_y(layer, list(reversed(labels)))
        style_layer(layer, "Predicted class", "True class")
        # Add one explicit, centered percentage per cell.  Using graph objects
        # instead of the template's default data labels prevents edge labels
        # from being clipped in the 4- and 5-class matrices and keeps the
        # binary and multiclass panels visually identical.
        for true_idx in range(n):
            for pred_idx in range(n):
                value = arr[true_idx, pred_idx]
                text = layer.add_label(f"{value:.1f}", pred_idx + 1, n - true_idx)
                text.set_int("align", 1)
                text.set_int("fsize", 17 if n <= 3 else 14)
                text.set_int("bold", 1)
                text.color = "#FFFFFF" if value >= 42 else "#17232B"
        for command in (
            "layer.x.showgrids=0; layer.y.showgrids=0;",
            "layer.x.label.rotate=0;",
        ):
            try:
                layer.lt_exec(command)
            except Exception:
                pass
        if not show_scale:
            try:
                layer.lt_exec("label -r ColorScale;")
            except Exception:
                pass
        export_graph(graph, stem, width=1200 if n > 2 else 1050)


def deployment_cost(book):
    rows = read_csv("deployment_cost.csv")
    columns = []
    for i, row in enumerate(rows):
        point_name = f"{row['dataset']} | {row['method']}"
        columns.extend(
            [
                (f"Parameters {i+1}", [float(row["parameters"]) / 1000.0]),
                (point_name, [float(row["processing_time_ms"])]),
            ]
        )
    wks = setup_sheet(book, "DeploymentCost", columns)
    graph = op.new_graph(template="scatter")
    layer = graph[0]
    shape = {"DREAMER": 2, "FACED": 3, "SEED": 1}
    for i, row in enumerate(rows):
        plot = layer.add_plot(wks, coly=2 * i + 1, colx=2 * i, type="s")
        plot.color = "#4477AA" if row["method"] == "EEG only" else "#228877"
        plot.symbol_size = 13
        plot.symbol_kind = shape[row["dataset"]]
    style_layer(layer, "Deployment parameters / thousand",
                "Measured processing time / ms per window", (0.2, 3.82))
    layer.rescale()
    layer.set_xlim(8, 83)
    layer.set_ylim(0.2, 3.82)
    shrink_legend(layer, 11)
    export_graph(graph, "origin_deployment_cost", width=1400)


def run():
    log_path = OUT / "origin_generation_log.txt"
    try:
        first = op.new_sheet(lname="EEG manuscript source data")
        book = first.get_book()
        first.name = "ReadMe"
        first.cols = 2
        first.from_list(0, ["Source", "Statistical unit", "Export", "Created by"])
        first.from_list(
            1,
            [
                "Real manuscript CSV files",
                "Five fold-averaged seed means per task",
                "Editable Origin project plus PDF/SVG/PNG",
                "Origin 2026b embedded Python / originpro",
            ],
        )

        main_scores(book, "subject_dependent", "origin_main_within", "(a) Within-subject")
        main_scores(book, "subject_independent", "origin_main_cross", "(b) Subject-independent")
        paired_delta(book, "subject_dependent", "origin_delta_within", "(a) Within-subject")
        paired_delta(book, "subject_independent", "origin_delta_cross", "(b) Subject-independent")
        robustness(book)
        confusion_heatmaps()
        deployment_cost(book)

        project = OUT / "Origin_EEG_results_2026-10-29.opju"
        op.save(str(project))
        log_path.write_text(
            "SUCCESS\n"
            f"Project: {project}\n"
            "Figures: 14 editable Origin graph pages; PDF, SVG, and PNG exports requested.\n",
            encoding="utf-8",
        )
        print(f"ORIGIN FIGURES COMPLETE: {project}")
    except Exception:
        message = traceback.format_exc()
        log_path.write_text("FAILED\n" + message, encoding="utf-8")
        print(message)
        raise


run()
