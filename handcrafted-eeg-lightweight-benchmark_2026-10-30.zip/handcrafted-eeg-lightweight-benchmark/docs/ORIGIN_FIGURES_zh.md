# Origin 论文结果图

## 已生成内容

- `Origin_EEG_results_2026-10-29.opju`：可编辑 Origin 工程，包含 1 个源数据工作簿和 7 个图窗口。
- `origin_main_within.*`：受试者内四种参与方式比较；浅线为七个正式任务，深色点和误差线为任务中位数与四分位距。
- `origin_main_cross.*`：独立受试者四种参与方式比较，统计定义同上。
- `origin_delta_within.*`：受试者内直接融合相对 EEG-only 的五种子配对差值、均值与 95% Student-t 置信区间。
- `origin_delta_cross.*`：独立受试者配对差值，统计定义同上。
- `origin_robustness_performance.*`：SEED、SEED-IV、SEED-V 在干净、10 dB 噪声和 25% 通道丢弃条件下的 Trial Macro-F1。
- `origin_robustness_collapse.*`：扰动后最大预测类别占比及均匀预测参考。
- `origin_deployment_cost.*`：DREAMER、FACED、SEED 的参数量与单窗口处理时间。

每张图均提供 `.pdf`、`.svg` 和 `.png`。论文优先使用 PDF；若后续需要在 Illustrator、Inkscape 或 PowerPoint 中修改文字和线条，可使用 SVG。

## 数据与统计约束

- 所有数值直接读取论文 `data` 目录中的真实实验 CSV；未生成示意数据。
- 主比较使用五个随机种子各自先在五折上求均值后的结果。
- 配对差值以随机种子为统计单元，折没有被当作独立重复样本。
- 图中的横向微移只用于避免五个种子点互相遮挡，不改变任何实验数值。

## Origin 中继续编辑

1. 双击 `.opju` 工程。
2. 在 Project Explorer 中双击 Graph1–Graph7 打开对应图。
3. 双击坐标轴修改刻度、字体和范围；双击数据点或柱形修改颜色、符号、线宽和透明度。
4. 数据位于 `EEG manuscript source data` 工作簿的不同工作表中，修改工作表后可在图中重新缩放。
5. 导出时优先选择 PDF 或 SVG，并保留字体为可编辑文本。

## 质量检查

- SVG 文件保留可编辑 `<text>` 节点。
- PDF 字体检查可审计，七张图的最小文字均不低于约 9 pt，高于 5 pt 下限。
- 已逐图人工检查坐标轴、图例、数据范围和遮挡。
- 自动 PDF 碰撞检查因当前环境缺少 PyMuPDF 未能执行，因此没有声称该项自动检查通过；后续安装 PyMuPDF 后可补跑。
- 通用 Python 源码检查器把 Origin 导出误判为缺少 Matplotlib 的 `svg.fonttype`、`pdf.fonttype` 和 DPI 设置；这些检查不适用于 Origin 的原生 PDF/SVG 导出。

## 可复现入口

- `origin_generate_figures.py`：Origin 内嵌 Python 制图脚本。
- `run_origin_figures.ogs`：可从 Origin Script Window 调用的 LabTalk 入口。

