"""Locally defined compact 1D architectural controls, not paper reproductions.

All return 64 dimensions and downsample by 8, with identical classifier heads.
"""
import torch
from torch import nn


def conv(cin, cout, kernel=3, stride=1, groups=1):
    return nn.Sequential(nn.Conv1d(cin, cout, kernel, stride, kernel//2, groups=groups, bias=False), nn.BatchNorm1d(cout), nn.ReLU())


class Residual(nn.Module):
    def __init__(self, cin, cout, stride):
        super().__init__()
        self.body=nn.Sequential(conv(cin,cout,3,stride), nn.Conv1d(cout,cout,3,padding=1,bias=False),nn.BatchNorm1d(cout))
        self.skip=nn.Identity() if cin==cout and stride==1 else nn.Sequential(nn.Conv1d(cin,cout,1,stride,bias=False),nn.BatchNorm1d(cout))
    def forward(self,x):
        return torch.relu(self.body(x)+self.skip(x))


class Fire(nn.Module):
    def __init__(self, cin, squeeze, expand):
        super().__init__()
        self.squeeze=conv(cin,squeeze,1)
        self.one=conv(squeeze,expand,1)
        self.three=conv(squeeze,expand,3)
    def forward(self,x):
        x=self.squeeze(x)
        return torch.cat([self.one(x),self.three(x)],dim=1)


def build_backbone(name, channels):
    if name=='resnet1d':
        blocks=[conv(channels,32,7,2),Residual(32,32,1),Residual(32,64,2),Residual(64,64,2)]
    elif name=='mobilenet1d':
        blocks=[conv(channels,32,7,2),conv(32,32,3,2,32),conv(32,64,1),conv(64,64,3,2,64),conv(64,64,1)]
    elif name=='squeezenet1d':
        blocks=[conv(channels,32,7,2),Fire(32,8,16),nn.MaxPool1d(3,2,1),Fire(32,16,32),nn.MaxPool1d(3,2,1),Fire(64,16,32)]
    else:
        raise ValueError(name)
    return nn.Sequential(*blocks,nn.AdaptiveAvgPool1d(1),nn.Flatten())
