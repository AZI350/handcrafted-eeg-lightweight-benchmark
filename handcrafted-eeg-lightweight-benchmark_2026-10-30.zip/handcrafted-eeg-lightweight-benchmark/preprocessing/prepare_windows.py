"""Create matched 1/2/4-second files from one-second DREAMER/FACED NPZ files."""
import argparse
import json
from pathlib import Path

import numpy as np


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input-root', type=Path, required=True,
                        help='Contains DREAMER/ and FACED/ one-second NPZ files')
    parser.add_argument('--output-root', type=Path, required=True,
                        help='Receives window_1s/, window_2s/, and window_4s/')
    args = parser.parse_args()
    manifest = []
    for dataset, expected in [('DREAMER', 23), ('FACED', 123)]:
        sources = sorted((args.input_root / dataset).glob('*.npz'))
        if len(sources) != expected:
            raise RuntimeError(f'{dataset}: expected {expected} NPZ files, found {len(sources)}')
        for source in sources:
            with np.load(source, allow_pickle=False) as archive:
                rows = {key: archive[key] for key in archive.files}
            if int(rows['sfreq']) != 250:
                raise ValueError(f'{source}: expected 250 Hz')
            trials = np.unique(rows['trial_index'])
            output = {seconds: [] for seconds in (1, 2, 4)}
            masks = {seconds: [] for seconds in output}
            indices = {seconds: [] for seconds in output}
            for trial in trials:
                ix = np.flatnonzero(rows['trial_index'] == trial)
                ix = ix[np.argsort(rows['window_in_trial'][ix])]
                if len(ix) < 28:
                    raise ValueError(f'{source}: trial {trial} has fewer than 28 seconds')
                ix = ix[:28]
                signal = rows['eeg_uv'][ix]
                good4 = rows['quality_ok'][ix].reshape(7, 4).all(axis=1)
                for seconds in output:
                    chunks = signal.reshape(28 // seconds, seconds, signal.shape[1], 250)
                    chunks = chunks.transpose(0, 2, 1, 3).reshape(28 // seconds, signal.shape[1], 250 * seconds)
                    output[seconds].append(chunks)
                    masks[seconds].append(np.repeat(good4, 4 // seconds))
                    indices[seconds].extend([int(trial)] * (28 // seconds))
            valid_durations = []
            for seconds in output:
                destination = args.output_root / f'window_{seconds}s' / dataset / source.name
                destination.parent.mkdir(parents=True, exist_ok=True)
                eeg = np.concatenate(output[seconds])
                quality = np.concatenate(masks[seconds])
                np.savez(destination, eeg_uv=eeg, quality_ok=quality,
                         trial_index=np.asarray(indices[seconds], dtype=np.int16),
                         window_in_trial=np.tile(np.arange(28 // seconds), len(trials)),
                         scores=rows['scores'], channel_names=rows['channel_names'], sfreq=rows['sfreq'])
                valid_durations.append(int(quality.sum()) * seconds)
                manifest.append({'dataset': dataset, 'subject': source.stem, 'window_s': seconds,
                                 'windows': len(eeg), 'valid_windows': int(quality.sum()),
                                 'source_file': source.name})
            if len(set(valid_durations)) != 1:
                raise RuntimeError(f'{source}: valid duration differs by window length')
            print(f'PREPARED {dataset}/{source.stem}: {valid_durations[0]} valid seconds', flush=True)
    args.output_root.mkdir(parents=True, exist_ok=True)
    (args.output_root / 'preparation_manifest.json').write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
