"""CPU unit/integration checks; no real-data training or GPU required."""
import tempfile
from pathlib import Path
import numpy as np
import torch
import cloud
from prepare import process

def main():
    torch.set_num_threads(2)
    rng=np.random.default_rng(1)
    for dataset in cloud.CLASSES:
        cloud.configure(dataset);k=len(cloud.CLASSES[dataset])
        y=np.tile(np.arange(k),3);prob=np.eye(k)[y]*.9+.1/k
        assert cloud.metrics(y,prob.argmax(1),prob)['macro_f1']==1
        tm=cloud.trial_metrics(y,y,prob,np.repeat('sub01',len(y)),np.arange(len(y)))
        assert tm['overall']['macro_f1']==1
        model=cloud.Model('baseline',4,0)
        test={'x':torch.randn(len(y),4,250),'y_cpu':y,'subject':np.repeat('sub01',len(y)),'trial':np.arange(len(y))}
        metric,pred,probability=cloud.evaluate(model,test,None)
        assert probability.shape==(len(y),k) and np.allclose(probability.sum(1),1,atol=1e-6)
        assert metric['trial']['overall']['confusion_matrix']==metric['window']['confusion_matrix']
        for backbone in ['compact','resnet1d','mobilenet1d','squeezenet1d']:
            for method in ['baseline','feature_only','direct_fusion','aux_supervision']:
                model=cloud.Model(method,4,12,backbone)
                logits,aux=model(torch.randn(4,4,250),torch.randn(4,12))
                assert logits.shape==(4,k)
                loss=logits.square().mean()+(aux.square().mean() if aux is not None else 0)
                loss.backward()
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as td:
            root=Path(td);(root/dataset).mkdir()
            # session-specific trials for adapter/split tests; SEED binds repeated IDs.
            n=45 if dataset!='SEED_IV' else 72
            labels=np.arange(n)%k
            np.savez(root/dataset/'sub01.npz',eeg_uv=rng.normal(size=(n,4,250)).astype('float32'),quality_ok=np.ones(n,bool),trial_index=np.arange(n),window_in_trial=np.zeros(n,int),scores=labels[:,None],channel_names=np.array(['FP1','F3','C3','O1']),sfreq=250)
            a=cloud.Adapter(dataset,root,'emotion',None)
            d=a.load_subject(a.subject_files[0],set(),root/'cache')
            assert np.array_equal(d['y'],labels)
            splits=cloud.within_splits(a,5,20261013)
            test_ids=[]
            for s in splits:
                tr=set(s['train']['sub01']);va=set(s['val']['sub01']);te=set(s['test']['sub01'])
                assert not tr&va and not tr&te and not te&va
                assert tr|va|te==set(range(n));test_ids+=list(te)
                if dataset=='SEED':assert not {t%15 for t in tr}&{t%15 for t in te}
            assert sorted(test_ids)==list(range(n))
    x=process(rng.normal(size=(62,7000)),200)
    assert x.shape==(62,7000) and np.isfinite(x).all()
    print('PASS: 3/4/5-class heads, 48 model forwards/backwards, multiclass/trial metrics, grouped splits, adapter labels, preprocessing')

if __name__=='__main__':main()
