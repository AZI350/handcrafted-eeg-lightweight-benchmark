# Public release checklist

Complete these items before changing the GitHub repository to public:

- [ ] Choose a source-code licence and replace `LICENSE_TO_CHOOSE.md` with the standard `LICENSE` text.
- [ ] Replace anonymized or provisional author metadata in `CITATION.cff` with the final author list.
- [ ] Add the final article journal, year, volume, pages/article number, and DOI to `CITATION.cff`.
- [ ] Confirm that no raw or processed participant EEG, access form, approval e-mail, credential, or token is committed.
- [ ] Run `python tests/verify_repository.py`.
- [ ] Run `python analysis/verify_source_data.py`.
- [ ] Regenerate figures with `python analysis/make_figures.py` and compare them with the submitted manuscript.
- [ ] Run one GPU smoke test for each pipeline on a clean Python 3.10 environment.
- [ ] Create a tagged release such as `v1.0.0` matching the submitted/accepted code.
- [ ] Archive the tagged GitHub release in Zenodo or another stable repository if a software DOI is required.
- [ ] Replace the placeholders in the Code Availability statement below.

## Ready-to-adapt Code Availability statement

> The code used for preprocessing, feature extraction, model training, evaluation, and figure generation is available at [GITHUB-URL], release [VERSION], and is archived at [SOFTWARE-DOI, if available]. The repository includes fixed split and seed configurations and the source-data tables underlying the manuscript figures. DREAMER, FACED, SEED, SEED-IV, and SEED-V are third-party datasets and are not redistributed; they must be obtained from their original providers under the applicable access and licence conditions.

Do not insert a repository URL or DOI until the public record exists.
