import argparse,json
from pathlib import Path
import numpy as np
p=argparse.ArgumentParser();p.add_argument('--data-root',type=Path,default=Path(__file__).resolve().parent/'data');a=p.parse_args()
inventory=json.loads((Path(__file__).resolve().parent/'upload_inventory.json').read_text())
for row in inventory:
 path=a.data_root/row['path']
 assert path.exists() and path.stat().st_size==row['bytes'],str(path)
 with np.load(path,allow_pickle=False) as z:
  for key in ['eeg_uv','quality_ok','scores','trial_index','window_in_trial','channel_names','sfreq']:assert key in z,(path,key)
  assert int(z['sfreq'])==250 and len(z['trial_index'])==len(z['quality_ok'])
for ds,n in [('DREAMER',23),('FACED',123)]:assert len(list((a.data_root/ds).glob('*.npz')))==n
print('PASS: 146 data files, sizes, metadata, sampling rates; no full file hash check')
