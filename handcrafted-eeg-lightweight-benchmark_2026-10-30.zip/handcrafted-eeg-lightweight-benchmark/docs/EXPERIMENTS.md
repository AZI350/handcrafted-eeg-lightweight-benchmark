# Seven experiment groups

| ID | Question | Main change | Fixed reference |
|---:|---|---|---|
| 1 | Do handcrafted features help a compact EEG network, and where does the gain originate? | EEG-only, feature-only, direct fusion, auxiliary supervision; DTCWT, Hjorth, band ratios | Five folds, five seeds, matched protocol |
| 2 | Does trial-level early stopping improve final trial Macro-F1? | Validation selection metric | Same model/data configuration |
| 3 | Are cross-domain feature combinations better than single groups? | Pairwise and three-group combinations | Same training budget |
| 4 | Is the auxiliary-loss result stable to its weight? | 0.01, 0.03, 0.1, 0.3, 1.0 | Same auxiliary target and model |
| 5 | Does the performance-cost relation change across lightweight backbones? | Compact, ResNet1D, MobileNet1D, SqueezeNet1D | Same input and protocol |
| 6 | How does window duration affect trial prediction? | 1, 2, and 4 seconds | Equal retained valid duration |
| 7 | What happens under channel reduction and fixed-model perturbations? | Alternate/frontal channels; noise and dropout diagnostics | Full-channel clean model |

## Label spaces

- DREAMER and FACED: valence and arousal are evaluated separately as binary tasks.
- SEED: negative, neutral, positive.
- SEED-IV: neutral, sad, fear, happy.
- SEED-V: disgust, fear, sad, neutral, happy.

## Interpretation boundaries

- `subject_dependent` measures held-out trials from participants also represented in training; it is not unseen-participant generalization.
- `subject_independent` holds out complete participants.
- Trial probabilities are the mean of the probabilities from all retained windows belonging to that trial.
- Multiclass sensitivity is macro recall. It is not a binary event-coverage percentage.
- Five-seed intervals reflect optimization randomness under fixed splits.
- Perturbations are applied after filtering and are controlled stress tests, not complete acquisition-noise models.
