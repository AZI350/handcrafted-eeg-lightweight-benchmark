"""Portable staged training. Fixed executed epochs for exact update-budget controls."""
import argparse,copy,inspect,json,sys,time
from pathlib import Path
import torch
import run_experiment as core
Base=core.ExperimentNet

def build_finetune(validation_only=False):
    source=inspect.getsource(core.train_run)
    # Disable early stopping for all comparison arms: exactly T stage-2 epochs.
    source=source.replace('if stale >= args.patience:', 'if False: # fixed update budget')
    if validation_only:
        source=source.split('    test, prediction, probability = evaluate')[0]
        source+='''    result = {"dataset": adapter_info["dataset"], "target": adapter_info["target"], "protocol": args.protocol, "fold": fold, "seed": seed, "method": method, "feature_set": list(feature_set), "validation": validation, "best_epoch": best_epoch, "epochs_run": epoch, "training_seconds": time.perf_counter()-started, "validation_only": True}
    json_dump(metrics_file, result)
    return result
'''
    scope=dict(core.__dict__)
    exec(compile(source,'fixed_budget_finetune','exec'),scope)
    return scope['train_run'],scope

def main():
    p=argparse.ArgumentParser(add_help=False)
    p.add_argument('--stage1-objective',choices=['features','classification'],default='features')
    p.add_argument('--pretrain-epochs',type=int,default=20)
    p.add_argument('--pretrain-lr',type=float,default=.001)
    p.add_argument('--freeze-epochs',type=int,default=0)
    p.add_argument('--validation-only',action='store_true')
    p.add_argument('--reference',action='store_true',help='Pure EEG/direct fusion fixed-epoch references, no stage1')
    extra,rest=p.parse_known_args()
    if extra.pretrain_epochs<1 or extra.freeze_epochs<0:raise ValueError('Invalid stage lengths')
    finetune,scope=build_finetune(extra.validation_only)
    def train(args,info,fold,method,features,seed,arrays,folder):
        if extra.freeze_epochs>=args.max_epochs:raise ValueError('Freeze must end before final epoch')
        folder.mkdir(parents=True,exist_ok=True)
        config={**vars(extra),'feature_set':list(features),'stage2_lr':args.learning_rate,'stage2_epochs':args.max_epochs,'seed':seed}
        cfg=folder/'stage_config.json'
        if cfg.exists() and json.loads(cfg.read_text())!=config:raise RuntimeError('Stage settings changed; use new output')
        core.json_dump(cfg,config)
        completed=folder/'metrics.json'
        if completed.exists() and not args.overwrite:
            r=json.loads(completed.read_text(encoding='utf-8'))
            if r.get('stage_complete'):return r
            raise RuntimeError('Incomplete stage metadata; rerun this configuration with --overwrite')
        start=time.perf_counter();core.seed_everything(seed)
        feature_tensors={k:core.joined_features(v,features) for k,v in arrays.items()}
        feature_dim=0 if not features else feature_tensors['train'].shape[1]
        objective=extra.stage1_objective
        pre=Base('aux_supervision' if objective=='features' else 'baseline',info['channels'],feature_dim,args.backbone).cuda()
        params=list(pre.backbone.parameters())+list((pre.auxiliary if objective=='features' else pre.classifier).parameters())
        optimizer=torch.optim.AdamW(params,lr=extra.pretrain_lr,weight_decay=args.weight_decay)
        counts=core.np.bincount(arrays['train']['y_cpu'],minlength=2)
        ce=torch.nn.CrossEntropyLoss(weight=torch.tensor(counts.sum()/(2*counts),dtype=torch.float32,device='cuda'))
        best=float('inf') if objective=='features' else -float('inf')
        history=[];updates=0
        # Common order across the two objectives, independent of different head widths.
        core.seed_everything(seed+5000)
        for epoch in range(1,extra.pretrain_epochs+1):
            pre.train();order=torch.randperm(len(arrays['train']['y']));total=0.
            for at in range(0,len(order),args.batch_size):
                ix=order[at:at+args.batch_size];optimizer.zero_grad(set_to_none=True)
                logits,pred=pre(arrays['train']['x'][ix].cuda())
                loss=torch.nn.functional.mse_loss(pred,feature_tensors['train'][ix].cuda()) if objective=='features' else ce(logits,arrays['train']['y'][ix].cuda())
                loss.backward();torch.nn.utils.clip_grad_norm_(params,args.grad_clip);optimizer.step();updates+=1
                total+=loss.item()*len(ix)
            pre.eval()
            if objective=='features':
                score=0.
                with torch.no_grad():
                    for at in range(0,len(arrays['val']['y']),args.batch_size):
                        _,pred=pre(arrays['val']['x'][at:at+args.batch_size].cuda());target=feature_tensors['val'][at:at+args.batch_size].cuda()
                        score+=torch.nn.functional.mse_loss(pred,target).item()*len(target)
                score/=len(arrays['val']['y']);improved=score<best
            else:
                val,_,_=core.evaluate(pre,arrays['val'],None)
                score=val['trial']['overall']['macro_f1'];improved=score>best
            if not core.np.isfinite(score):raise RuntimeError('Nonfinite pretraining validation')
            if improved:
                best=score;torch.save(pre.backbone.state_dict(),folder/'pretrained_backbone.pt')
            history.append(dict(epoch=epoch,loss=total/len(order),validation_score=score))
            core.json_dump(folder/'pretrain_history.json',history)
            print(f'STAGE1 {objective} fold={fold} seed={seed} epoch={epoch}/{extra.pretrain_epochs} loss={total/len(order):.5f} val={score:.5f}',flush=True)
        pre_seconds=time.perf_counter()-start
        state=torch.load(folder/'pretrained_backbone.pt',map_location='cpu',weights_only=True)
        del optimizer,pre
        class Initialized(Base):
            def __init__(self,*a,**kw):
                super().__init__(*a,**kw);self.backbone.load_state_dict(state);self.stage2_epoch=0
            def train(self,mode=True):
                super().train(mode)
                if mode:
                    self.stage2_epoch+=1;frozen=self.stage2_epoch<=extra.freeze_epochs
                    for parameter in self.backbone.parameters():parameter.requires_grad_(not frozen)
                    if frozen:self.backbone.eval() # freeze normalization statistics too
                return self
        scope['ExperimentNet']=Initialized
        print('STAGE2 classification; fresh head/optimizer; fixed epochs',flush=True)
        result=finetune(args,info,fold,'baseline',features,seed,arrays,folder)
        result.update(method='aux_supervision',stage_complete=True,stage1_objective=objective,stage_config=config,
                      pretrain_seconds=pre_seconds,total_training_seconds=time.perf_counter()-start,
                      stage1_updates=updates,stage2_updates=((len(order)+args.batch_size-1)//args.batch_size)*args.max_epochs)
        core.json_dump(completed,result)
        return result
    core.train_run=finetune if extra.reference else train
    if extra.validation_only:core.summarize=lambda *a:None
    sys.argv=[sys.argv[0],*rest];core.main()

if __name__=='__main__':main()
