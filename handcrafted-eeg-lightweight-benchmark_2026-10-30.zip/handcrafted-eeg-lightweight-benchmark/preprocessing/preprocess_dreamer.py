"""Convert DREAMER.mat to the unified per-subject NPZ format.

The original MAT file is read-only.  Each of the 18 video stimuli is one
trial.  To match the FACED pipeline, the final 30 seconds are retained and
split into non-overlapping one-second windows at 250 Hz.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.io import loadmat

import preprocess as common


ROOT = Path(__file__).resolve().parent
CHANNELS = ["AF3", "F7", "F3", "FC5", "T7", "P7", "O1", "O2", "P8", "T8", "FC6", "F4", "F8", "AF4"]
SCORE_COLUMNS = ["valence", "arousal", "dominance"]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True, help='Licensed DREAMER.mat file')
    parser.add_argument('--output-root', type=Path, required=True, help='Receives DREAMER/*.npz')
    args = parser.parse_args()
    if not args.source.exists():
        raise FileNotFoundError(args.source)
    common.OUT = args.output_root
    dreamer = loadmat(args.source, variable_names=["DREAMER"], struct_as_record=False, squeeze_me=True)["DREAMER"]
    if int(dreamer.noOfSubjects) != 23 or int(dreamer.noOfVideoSequences) != 18:
        raise ValueError("Unexpected DREAMER dimensions")
    sfreq = float(dreamer.EEG_SamplingRate)
    electrodes = [str(value) for value in np.asarray(dreamer.EEG_Electrodes).reshape(-1)]
    if electrodes != CHANNELS:
        raise ValueError(f"Unexpected channel order: {electrodes}")

    manifest = []
    for subject_index, subject in enumerate(np.asarray(dreamer.Data).reshape(-1), start=1):
        subject_id = f"sub{subject_index:02d}"
        trials = []
        info = []
        stimuli = np.asarray(subject.EEG.stimuli, dtype=object).reshape(-1)
        baseline = np.asarray(subject.EEG.baseline, dtype=object).reshape(-1)
        valence = np.asarray(subject.ScoreValence, dtype=np.float32).reshape(-1)
        arousal = np.asarray(subject.ScoreArousal, dtype=np.float32).reshape(-1)
        dominance = np.asarray(subject.ScoreDominance, dtype=np.float32).reshape(-1)
        if not (len(stimuli) == len(baseline) == len(valence) == len(arousal) == len(dominance) == 18):
            raise ValueError(f"Unexpected trial count for {subject_id}")
        for trial_index, signal in enumerate(stimuli):
            signal = np.asarray(signal, dtype=np.float64)
            if signal.ndim != 2 or signal.shape[1] != len(CHANNELS):
                raise ValueError(f"Unexpected EEG shape for {subject_id} trial {trial_index + 1}: {signal.shape}")
            trials.append(common.process_trial(signal.T, sfreq))
            info.append({
                "video_id": trial_index + 1,
                "presentation_trial": trial_index + 1,
                "stimulus_duration_s": float(signal.shape[0] / sfreq),
                "retained_start_s": float(signal.shape[0] / sfreq - 30.0),
                "baseline_duration_s": float(np.asarray(baseline[trial_index]).shape[0] / sfreq),
            })
        scores = np.column_stack([valence, arousal, dominance]).astype(np.float32)
        meta = common.save(
            "DREAMER",
            subject_id,
            trials,
            scores,
            {
                "channels": CHANNELS,
                "score_columns": SCORE_COLUMNS,
                "source_sfreq": sfreq,
                "video_info": info,
                "source_archive": args.source.name,
                "unit_policy": "DREAMER EEG values treated as microvolts; 1-45 Hz filtering removes device DC offset.",
                "baseline_policy": "Provided baseline recordings retained in source metadata but not subtracted; pipeline matches FACED stimulus-only processing.",
                "timing_policy": "Each video stimulus is one trial; final 30 seconds retained.",
            },
        )
        row = {
            "dataset": "DREAMER",
            "subject": subject_id,
            "status": "ok",
            "trials": int(meta["trials"]),
            "windows": int(meta["windows"]),
            "quality_ok_windows": int(meta["quality_ok_windows"]),
        }
        manifest.append(row)
        print(json.dumps(row, ensure_ascii=False), flush=True)

    (args.output_root / "manifest_DREAMER.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"DREAMER preprocessing complete: {len(manifest)} subjects", flush=True)


if __name__ == "__main__":
    main()
