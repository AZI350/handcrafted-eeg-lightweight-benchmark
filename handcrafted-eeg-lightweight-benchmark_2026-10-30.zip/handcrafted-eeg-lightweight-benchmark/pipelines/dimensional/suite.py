"""Reproduce the seven DREAMER/FACED experiment groups.

The command prints a complete plan by default. Add ``--execute`` only after
the prepared data and the smoke test have been checked.
"""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PAPER_SEEDS = [173, 941, 2027, 4099, 7919]


def jobs(experiment):
    if experiment == 1:
        return [('main', 1, ['--methods', 'baseline', 'feature_only', 'direct_fusion', 'aux_supervision',
                             '--features', 'dtcwt_energy', 'hjorth', 'band_ratios',
                             '--feature-sets', 'dtcwt_energy', 'hjorth', 'band_ratios'])]
    if experiment == 2:
        return [('trial_earlystop', 1, ['--methods', 'baseline', 'direct_fusion',
                                        '--selection-metric', 'trial_macro_f1'])]
    if experiment == 3:
        return [('combinations', 1, ['--methods', 'feature_only', 'direct_fusion', 'aux_supervision',
                                     '--features', 'dtcwt_energy', 'hjorth', 'band_ratios',
                                     '--feature-sets', 'hjorth+band_ratios', 'dtcwt_energy+hjorth',
                                     'dtcwt_energy+band_ratios', 'dtcwt_energy+hjorth+band_ratios'])]
    if experiment == 4:
        return [(f'lambda_{value}', 1, ['--methods', 'aux_supervision', '--aux-lambda', str(value)])
                for value in (0.01, 0.03, 0.3, 1.0)]
    if experiment == 5:
        return [(backbone, 1, ['--methods', 'baseline', 'direct_fusion', '--backbone', backbone])
                for backbone in ('resnet1d', 'mobilenet1d', 'squeezenet1d')]
    if experiment == 6:
        return [(f'window_{seconds}s', seconds, ['--methods', 'baseline', 'direct_fusion'])
                for seconds in (2, 4)]
    if experiment == 7:
        return [(mode, 1, ['--methods', 'baseline', 'direct_fusion', '--channel-mode', mode])
                for mode in ('alternate', 'frontal')]
    raise ValueError(experiment)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--experiments', nargs='+', type=int, default=list(range(1, 8)))
    parser.add_argument('--datasets', nargs='+', choices=['DREAMER', 'FACED'], default=['DREAMER', 'FACED'])
    parser.add_argument('--targets', nargs='+', choices=['valence', 'arousal'], default=['valence', 'arousal'])
    parser.add_argument('--protocols', nargs='+', choices=['subject_dependent', 'subject_independent'],
                        default=['subject_dependent', 'subject_independent'])
    parser.add_argument('--seeds', nargs='+', type=int, default=PAPER_SEEDS)
    parser.add_argument('--windows-root', type=Path, required=True,
                        help='Directory containing window_1s, window_2s, and window_4s')
    parser.add_argument('--output-root', type=Path, default=HERE / 'results')
    parser.add_argument('--batch-size', type=int, default=256)
    parser.add_argument('--cpu-threads', type=int, default=4)
    parser.add_argument('--smoke', action='store_true')
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()

    out = args.output_root / ('smoke' if args.smoke else 'formal')
    seeds = args.seeds[:1] if args.smoke else args.seeds
    plan = []
    for experiment in args.experiments:
        for dataset in args.datasets:
            for target in args.targets:
                for protocol in args.protocols:
                    for tag, window, extra in jobs(experiment):
                        name = f'e{experiment}_{tag}_{dataset}_{target}_{protocol}'
                        command = [
                            sys.executable, '-u', str(HERE / 'run_experiment.py'),
                            '--datasets', dataset, '--target', target, '--protocol', protocol,
                            '--data-root', str(args.windows_root / f'window_{window}s'),
                            '--output-root', str(out / f'exp{experiment}'), '--run-name', name,
                            '--features', 'dtcwt_energy', '--feature-sets', 'dtcwt_energy',
                            '--folds', '5', '--validation-subjects', '4' if dataset == 'DREAMER' else '20',
                            '--split-seed', '20261013', '--seeds', *map(str, seeds),
                            '--batch-size', str(args.batch_size), '--cpu-threads', str(args.cpu_threads),
                            *extra,
                        ]
                        if args.smoke:
                            command += ['--fold-indices', '1', '--max-epochs', '1']
                        plan.append({'experiment': experiment, 'name': name, 'command': command})

    out.mkdir(parents=True, exist_ok=True)
    (out / 'last_plan.json').write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding='utf-8')
    for row in plan:
        print(' '.join(map(str, row['command'])), flush=True)
    print(f'{len(plan)} command groups. ' + ('Executing.' if args.execute else 'Plan only.'), flush=True)
    if not args.execute:
        return

    for dataset, expected in [('DREAMER', 23), ('FACED', 123)]:
        if dataset not in args.datasets:
            continue
        for window in {job[1] for experiment in args.experiments for job in jobs(experiment)}:
            actual = len(list((args.windows_root / f'window_{window}s' / dataset).glob('*.npz')))
            if actual != expected:
                raise SystemExit(f'{dataset}/{window}s: expected {expected} subjects, found {actual}')

    for row in plan:
        if shutil.disk_usage(out).free < 5 * 1024**3:
            raise SystemExit('Less than 5 GiB free before the next group')
        log = out / 'logs' / f"{row['name']}.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open('a', encoding='utf-8') as handle:
            process = subprocess.Popen(row['command'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                       text=True, encoding='utf-8', errors='replace', bufsize=1)
            for line in process.stdout:
                print(line, end='', flush=True)
                handle.write(line)
                handle.flush()
            if process.wait() != 0:
                raise SystemExit(f"FAILED {row['name']}; see {log}")
    print('Requested dimensional experiments complete.', flush=True)


if __name__ == '__main__':
    main()
