"""Audit the real manuscript source-data tables before figure generation."""
import csv
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
EXPECTED_ROWS = {
    'confusion_matrices_long.csv': 66,
    'deployment_cost.csv': 6,
    'fine_grained_fusion_delta_summary.csv': 14,
    'fine_grained_fusion_deltas.csv': 70,
    'fine_grained_runs.csv': 1400,
    'fine_grained_seed_means.csv': 280,
    'robustness_summary.csv': 9,
}

for name, expected in EXPECTED_ROWS.items():
    path = DATA / name
    with path.open(encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    if len(rows) != expected:
        raise RuntimeError(f'{name}: expected {expected} rows, found {len(rows)}')

audit = json.loads((DATA / 'confusion_matrices_audit.json').read_text(encoding='utf-8-sig'))
if len(audit) != 7 or any(item['n_runs'] != 25 for item in audit):
    raise RuntimeError('Confusion-matrix audit must contain seven tasks and 25 runs per task')

for path in DATA.iterdir():
    if path.is_file():
        text = path.read_text(encoding='utf-8-sig', errors='ignore')
        if re.search(r'[A-Za-z]:\\\\|/root/|wxid_|sylu\.edu', text):
            raise RuntimeError(f'Local/private path leaked into {path.name}')
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        print(f'{digest}  data/{path.name}')

print('Source-data audit passed. Values are archived experiment outputs, not simulated data.')
