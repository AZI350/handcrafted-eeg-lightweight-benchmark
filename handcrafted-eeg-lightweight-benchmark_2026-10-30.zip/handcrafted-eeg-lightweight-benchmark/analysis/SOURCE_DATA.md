# Manuscript source data

The files in this directory are the real CSV/JSON inputs used by `make_figures.py` and `origin_generate_figures.py`. No simulated observations are included.

| File | Rows | Meaning |
|---|---:|---|
| `fine_grained_runs.csv` | 1400 | Fold/seed records for the four participation modes in the common DTCWT comparison |
| `fine_grained_seed_means.csv` | 280 | Fold-averaged seed means |
| `fine_grained_fusion_deltas.csv` | 70 | Seed-paired direct-fusion minus EEG-only differences |
| `fine_grained_fusion_delta_summary.csv` | 14 | Task/protocol summaries and intervals |
| `confusion_matrices_long.csv` | 66 | Row-normalized cells from seven aggregated trial confusion matrices |
| `confusion_matrices_audit.json` | 7 tasks | Integer counts and audit metadata; 25 saved runs per task |
| `robustness_summary.csv` | 9 | Clean, 10-dB-noise, and 25%-channel-dropout summaries for the SEED series |
| `deployment_cost.csv` | 6 | Representative parameter and measured processing-time records |

Run `python analysis/verify_source_data.py` before regenerating figures. The script checks exact row counts, the seven confusion-matrix tasks, and accidental local-path leakage, then prints SHA-256 hashes.
