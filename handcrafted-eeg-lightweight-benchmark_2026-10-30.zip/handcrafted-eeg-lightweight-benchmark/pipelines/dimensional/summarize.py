import argparse,json,collections
from pathlib import Path
import numpy as np
from scipy.stats import t

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
 groups=collections.defaultdict(dict)
 for path in (a.root/'final').rglob('metrics.json'):
  r=json.loads(path.read_text());name=path.relative_to(a.root/'final').parts[0]
  tag=name.split('_f'+str(r['fold'])+'_',1)[1]
  if tag=='references':tag=r['method']
  key=(r['dataset'],r['target'],r['protocol'],tag)
  groups[key][(r['seed'],r['fold'])]=r
 lines=['# Server experiment summary','','Trial metrics (%); paired seed CI after fold averaging. Complete five-fold/five-seed comparisons only.','','| Dataset | Target | Protocol | Method | N | F1 | Accuracy | Difference vs selected (95% CI) |','|---|---|---|---|---:|---:|---:|---|']
 for k,items in sorted(groups.items()):
  ref=groups.get((*k[:3],'selected'),{});ci='incomplete'
  if len(items)==25 and set(items)==set(ref):
   seeds=sorted({s for s,f in items});v=np.array([np.mean([(items[s,f]['test']['trial']['overall']['macro_f1']-ref[s,f]['test']['trial']['overall']['macro_f1'])*100 for f in range(1,6)]) for s in seeds]);half=t.ppf(.975,4)*v.std(ddof=1)/np.sqrt(5)
   ci=f'{v.mean():+.3f} [{v.mean()-half:+.3f}, {v.mean()+half:+.3f}]'
  if k[-1]=='classification_control':
   for ident,r in items.items():
    if ident in ref:
     for field in ['stage1_updates','stage2_updates']:assert r[field]==ref[ident][field],(k,ident,field)
  f1=np.mean([r['test']['trial']['overall']['macro_f1'] for r in items.values()])*100
  acc=np.mean([r['test']['trial']['overall']['accuracy'] for r in items.values()])*100
  lines.append('| '+' | '.join(k)+f' | {len(items)} | {f1:.3f} | {acc:.3f} | {ci} |')
 (a.root/'SUMMARY.md').write_text('\n'.join(lines),encoding='utf-8')
 profiles=[json.loads(p.read_text()) for p in (a.root/'final').rglob('profile_*.json')]
 (a.root/'profiles.json').write_text(json.dumps(profiles,indent=2))
 print('Saved SUMMARY.md and profiles.json')

if __name__=='__main__':main()
