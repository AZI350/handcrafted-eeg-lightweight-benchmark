"""Unified CLI for handcrafted-feature EEG experiments.

Examples:
  python run_experiment.py --list-options
  python run_experiment.py --datasets FACED --methods baseline feature_only direct_fusion aux_supervision \
      --features relative_power hjorth time_stats --ablation both --dry-run
  python run_experiment.py --datasets FACED DENS --methods direct_fusion aux_supervision \
      --feature-sets relative_power+spectral_shape all --seeds 173 941 --folds 5
"""
from __future__ import annotations

import argparse
import csv
import gc
import hashlib
import json
import os
import random
import tempfile
import time
import traceback
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")

import numpy as np
from scipy.signal import welch
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    balanced_accuracy_score,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_recall_fscore_support,
    precision_score,
    recall_score,
    roc_auc_score,
)
import torch
from torch import nn


HERE = Path(__file__).resolve().parent
PROJECT_ROOT = HERE
DEFAULT_DATA_ROOT = HERE / "data"
DEFAULT_OUTPUT_ROOT = HERE / "outputs"

METHODS = ("baseline", "feature_only", "direct_fusion", "aux_supervision")
BACKBONES = ("compact", "resnet1d", "mobilenet1d", "squeezenet1d")
FEATURES = (
    "relative_power",
    "absolute_power",
    "band_ratios",
    "hjorth",
    "time_stats",
    "spectral_shape",
    "stft_power",
)
FEATURE_DOMAINS = {
    "frequency": ("relative_power", "absolute_power", "band_ratios", "spectral_shape"),
    "time": ("hjorth", "time_stats"),
    "time_frequency": ("stft_power",),
}
DATASET_SPECS = {
    "FACED": {"valence": (9, 3.5), "arousal": (8, 3.5)},
    "DENS": {"valence": (0, 5.0), "arousal": (1, 5.0)},
    "DREAMER": {"valence": (0, 3.0), "arousal": (1, 3.0)},
}
BANDS = (("theta", 4.0, 8.0), ("alpha", 8.0, 14.0), ("beta", 14.0, 30.0), ("gamma", 30.0, 45.0))


def channel_indices(channel_names: np.ndarray, mode: str) -> np.ndarray:
    names = [str(value) for value in channel_names.tolist()]
    if mode == "all":
        return np.arange(len(names), dtype=np.int64)
    if mode == "alternate":
        return np.arange(0, len(names), 2, dtype=np.int64)
    if mode == "frontal":
        indices = [index for index, name in enumerate(names) if name.upper().startswith(("FP", "AF", "F", "FC"))]
        if not indices:
            raise ValueError(f"No frontal channels found in {names}")
        return np.asarray(indices, dtype=np.int64)
    raise ValueError(f"Unknown channel mode: {mode}")


def json_dump(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # Windows readers may briefly open the destination without delete sharing.
    # Keep the old JSON intact until replacement succeeds; never truncate it.
    payload = json.dumps(value, ensure_ascii=False, indent=2)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                     prefix=path.name + ".", suffix=".tmp", delete=False) as handle:
        temporary = Path(handle.name)
        handle.write(payload)
    deadline = time.monotonic() + 10.0
    try:
        while True:
            try:
                temporary.replace(path)
                break
            except PermissionError:
                if time.monotonic() >= deadline:
                    raise
                time.sleep(0.1)
    finally:
        temporary.unlink(missing_ok=True)


def slug_feature_set(names: Iterable[str]) -> str:
    names = tuple(names)
    joined = "+".join(names) if names else "none"
    if len(joined) > 80:
        digest = hashlib.sha256(joined.encode()).hexdigest()[:10]
        return f"all_{len(names):02d}_{digest}"
    return joined


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def feature_description(channels: int) -> dict:
    return {
        "relative_power": {
            "dimensions": channels * 4,
            "definition": "Welch PSD各通道theta/alpha/beta/gamma功率除以1-45 Hz总功率",
        },
        "absolute_power": {
            "dimensions": channels * 4,
            "definition": "Welch PSD各通道四频段绝对功率取自然对数",
        },
        "band_ratios": {
            "dimensions": channels * 3,
            "definition": "各通道theta/alpha、beta/alpha、(theta+alpha)/(beta+gamma)，随后取自然对数",
        },
        "hjorth": {
            "dimensions": channels * 3,
            "definition": "各通道Activity、Mobility、Complexity",
        },
        "time_stats": {
            "dimensions": channels * 6,
            "definition": "各通道均值、标准差、峰峰值、偏度、超额峰度、平均绝对一阶差分",
        },
        "spectral_shape": {
            "dimensions": channels * 4,
            "definition": "1-45 Hz归一化谱的谱熵、谱质心、谱扩散和95%谱边缘频率",
        },
        "stft_power": {
            "dimensions": channels * 16,
            "definition": "每秒分为4个无重叠时间片，各片计算四频段相对功率",
        },
    }


def compute_features(x: np.ndarray, sfreq: int, selected: set[str]) -> dict[str, np.ndarray]:
    """Compute selected atomic feature groups for [window, channel, sample]."""
    eps = np.float32(1e-12)
    output: dict[str, np.ndarray] = {}
    spectral_needed = bool(selected & {"relative_power", "absolute_power", "band_ratios", "spectral_shape"})
    band_values = None
    if spectral_needed:
        frequency, psd = welch(
            x,
            fs=sfreq,
            window="hann",
            nperseg=sfreq,
            noverlap=0,
            nfft=sfreq,
            detrend="constant",
            scaling="density",
            axis=-1,
        )
        total_mask = (frequency >= 1) & (frequency < 45)
        total = psd[..., total_mask].sum(-1)
        band_values = np.stack(
            [psd[..., (frequency >= low) & (frequency < high)].sum(-1) for _, low, high in BANDS],
            axis=-1,
        )
        if "relative_power" in selected:
            output["relative_power"] = (band_values / np.maximum(total[..., None], eps)).reshape(len(x), -1).astype(np.float32)
        if "absolute_power" in selected:
            output["absolute_power"] = np.log(np.maximum(band_values, eps)).reshape(len(x), -1).astype(np.float32)
        if "band_ratios" in selected:
            theta, alpha, beta, gamma = [band_values[..., index] for index in range(4)]
            ratios = np.stack(
                [theta / np.maximum(alpha, eps), beta / np.maximum(alpha, eps), (theta + alpha) / np.maximum(beta + gamma, eps)],
                axis=-1,
            )
            output["band_ratios"] = np.log(np.maximum(ratios, eps)).reshape(len(x), -1).astype(np.float32)
        if "spectral_shape" in selected:
            local_frequency = frequency[total_mask]
            local_psd = psd[..., total_mask]
            probability = local_psd / np.maximum(local_psd.sum(-1, keepdims=True), eps)
            entropy = -(probability * np.log(np.maximum(probability, eps))).sum(-1) / np.log(probability.shape[-1])
            centroid = (probability * local_frequency).sum(-1)
            spread = np.sqrt((probability * np.square(local_frequency - centroid[..., None])).sum(-1))
            cumulative = np.cumsum(probability, axis=-1)
            edge_index = np.argmax(cumulative >= 0.95, axis=-1)
            edge95 = local_frequency[edge_index]
            output["spectral_shape"] = np.stack([entropy, centroid, spread, edge95], axis=-1).reshape(len(x), -1).astype(np.float32)

    if selected & {"hjorth", "time_stats"}:
        dx = np.diff(x, axis=-1)
    if "hjorth" in selected:
        ddx = np.diff(dx, axis=-1)
        variance0 = np.var(x, axis=-1)
        variance1 = np.var(dx, axis=-1)
        variance2 = np.var(ddx, axis=-1)
        mobility = np.sqrt(variance1 / np.maximum(variance0, eps))
        complexity = np.sqrt(variance2 / np.maximum(variance1, eps)) / np.maximum(mobility, eps)
        output["hjorth"] = np.stack([variance0, mobility, complexity], axis=-1).reshape(len(x), -1).astype(np.float32)
    if "time_stats" in selected:
        mean = x.mean(-1)
        centered = x - mean[..., None]
        std = np.maximum(x.std(-1), eps)
        standardized = centered / std[..., None]
        skewness = np.mean(standardized ** 3, axis=-1)
        excess_kurtosis = np.mean(standardized ** 4, axis=-1) - 3.0
        peak_to_peak = np.ptp(x, axis=-1)
        line_length = np.mean(np.abs(dx), axis=-1)
        output["time_stats"] = np.stack(
            [mean, std, peak_to_peak, skewness, excess_kurtosis, line_length], axis=-1
        ).reshape(len(x), -1).astype(np.float32)
    if "stft_power" in selected:
        temporal = []
        boundaries = np.linspace(0, x.shape[-1], 5, dtype=int)
        for segment_index in range(4):
            segment = x[..., boundaries[segment_index]:boundaries[segment_index + 1]]
            window = np.hanning(segment.shape[-1]).astype(np.float32)
            spectrum = np.abs(np.fft.rfft(segment * window, axis=-1)) ** 2
            local_frequency = np.fft.rfftfreq(segment.shape[-1], d=1.0 / sfreq)
            denominator = spectrum[..., (local_frequency >= 1) & (local_frequency < 45)].sum(-1)
            temporal.append(np.stack([
                spectrum[..., (local_frequency >= low) & (local_frequency < high)].sum(-1) / np.maximum(denominator, eps)
                for _, low, high in BANDS
            ], axis=-1))
        output["stft_power"] = np.stack(temporal, axis=-2).reshape(len(x), -1).astype(np.float32)

    for name, values in output.items():
        if not np.isfinite(values).all():
            raise ValueError(f"Non-finite values in feature group {name}")
    return output


# The entry stays in this file; transform implementations live in a small library so
# every CLI mode uses the same fixed definitions and dimensions.
from feature_library import (  # noqa: E402
    FEATURES as COMPLETE_FEATURES,
    FEATURE_DOMAINS as COMPLETE_FEATURE_DOMAINS,
    compute_features as compute_complete_features,
    dependency_versions,
    feature_description as complete_feature_description,
)

FEATURES = COMPLETE_FEATURES
FEATURE_DOMAINS = COMPLETE_FEATURE_DOMAINS
feature_description = complete_feature_description
compute_features = compute_complete_features
FEATURE_CACHE_VERSION = "complete-handcrafted-v1"


@dataclass(frozen=True)
class DatasetAdapter:
    name: str
    root: Path
    target: str
    threshold_override: float | None
    channel_mode: str = "all"

    @property
    def subject_files(self) -> list[Path]:
        return sorted((self.root / self.name).glob("*.npz"))

    @property
    def threshold(self) -> float:
        return self.threshold_override if self.threshold_override is not None else DATASET_SPECS[self.name][self.target][1]

    @property
    def score_column(self) -> int:
        return DATASET_SPECS[self.name][self.target][0]

    def inspect(self) -> dict:
        files = self.subject_files
        if not files:
            raise FileNotFoundError(f"No NPZ files in {self.root / self.name}")
        sample = np.load(files[0], allow_pickle=False)
        return {
            "dataset": self.name,
            "subjects": len(files),
            "channels": len(channel_indices(sample["channel_names"], self.channel_mode)),
            "channel_mode": self.channel_mode,
            "channel_names": sample["channel_names"][channel_indices(sample["channel_names"], self.channel_mode)].tolist(),
            "samples_per_window": int(sample["eeg_uv"].shape[2]),
            "sampling_rate_hz": int(sample["sfreq"]),
            "target": self.target,
            "score_column": self.score_column,
            "threshold": self.threshold,
            "quality_filter": True,
        }

    def load_subject(self, path: Path, selected_features: set[str], cache_root: Path) -> dict:
        source_identity = path.name + "|" + str(path.stat().st_size) + "|" + str(path.stat().st_mtime_ns)
        source = np.load(path, allow_pickle=False)
        keep = source["quality_ok"]
        x = source["eeg_uv"][keep].astype(np.float32, copy=True)
        if self.channel_mode != "all":
            x = x[:, channel_indices(source["channel_names"], self.channel_mode), :]
            source_identity += "|channels=" + self.channel_mode
        trial = source["trial_index"][keep]
        y = (source["scores"][trial, self.score_column] > self.threshold).astype(np.int64)
        features = {}
        missing = set()
        cache_files = {}
        for name in selected_features:
            cache_key = hashlib.sha256((source_identity + "|" + FEATURE_CACHE_VERSION + "|" + name).encode()).hexdigest()[:16]
            cache_file = cache_root / self.name / name / f"{path.stem}_{cache_key}.npz"
            cache_files[name] = cache_file
            if cache_file.exists():
                with np.load(cache_file, allow_pickle=False) as cached:
                    features[name] = cached[name]
            else:
                missing.add(name)
        if missing:
            print(f"  EXTRACT {self.name}/{path.stem}: {', '.join(sorted(missing))}", flush=True)
            extracted = compute_features(
                x,
                int(source["sfreq"]),
                missing,
                progress=lambda message: print(f"    [{path.stem}] {message}", flush=True),
            )
            for name, values in extracted.items():
                cache_file = cache_files[name]
                cache_file.parent.mkdir(parents=True, exist_ok=True)
                np.savez_compressed(cache_file, **{name: values})
                features[name] = values
        result = {
            "x": x,
            "y": y,
            "subject": np.full(len(y), path.stem, dtype=f"<U{max(16, len(path.stem))}"),
            "trial": trial.astype(np.int16),
            "window": source["window_in_trial"][keep].astype(np.int16),
        }
        result.update(features)
        return result


def make_subject_independent_splits(subjects: list[str], folds: int, split_seed: int, validation_subjects: int) -> list[dict[str, list[str]]]:
    if len(subjects) < 4:
        raise ValueError("At least four subjects are required")
    folds = min(folds, len(subjects))
    shuffled = np.asarray(subjects)
    np.random.default_rng(split_seed).shuffle(shuffled)
    test_parts = np.array_split(shuffled, folds)
    splits = []
    for index, test in enumerate(test_parts):
        pool = np.asarray([subject for subject in shuffled if subject not in set(test)])
        np.random.default_rng(split_seed + 100 + index).shuffle(pool)
        maximum_validation = max(1, len(pool) - 2)
        adaptive_default = max(1, len(pool) // 5)
        requested = validation_subjects if validation_subjects > 0 else adaptive_default
        validation_count = min(requested, maximum_validation)
        splits.append({
            "train": pool[validation_count:].tolist(),
            "val": pool[:validation_count].tolist(),
            "test": test.tolist(),
        })
    return splits


def make_subject_dependent_splits(adapter: DatasetAdapter, folds: int, split_seed: int) -> list[dict[str, dict[str, list[int]]]]:
    """Trial-grouped within-subject CV; no trial contributes windows to two splits."""
    if folds < 3:
        raise ValueError("Subject-dependent protocol requires at least three folds")
    per_subject_parts: dict[str, list[list[int]]] = {}
    for subject_index, path in enumerate(adapter.subject_files):
        with np.load(path, allow_pickle=False) as source:
            available = np.unique(source["trial_index"][source["quality_ok"]]).astype(int)
            labels = (source["scores"][available, adapter.score_column] > adapter.threshold).astype(np.int64)
        parts = [[] for _ in range(folds)]
        for label in (0, 1):
            class_trials = available[labels == label].copy()
            rng = np.random.default_rng(split_seed + 1009 * subject_index + 97 * label)
            rng.shuffle(class_trials)
            for part_index, values in enumerate(np.array_split(class_trials, folds)):
                parts[part_index].extend(int(value) for value in values)
        per_subject_parts[path.stem] = [sorted(values) for values in parts]

    splits = []
    for fold_index in range(folds):
        validation_index = (fold_index + 1) % folds
        split = {"train": {}, "val": {}, "test": {}}
        for subject, parts in per_subject_parts.items():
            split["test"][subject] = parts[fold_index]
            split["val"][subject] = parts[validation_index]
            split["train"][subject] = sorted(
                trial for index, values in enumerate(parts)
                if index not in (fold_index, validation_index)
                for trial in values
            )
        splits.append(split)
    return splits


def build_feature_sets(selected: list[str], ablation: str, explicit: list[str] | None) -> list[tuple[str, ...]]:
    if explicit:
        sets = []
        for specification in explicit:
            names = tuple(selected) if specification == "all" else tuple(part for part in specification.split("+") if part)
            unknown = set(names) - set(FEATURES)
            if unknown:
                raise ValueError(f"Unknown features in --feature-sets: {sorted(unknown)}")
            sets.append(names)
    else:
        full = tuple(selected)
        sets = [full]
        if ablation in ("single", "both"):
            sets.extend((name,) for name in selected)
        if ablation in ("leave_one_out", "both") and len(selected) > 1:
            sets.extend(tuple(name for name in selected if name != removed) for removed in selected)
        if ablation == "domain":
            for domain_features in FEATURE_DOMAINS.values():
                present = tuple(name for name in domain_features if name in selected)
                if present:
                    sets.append(present)
            for domain_features in FEATURE_DOMAINS.values():
                remaining = tuple(name for name in selected if name not in domain_features)
                if remaining:
                    sets.append(remaining)
    unique = []
    seen = set()
    for item in sets:
        canonical = tuple(name for name in FEATURES if name in item)
        if canonical and canonical not in seen:
            seen.add(canonical)
            unique.append(canonical)
    return unique


class EEGBackbone(nn.Module):
    def __init__(self, channels: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(channels, 32, 15, stride=2, padding=7, bias=False),
            nn.BatchNorm1d(32), nn.ELU(), nn.Dropout(0.25),
            nn.Conv1d(32, 32, 15, stride=2, padding=7, groups=32, bias=False),
            nn.Conv1d(32, 64, 1, bias=False), nn.BatchNorm1d(64), nn.ELU(), nn.Dropout(0.25),
            nn.Conv1d(64, 64, 7, stride=2, padding=3, groups=64, bias=False),
            nn.Conv1d(64, 64, 1, bias=False), nn.BatchNorm1d(64), nn.ELU(),
            nn.AdaptiveAvgPool1d(1), nn.Flatten(),
        )

    def forward(self, x):
        return self.net(x)


class ExperimentNet(nn.Module):
    def __init__(self, method: str, channels: int, feature_dim: int, backbone: str = "compact"):
        super().__init__()
        self.method = method
        self.backbone = EEGBackbone(channels) if method != "feature_only" else None
        if method != "feature_only" and backbone != "compact":
            from comparison_backbones import build_backbone
            self.backbone = build_backbone(backbone, channels)
        if method == "feature_only":
            self.feature_encoder = nn.Sequential(nn.Linear(feature_dim, 128), nn.ELU(), nn.Dropout(0.25), nn.Linear(128, 64), nn.ELU())
            self.classifier = nn.Linear(64, 2)
        elif method == "direct_fusion":
            self.feature_encoder = nn.Sequential(nn.Linear(feature_dim, 64), nn.ELU(), nn.Dropout(0.25))
            self.classifier = nn.Linear(128, 2)
        else:
            self.feature_encoder = None
            self.classifier = nn.Linear(64, 2)
        self.auxiliary = nn.Sequential(nn.Linear(64, 128), nn.ELU(), nn.Linear(128, feature_dim)) if method == "aux_supervision" else None

    def encode(self, x, features=None):
        if self.method == "feature_only":
            representation = self.feature_encoder(features)
        else:
            representation = self.backbone(x)
        if self.method == "direct_fusion":
            representation = torch.cat([representation, self.feature_encoder(features)], dim=1)
        return representation

    def forward(self, x, features=None):
        representation = self.encode(x, features)
        logits = self.classifier(representation)
        auxiliary = self.auxiliary(representation) if self.auxiliary is not None else None
        return logits, auxiliary


def safe_auc(function, y, probability):
    return float(function(y, probability)) if len(np.unique(y)) == 2 else None


def finite_or_none(value):
    value = float(value)
    return value if np.isfinite(value) else None


def core_metrics(y: np.ndarray, prediction: np.ndarray, probability: np.ndarray) -> dict:
    # A subject or trial set may contain only one class. These metrics remain useful
    # with fixed labels=[0,1], while sklearn's warnings would otherwise flood the terminal.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        precision, recall, f1, support = precision_recall_fscore_support(y, prediction, labels=[0, 1], zero_division=0)
        matrix = confusion_matrix(y, prediction, labels=[0, 1])
        accuracy = accuracy_score(y, prediction)
        balanced_accuracy = balanced_accuracy_score(y, prediction)
        macro_f1 = f1_score(y, prediction, labels=[0, 1], average="macro", zero_division=0)
        weighted_f1 = f1_score(y, prediction, labels=[0, 1], average="weighted", zero_division=0)
        micro_f1 = f1_score(y, prediction, labels=[0, 1], average="micro", zero_division=0)
        macro_precision = precision_score(y, prediction, labels=[0, 1], average="macro", zero_division=0)
        macro_recall = recall_score(y, prediction, labels=[0, 1], average="macro", zero_division=0)
        kappa = cohen_kappa_score(y, prediction)
        mcc = matthews_corrcoef(y, prediction)
    tn, fp, fn, tp = matrix.ravel()
    return {
        "accuracy": float(accuracy),
        "balanced_accuracy": float(balanced_accuracy),
        "macro_f1": float(macro_f1),
        "weighted_f1": float(weighted_f1),
        "micro_f1": float(micro_f1),
        "macro_precision": float(macro_precision),
        "macro_recall": float(macro_recall),
        "specificity": float(tn / max(tn + fp, 1)),
        "sensitivity": float(tp / max(tp + fn, 1)),
        "cohen_kappa": finite_or_none(kappa),
        "mcc": finite_or_none(mcc),
        "roc_auc": safe_auc(roc_auc_score, y, probability),
        "pr_auc": safe_auc(average_precision_score, y, probability),
        "confusion_matrix": matrix.tolist(),
        "per_class": {
            "low": {"precision": float(precision[0]), "recall": float(recall[0]), "f1": float(f1[0]), "support": int(support[0])},
            "high": {"precision": float(precision[1]), "recall": float(recall[1]), "f1": float(f1[1]), "support": int(support[1])},
        },
    }


def grouped_metrics(y, prediction, probability, groups) -> dict:
    rows = []
    for group in np.unique(groups):
        mask = groups == group
        item = core_metrics(y[mask], prediction[mask], probability[mask])
        item["group"] = str(group)
        item["samples"] = int(mask.sum())
        rows.append(item)
    aggregate_keys = ("accuracy", "balanced_accuracy", "macro_f1", "weighted_f1", "macro_precision", "macro_recall", "cohen_kappa", "mcc")
    means = {}
    for key in aggregate_keys:
        values = [row[key] for row in rows if row[key] is not None and np.isfinite(row[key])]
        means[key] = float(np.mean(values)) if values else None
    return {"mean": means, "per_group": rows}


def trial_metrics(y, prediction, probability, subjects, trials) -> dict:
    trial_y, trial_probability, trial_subject = [], [], []
    for subject in np.unique(subjects):
        subject_mask = subjects == subject
        for trial in np.unique(trials[subject_mask]):
            mask = subject_mask & (trials == trial)
            labels = np.unique(y[mask])
            if len(labels) != 1:
                raise ValueError("A trial contains inconsistent labels")
            trial_y.append(labels[0])
            trial_probability.append(probability[mask].mean())
            trial_subject.append(subject)
    trial_y = np.asarray(trial_y)
    trial_probability = np.asarray(trial_probability)
    trial_prediction = (trial_probability >= 0.5).astype(np.int64)
    trial_subject = np.asarray(trial_subject)
    return {
        "overall": core_metrics(trial_y, trial_prediction, trial_probability),
        "per_subject": grouped_metrics(trial_y, trial_prediction, trial_probability, trial_subject),
        "trials": int(len(trial_y)),
    }


def load_split(
    adapter: DatasetAdapter,
    selection: list[str] | dict[str, list[int]],
    selected_features: set[str],
    cache_root: Path,
    name: str,
) -> dict:
    path_by_stem = {path.stem: path for path in adapter.subject_files}
    selections = list(selection.items()) if isinstance(selection, dict) else [(subject, None) for subject in selection]
    selected_subjects = len(selections)

    # Allocate each split once and fill it subject-by-subject.  FACED contains
    # about 3 GB of float32 windows; retaining a list of all subjects and then
    # concatenating it temporarily doubled that memory and could terminate the
    # process before the first training run.
    total = 0
    for subject, trials in selections:
        if trials is not None and not trials:
            continue
        with np.load(path_by_stem[subject], allow_pickle=False) as source:
            keep = source["quality_ok"]
            if trials is not None:
                keep = keep & np.isin(source["trial_index"], np.asarray(trials, dtype=source["trial_index"].dtype))
            total += int(np.count_nonzero(keep))
    if total == 0:
        raise ValueError(f"Split {name} contains no usable windows")

    output = None
    cursor = 0
    for subject, trials in selections:
        if trials is not None and not trials:
            continue
        piece = adapter.load_subject(path_by_stem[subject], selected_features, cache_root)
        if trials is not None:
            mask = np.isin(piece["trial"], np.asarray(trials, dtype=piece["trial"].dtype))
            if not mask.any():
                continue
            piece = {key: values[mask] for key, values in piece.items()}
        if output is None:
            output = {
                key: np.empty((total, *values.shape[1:]), dtype=values.dtype)
                for key, values in piece.items()
            }
        end = cursor + len(piece["y"])
        for key, values in piece.items():
            output[key][cursor:end] = values
        cursor = end
        del piece
    if output is None or cursor != total:
        raise RuntimeError(f"Split {name} allocation mismatch: expected={total}, loaded={cursor}")
    trial_count = len(set(zip(output["subject"].tolist(), output["trial"].tolist())))
    print(
        f"  loaded {name:5s}: {selected_subjects:3d} subjects, {trial_count:5d} trials, {len(output['y']):7d} windows",
        flush=True,
    )
    return output


def normalize(arrays: dict[str, dict], feature_names: set[str]) -> dict:
    train = arrays["train"]
    eeg_mean = train["x"].mean((0, 2), dtype=np.float64).astype(np.float32)[None, :, None]
    variance = np.zeros(train["x"].shape[1], dtype=np.float64)
    count = 0
    for start in range(0, len(train["x"]), 1024):
        block = train["x"][start:start + 1024]
        variance += np.square(block.astype(np.float64) - eeg_mean).sum((0, 2))
        count += len(block) * block.shape[-1]
    eeg_std = np.maximum(np.sqrt(variance / count).astype(np.float32)[None, :, None], 1e-6)
    feature_stats = {}
    for name in feature_names:
        mean = train[name].mean(0, dtype=np.float64).astype(np.float32)
        std = np.maximum(train[name].std(0, dtype=np.float64).astype(np.float32), 1e-6)
        feature_stats[name] = (mean, std)
    for split in arrays.values():
        # Normalize in-place and keep the complete split in host memory.  Each
        # mini-batch is moved to CUDA in train/evaluate, which keeps VRAM usage
        # bounded by batch size rather than dataset size.
        for start in range(0, len(split["x"]), 1024):
            block = split["x"][start:start + 1024]
            np.subtract(block, eeg_mean, out=block)
            np.divide(block, eeg_std, out=block)
        split["x"] = torch.from_numpy(split["x"])
        split["y_cpu"] = split["y"].copy()
        split["y"] = torch.from_numpy(split["y"])
        for name, (mean, std) in feature_stats.items():
            # Keep atomic feature groups in host memory. Only the combination used by
            # the current run is uploaded, avoiding atomic groups plus concatenated
            # copies occupying GPU memory at the same time.
            split[name] = torch.from_numpy(((split[name] - mean) / std).astype(np.float32))
    return {"eeg_mean": eeg_mean, "eeg_std": eeg_std, "feature_stats": feature_stats}


def joined_features(split: dict, feature_set: tuple[str, ...]):
    if not feature_set:
        return None
    if len(feature_set) == 1:
        return split[feature_set[0]]
    return torch.cat([split[name] for name in feature_set], dim=1)


@torch.no_grad()
def evaluate(model, split: dict, features) -> tuple[dict, np.ndarray, np.ndarray]:
    model.eval()
    predictions, probabilities = [], []
    for start in range(0, len(split["y_cpu"]), 1024):
        end = start + 1024
        batch_features = features[start:end].cuda() if features is not None else None
        logits, _ = model(split["x"][start:end].cuda(), batch_features)
        predictions.append(logits.argmax(1).cpu().numpy())
        probabilities.append(logits.softmax(1)[:, 1].cpu().numpy())
    prediction = np.concatenate(predictions)
    probability = np.concatenate(probabilities)
    y = split["y_cpu"]
    output = {
        "window": core_metrics(y, prediction, probability),
        "subject": grouped_metrics(y, prediction, probability, split["subject"]),
        "trial": trial_metrics(y, prediction, probability, split["subject"], split["trial"]),
    }
    return output, prediction, probability


def train_run(args, adapter_info, fold, method, feature_set, seed, arrays, output_dir):
    metrics_file = output_dir / "metrics.json"
    if metrics_file.exists() and not args.overwrite:
        print(f"SKIP completed fold={fold} seed={seed} method={method} features={slug_feature_set(feature_set)}", flush=True)
        return json.loads(metrics_file.read_text(encoding="utf-8"))
    output_dir.mkdir(parents=True, exist_ok=True)
    train = arrays["train"]
    feature_tensors = {}
    for name, split in arrays.items():
        combined = joined_features(split, feature_set)
        feature_tensors[name] = combined
    feature_dim = 0 if not feature_set else feature_tensors["train"].shape[1]
    seed_everything(seed)
    model = ExperimentNet(method, adapter_info["channels"], feature_dim, args.backbone).cuda()
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    counts = np.bincount(train["y_cpu"], minlength=2)
    weights = torch.tensor(counts.sum() / (2 * counts), dtype=torch.float32, device="cuda")
    classification_loss = nn.CrossEntropyLoss(weight=weights)
    regression_loss = nn.MSELoss() if args.aux_loss == "mse" else nn.SmoothL1Loss(beta=1.0)
    seed_everything(seed + 10000)
    best, stale, history = -1.0, 0, []
    started = time.perf_counter()
    print(
        f"\nSTART dataset={adapter_info['dataset']} target={adapter_info['target']} protocol={args.protocol} "
        f"fold={fold} seed={seed} method={method} features={slug_feature_set(feature_set)}",
        flush=True,
    )
    for epoch in range(1, args.max_epochs + 1):
        model.train()
        order = torch.randperm(len(train["y"]), device="cpu")
        total_sum = class_sum = auxiliary_sum = 0.0
        for start in range(0, len(order), args.batch_size):
            index = order[start:start + args.batch_size]
            batch_features = feature_tensors["train"][index].cuda() if feature_tensors["train"] is not None else None
            batch_x = train["x"][index].cuda()
            batch_y = train["y"][index].cuda()
            optimizer.zero_grad(set_to_none=True)
            logits, auxiliary_prediction = model(batch_x, batch_features)
            class_value = classification_loss(logits, batch_y)
            auxiliary_value = regression_loss(auxiliary_prediction, batch_features) if method == "aux_supervision" else class_value.new_zeros(())
            effective_lambda = args.aux_lambda * (max(0.0, 1.0 - (epoch - 1) / max(1, args.max_epochs - 1)) if args.aux_schedule == "linear_decay" else 1.0)
            loss = class_value + effective_lambda * auxiliary_value
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            optimizer.step()
            total_sum += float(loss.detach()) * len(index)
            class_sum += float(class_value.detach()) * len(index)
            auxiliary_sum += float(auxiliary_value.detach()) * len(index)
        validation, _, _ = evaluate(model, arrays["val"], feature_tensors["val"])
        validation_subject_macro_f1 = validation["subject"]["mean"]["macro_f1"]
        validation_trial_macro_f1 = validation["trial"]["overall"]["macro_f1"]
        if args.selection_metric == "subject_macro_f1":
            score = validation_subject_macro_f1
        else:
            score = validation_trial_macro_f1
        history.append({
            "epoch": epoch,
            "loss": total_sum / len(order),
            "classification_loss": class_sum / len(order),
            "auxiliary_loss": auxiliary_sum / len(order),
            "effective_aux_lambda": effective_lambda,
            "validation_subject_macro_f1": validation_subject_macro_f1,
            "validation_trial_macro_f1": validation_trial_macro_f1,
            "selection_metric": args.selection_metric,
            "selection_score": score,
        })
        json_dump(output_dir / "history.json", history)
        if score > best + args.min_delta:
            best, stale, best_epoch = score, 0, epoch
            torch.save(model.state_dict(), output_dir / "best.pt")
        else:
            stale += 1
        if epoch == 1 or epoch % args.log_every == 0:
            print(
                f"  epoch={epoch:02d} val_subject_macro_f1={validation_subject_macro_f1:.4f} "
                f"val_trial_macro_f1={validation_trial_macro_f1:.4f} "
                f"selected={args.selection_metric}:{score:.4f} best={best:.4f}",
                flush=True,
            )
        if stale >= args.patience:
            break
    model.load_state_dict(torch.load(output_dir / "best.pt", weights_only=True))
    validation, _, _ = evaluate(model, arrays["val"], feature_tensors["val"])
    test, prediction, probability = evaluate(model, arrays["test"], feature_tensors["test"])
    if method == "aux_supervision":
        deployment = ExperimentNet("baseline", adapter_info["channels"], 0, args.backbone).cuda()
        deployment.load_state_dict({key: value for key, value in model.state_dict().items() if not key.startswith("auxiliary.")})
    else:
        deployment = model
    result = {
        "dataset": adapter_info["dataset"],
        "target": adapter_info["target"],
        "protocol": args.protocol,
        "fold": fold,
        "seed": seed,
        "method": method,
        "feature_set": list(feature_set),
        "feature_dimensions": int(feature_dim),
        "selection_metric": args.selection_metric,
        "best_selection_score": float(best),
        "backbone": args.backbone,
        "channel_mode": args.channel_mode,
        "best_epoch": best_epoch,
        "epochs_run": epoch,
        "training_seconds": time.perf_counter() - started,
        "training_parameters": sum(parameter.numel() for parameter in model.parameters()),
        "deployment_parameters": sum(parameter.numel() for parameter in deployment.parameters()),
        "requires_online_features": method in ("feature_only", "direct_fusion"),
        "validation": validation,
        "test": test,
    }
    torch.save(deployment.state_dict(), output_dir / "deploy.pt")
    np.savez_compressed(
        output_dir / "test_predictions.npz",
        y=arrays["test"]["y_cpu"],
        prediction=prediction,
        probability=probability,
        subject=arrays["test"]["subject"],
        trial=arrays["test"]["trial"],
        window=arrays["test"]["window"],
    )
    json_dump(metrics_file, result)
    print(
        f"COMPLETE test_window_acc={test['window']['accuracy']:.4f} "
        f"test_window_macro_f1={test['window']['macro_f1']:.4f} "
        f"test_subject_macro_f1={test['subject']['mean']['macro_f1']:.4f} "
        f"test_trial_macro_f1={test['trial']['overall']['macro_f1']:.4f}",
        flush=True,
    )
    del model, deployment, optimizer
    feature_tensors.clear()
    torch.cuda.empty_cache()
    return result


def summarize(results: list[dict], path: Path) -> None:
    groups = {}
    for result in results:
        key = (result["dataset"], result["target"], result.get("protocol", "subject_independent"), result["method"], slug_feature_set(result["feature_set"]))
        groups.setdefault(key, []).append(result)
    rows = []
    for (dataset, target, protocol, method, feature_set), items in groups.items():
        row = {"dataset": dataset, "target": target, "protocol": protocol, "method": method, "feature_set": feature_set, "runs": len(items)}
        for name, accessor in {
            "window_accuracy": lambda r: r["test"]["window"]["accuracy"],
            "window_balanced_accuracy": lambda r: r["test"]["window"]["balanced_accuracy"],
            "window_macro_f1": lambda r: r["test"]["window"]["macro_f1"],
            "window_weighted_f1": lambda r: r["test"]["window"]["weighted_f1"],
            "window_roc_auc": lambda r: r["test"]["window"]["roc_auc"],
            "window_pr_auc": lambda r: r["test"]["window"]["pr_auc"],
            "window_mcc": lambda r: r["test"]["window"]["mcc"],
            "subject_macro_f1": lambda r: r["test"]["subject"]["mean"]["macro_f1"],
            "subject_accuracy": lambda r: r["test"]["subject"]["mean"]["accuracy"],
            "trial_macro_f1": lambda r: r["test"]["trial"]["overall"]["macro_f1"],
            "trial_accuracy": lambda r: r["test"]["trial"]["overall"]["accuracy"],
        }.items():
            values = [accessor(item) for item in items if accessor(item) is not None]
            row[name + "_mean"] = float(np.mean(values)) if values else None
            row[name + "_sd"] = float(np.std(values, ddof=1)) if len(values) > 1 else 0.0
        row["deployment_parameters"] = items[0]["deployment_parameters"]
        row["requires_online_features"] = items[0]["requires_online_features"]
        rows.append(row)
    rows.sort(key=lambda row: (row["dataset"], -(row["subject_macro_f1_mean"] or -1)))
    json_dump(path / "summary.json", rows)
    if rows:
        with (path / "summary.csv").open("w", newline="", encoding="utf-8-sig") as stream:
            writer = csv.DictWriter(stream, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        description="跨被试EEG实验统一入口：数据集、结合方法、手工特征、消融和训练参数均可从终端选择。",
    )
    parser.add_argument("--datasets", nargs="+", choices=DATASET_SPECS, default=["FACED"])
    parser.add_argument("--target", choices=("valence", "arousal"), default="valence")
    parser.add_argument(
        "--protocol",
        choices=("subject_independent", "subject_dependent"),
        default="subject_independent",
        help="独立受试者划分，或同一受试者内按完整试次划分（不会泄漏窗口）",
    )
    parser.add_argument("--threshold", type=float, help="覆盖数据集默认标签阈值")
    parser.add_argument("--methods", nargs="+", choices=METHODS, default=list(METHODS))
    parser.add_argument("--backbone", choices=BACKBONES, default="compact")
    parser.add_argument("--features", nargs="+", choices=FEATURES, default=list(FEATURES))
    parser.add_argument("--feature-sets", nargs="*", help="显式组合，以+连接；all表示--features全部，例如 relative_power+hjorth all")
    parser.add_argument("--ablation", choices=("none", "single", "leave_one_out", "both", "domain"), default="none")
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--fold-indices", nargs="+", type=int, help="只运行指定的1-based折")
    parser.add_argument("--validation-subjects", type=int, default=20, help="0表示约20%%自适应；小数据集会自动缩减")
    parser.add_argument("--split-seed", type=int, default=20261013)
    parser.add_argument("--seeds", nargs="+", type=int, default=[173])
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--max-epochs", type=int, default=40)
    parser.add_argument("--patience", type=int, default=8)
    parser.add_argument(
        "--selection-metric",
        choices=("subject_macro_f1", "trial_macro_f1"),
        default="subject_macro_f1",
        help="早停与最佳模型选择指标",
    )
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--aux-lambda", type=float, default=0.1)
    parser.add_argument("--channel-mode", choices=["all", "alternate", "frontal"], default="all")
    parser.add_argument("--aux-loss", choices=["mse", "smooth_l1"], default="mse")
    parser.add_argument("--aux-schedule", choices=["constant", "linear_decay"], default="constant")
    parser.add_argument("--grad-clip", type=float, default=5.0)
    parser.add_argument("--min-delta", type=float, default=1e-6)
    parser.add_argument("--log-every", type=int, default=5)
    parser.add_argument("--data-root", type=Path, default=DEFAULT_DATA_ROOT)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument("--run-name", default="experiment")
    parser.add_argument("--cpu-threads", type=int, default=4)
    parser.add_argument("--overwrite", action="store_true", help="覆盖已完成的同名配置")
    parser.add_argument("--dry-run", action="store_true", help="只显示计划，不读取数据或训练")
    parser.add_argument("--list-options", action="store_true", help="列出数据集、方法和特征后退出")
    return parser


def plan(args) -> tuple[list[tuple[str, ...]], list[str]]:
    feature_sets = build_feature_sets(args.features, args.ablation, args.feature_sets)
    methods = list(dict.fromkeys(args.methods))
    if methods == ["baseline"]:
        feature_sets = []
    configurations = ["baseline/none"] if "baseline" in methods else []
    configurations += [f"{method}/{slug_feature_set(feature_set)}" for method in methods if method != "baseline" for feature_set in feature_sets]
    return feature_sets, configurations


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.list_options:
        print("Datasets:", ", ".join(DATASET_SPECS))
        print("Methods:", ", ".join(METHODS))
        print("Features:", ", ".join(FEATURES))
        print("Feature domains:", json.dumps(FEATURE_DOMAINS, ensure_ascii=False))
        return
    feature_sets, configurations = plan(args)
    if any(method != "baseline" for method in args.methods) and not feature_sets:
        parser.error("Non-baseline methods require at least one feature set")
    folds_by_dataset = {}
    for dataset in args.datasets:
        subject_count = len(list((args.data_root / dataset).glob("*.npz")))
        folds_by_dataset[dataset] = min(args.folds, subject_count) if args.protocol == "subject_independent" else args.folds
    planned_fold_counts = {}
    for dataset in args.datasets:
        available = folds_by_dataset[dataset]
        requested = args.fold_indices or list(range(1, available + 1))
        invalid = [fold for fold in requested if fold < 1 or fold > available]
        if invalid:
            parser.error(f"Invalid --fold-indices for {dataset}: {invalid}; available 1..{available}")
        planned_fold_counts[dataset] = len(set(requested))
    total = sum(planned_fold_counts[dataset] * len(args.seeds) * len(configurations) for dataset in args.datasets)
    print("\nEXPERIMENT PLAN")
    print("  datasets      :", ", ".join(args.datasets))
    print("  target        :", args.target)
    print("  protocol      :", args.protocol)
    print("  selection     :", args.selection_metric)
    print("  methods       :", ", ".join(args.methods))
    print("  atomic features:", ", ".join(args.features))
    print("  feature sets  :", len(feature_sets))
    for feature_set in feature_sets:
        print("    -", slug_feature_set(feature_set))
    print("  seeds         :", args.seeds)
    print("  configurations:", len(configurations))
    print("  planned runs  :", total)
    if "DENS" in args.datasets and len(list((args.data_root / "DENS").glob("*.npz"))) < 20:
        print("  WARNING       : local DENS currently has fewer than 20 subjects; results are exploratory only")
    if args.dry_run:
        return
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA GPU is required")
    torch.set_num_threads(args.cpu_threads)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    torch.use_deterministic_algorithms(True)
    output = args.output_root / args.run_name
    output.mkdir(parents=True, exist_ok=True)
    command_config = vars(args).copy()
    command_config["data_root"] = str(args.data_root.resolve())
    command_config["output_root"] = str(args.output_root.resolve())
    command_config["feature_sets_resolved"] = [list(value) for value in feature_sets]
    protocol_config = {
        key: command_config[key]
        for key in (
            "target", "protocol", "threshold", "folds", "validation_subjects", "split_seed", "batch_size",
            "max_epochs", "patience", "learning_rate", "weight_decay", "aux_lambda", "grad_clip",
            "min_delta", "selection_metric", "data_root", "backbone", "channel_mode", "aux_loss", "aux_schedule",
        )
    }
    protocol_file = output / "protocol_config.json"
    if protocol_file.exists() and not args.overwrite:
        previous_protocol = json.loads(protocol_file.read_text(encoding="utf-8"))
        previous_protocol.setdefault("channel_mode", "all")
        previous_protocol.setdefault("aux_loss", "mse")
        previous_protocol.setdefault("aux_schedule", "constant")
        if previous_protocol != protocol_config:
            raise RuntimeError(
                "The run-name already contains results with a different protocol. "
                "Use a new --run-name or pass --overwrite intentionally."
            )
    else:
        json_dump(protocol_file, protocol_config)
    json_dump(output / "command_config.json", command_config)
    all_results = []
    results_file = output / "results.json"
    if results_file.exists() and not args.overwrite:
        all_results = json.loads(results_file.read_text(encoding="utf-8"))
    selected_feature_names = set(name for feature_set in feature_sets for name in feature_set)
    for dataset in args.datasets:
        adapter = DatasetAdapter(dataset, args.data_root, args.target, args.threshold, args.channel_mode)
        info = adapter.inspect()
        info["feature_definitions"] = feature_description(info["channels"])
        info["feature_dependencies"] = dependency_versions()
        print("\nDATASET", json.dumps(info, ensure_ascii=False))
        subject_ids = [path.stem for path in adapter.subject_files]
        if args.protocol == "subject_independent":
            splits = make_subject_independent_splits(subject_ids, args.folds, args.split_seed, args.validation_subjects)
        else:
            splits = make_subject_dependent_splits(adapter, args.folds, args.split_seed)
        dataset_output = output / dataset / args.target / args.protocol
        json_dump(dataset_output / "dataset_info.json", info)
        json_dump(dataset_output / ("subject_splits.json" if args.protocol == "subject_independent" else "trial_splits.json"), splits)
        selected_folds = args.fold_indices or list(range(1, len(splits) + 1))
        for fold in selected_folds:
            if fold < 1 or fold > len(splits):
                raise ValueError(f"Invalid fold {fold} for {dataset}; available 1..{len(splits)}")
            print(f"\n{'=' * 80}\nPREPARE dataset={dataset} fold={fold}/{len(splits)}\n{'=' * 80}", flush=True)
            arrays = {
                split_name: load_split(adapter, selection, selected_feature_names, args.output_root / "_feature_cache", split_name)
                for split_name, selection in splits[fold - 1].items()
            }
            normalization = normalize(arrays, selected_feature_names)
            normalization_path = dataset_output / "folds" / f"fold_{fold:02d}" / "normalization.npz"
            normalization_path.parent.mkdir(parents=True, exist_ok=True)
            np.savez(
                normalization_path,
                eeg_mean=normalization["eeg_mean"],
                eeg_std=normalization["eeg_std"],
                **{f"{name}_{part}": values[index] for name, values in normalization["feature_stats"].items() for index, part in enumerate(("mean", "std"))},
            )
            for seed in args.seeds:
                if "baseline" in args.methods:
                    folder = dataset_output / "folds" / f"fold_{fold:02d}" / "baseline" / "none" / f"seed_{seed}"
                    result = train_run(args, info, fold, "baseline", tuple(), seed, arrays, folder)
                    all_results = [old for old in all_results if not (old["dataset"] == dataset and old["target"] == args.target and old.get("protocol", "subject_independent") == args.protocol and old["fold"] == fold and old["seed"] == seed and old["method"] == "baseline")]
                    all_results.append(result)
                    json_dump(results_file, all_results)
                for method in args.methods:
                    if method == "baseline":
                        continue
                    for feature_set in feature_sets:
                        tag = slug_feature_set(feature_set)
                        folder = dataset_output / "folds" / f"fold_{fold:02d}" / method / tag / f"seed_{seed}"
                        result = train_run(args, info, fold, method, feature_set, seed, arrays, folder)
                        all_results = [old for old in all_results if not (
                            old["dataset"] == dataset and old["target"] == args.target and old.get("protocol", "subject_independent") == args.protocol and old["fold"] == fold and old["seed"] == seed
                            and old["method"] == method and old["feature_set"] == list(feature_set)
                        )]
                        all_results.append(result)
                        json_dump(results_file, all_results)
            del arrays
            gc.collect()
            torch.cuda.empty_cache()
    summarize(all_results, output)
    print(f"\nALL REQUESTED RUNS COMPLETE. Results: {output}", flush=True)


if __name__ == "__main__":
    error_log = HERE / "last_error.log"
    if error_log.exists():
        error_log.unlink()
    try:
        main()
    except BaseException:
        details = traceback.format_exc()
        error_log.write_text(details, encoding="utf-8")
        print(f"\nERROR LOG SAVED TO: {error_log}\n", flush=True)
        raise
