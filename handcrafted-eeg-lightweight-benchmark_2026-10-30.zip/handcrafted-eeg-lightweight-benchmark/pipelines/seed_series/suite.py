"""Plan first; use --execute for visible sequential subprocess training."""
import argparse,json,subprocess,sys,shutil
from pathlib import Path

HERE=Path(__file__).resolve().parent
def jobs(experiment):
    # Return tag, windows, CLI options. Exp1 supplies shared reference runs.
    if experiment==1:return [('main',1,['--methods','baseline','feature_only','direct_fusion','aux_supervision','--features','dtcwt_energy','hjorth','band_ratios','--feature-sets','dtcwt_energy','hjorth','band_ratios'])]
    if experiment==2:return [('trial_earlystop',1,['--methods','baseline','direct_fusion','--selection-metric','trial_macro_f1'])]
    if experiment==3:return [('combinations',1,['--methods','feature_only','direct_fusion','aux_supervision','--features','dtcwt_energy','hjorth','band_ratios','--feature-sets','hjorth+band_ratios','dtcwt_energy+hjorth','dtcwt_energy+band_ratios','dtcwt_energy+hjorth+band_ratios'])]
    if experiment==4:return [(f'lambda_{v}',1,['--methods','aux_supervision','--aux-lambda',str(v)]) for v in [.01,.03,.3,1.0]]
    if experiment==5:return [(b,1,['--methods','baseline','direct_fusion','--backbone',b]) for b in ['resnet1d','mobilenet1d','squeezenet1d']]
    if experiment==6:return [(f'window_{w}s',w,['--methods','baseline','direct_fusion']) for w in [2,4]]
    if experiment==7:return [(c,1,['--methods','baseline','direct_fusion','--channel-mode',c]) for c in ['alternate','frontal']]
    raise ValueError(experiment)

def main():
    p=argparse.ArgumentParser();p.add_argument('--experiments',nargs='+',type=int,default=list(range(1,8)))
    p.add_argument('--datasets',nargs='+',default=['SEED','SEED_IV','SEED_V']);p.add_argument('--protocols',nargs='+',default=['subject_independent','subject_dependent'])
    p.add_argument('--seeds',nargs='+',type=int,default=[60013,70001,80021,90001,100003]);p.add_argument('--data-root',type=Path,default=HERE/'prepared');p.add_argument('--output-root',type=Path,default=HERE/'results')
    p.add_argument('--batch-size',type=int,default=256);p.add_argument('--cpu-threads',type=int,default=4);p.add_argument('--execute',action='store_true')
    p.add_argument('--smoke',action='store_true',help='one fold, one seed, one epoch; isolated output')
    a=p.parse_args();out=a.output_root/('smoke' if a.smoke else 'formal');plan=[]
    for exp in a.experiments:
        for ds in a.datasets:
            for protocol in a.protocols:
                for tag,window,extra in jobs(exp):
                    name=f'e{exp}_{tag}_{ds}_{protocol}'
                    cmd=[sys.executable,'-u',str(HERE/'cloud.py'),'--datasets',ds,'--target','emotion','--protocol',protocol,'--data-root',str(a.data_root/f'w{window}'),'--output-root',str(out/f'exp{exp}'),'--run-name',name,
                         '--features','dtcwt_energy','--feature-sets','dtcwt_energy','--folds','5','--validation-subjects','3','--seeds',*[str(s) for s in (a.seeds[:1] if a.smoke else a.seeds)],'--batch-size',str(a.batch_size),'--cpu-threads',str(a.cpu_threads),*extra]
                    if a.smoke:cmd+=['--fold-indices','1','--max-epochs','1']
                    plan.append({'experiment':exp,'name':name,'command':cmd})
    out.mkdir(parents=True,exist_ok=True)
    (out/'last_plan.json').write_text(json.dumps(plan,indent=2))
    for row in plan:print(' '.join(row['command']),flush=True)
    print(f'{len(plan)} command groups. Dry plan only.' if not a.execute else f'Executing {len(plan)} groups.',flush=True)
    if not a.execute:return
    for ds in a.datasets:
        expected=16 if ds=='SEED_V' else 15
        for w in {j[1] for exp in a.experiments for j in jobs(exp)}:
            actual=len(list((a.data_root/f'w{w}'/ds).glob('sub*.npz')))
            if actual!=expected:raise SystemExit(f'{ds} w{w}: expected {expected} subjects, found {actual}; complete prepare.py first')
    for row in plan:
        if shutil.disk_usage(out).free < 5*1024**3:raise SystemExit('Less than 5 GiB free: stop before next group; move/archive completed outputs before resuming')
        log=out/'logs'/f"{row['name']}.log";log.parent.mkdir(parents=True,exist_ok=True)
        with log.open('a',encoding='utf-8') as f:
            proc=subprocess.Popen(row['command'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='replace',bufsize=1)
            for line in proc.stdout:print(line,end='',flush=True);f.write(line);f.flush()
            if proc.wait()!=0:raise SystemExit(f"FAILED {row['name']}; see {log}")
    print('Requested training groups complete. See README for exp1 profiling/plots and exp7 perturbation evaluation.',flush=True)

if __name__=='__main__':main()
