"""Handcrafted EEG feature library used by the unified experiment entry."""
from __future__ import annotations

import time
from collections.abc import Callable
from importlib.metadata import version

import dtcwt
import numpy as np
import pywt

from scipy.signal import hilbert, welch





BANDS = (("theta", 4.0, 8.0), ("alpha", 8.0, 14.0), ("beta", 14.0, 30.0), ("gamma", 30.0, 45.0))
FEATURES = (
    "relative_power",
    "absolute_power",
    "band_ratios",
    "spectral_shape",
    "plpcc",
    "hjorth",
    "time_stats",
    "stft_power",
    "dwt_energy",
    "tqwt_energy",
    "dtcwt_energy",
    "hht",
)
FEATURE_DOMAINS = {
    "frequency": ("relative_power", "absolute_power", "band_ratios", "spectral_shape", "plpcc"),
    "time": ("hjorth", "time_stats"),
    "time_frequency": ("stft_power", "dwt_energy", "tqwt_energy", "dtcwt_energy", "hht"),
}

# Fixed, reproducible parameters for the new transforms.
PLP_ORDER = 13
PLP_FILTERS = 18
DWT_WAVELET = "db4"
DWT_LEVELS = 4
TQWT_Q = 2.0
TQWT_REDUNDANCY = 3.0
TQWT_LEVELS = 5
DTCWT_LEVELS = 4
HHT_IMFS = 3
HHT_MAX_ITERATIONS = 40


def dependency_versions() -> dict[str, str]:
    packages = ("numpy", "scipy", "PyWavelets", "dtcwt", "EMD-signal", "spafe", "tqwt-tools")
    
    from importlib.metadata import PackageNotFoundError
    result = {}
    for name in packages:
        try: result[name] = version(name)
        except PackageNotFoundError: result[name] = "not installed (optional)"
    return result


def feature_description(channels: int) -> dict[str, dict[str, int | str]]:
    return {
        "relative_power": {"dimensions": channels * 4, "definition": "Welch PSD各通道theta/alpha/beta/gamma功率除以1-45 Hz总功率"},
        "absolute_power": {"dimensions": channels * 4, "definition": "Welch PSD各通道四频段绝对功率取自然对数"},
        "band_ratios": {"dimensions": channels * 3, "definition": "各通道theta/alpha、beta/alpha、(theta+alpha)/(beta+gamma)，随后取自然对数"},
        "spectral_shape": {"dimensions": channels * 4, "definition": "1-45 Hz归一化谱的谱熵、谱质心、谱扩散和95%谱边缘频率"},
        "plpcc": {"dimensions": channels * PLP_ORDER, "definition": f"各通道整段1秒信号的{PLP_ORDER}阶PLP倒谱系数；{PLP_FILTERS}个Bark滤波器，1-45 Hz，无预加重"},
        "hjorth": {"dimensions": channels * 3, "definition": "各通道Hjorth Activity、Mobility、Complexity"},
        "time_stats": {"dimensions": channels * 6, "definition": "各通道均值、标准差、峰峰值、偏度、超额峰度、平均绝对一阶差分"},
        "stft_power": {"dimensions": channels * 16, "definition": "每秒分为4个无重叠时间片，各片计算四频段相对功率"},
        "dwt_energy": {"dimensions": channels * 10, "definition": f"各通道{DWT_WAVELET}离散小波{DWT_LEVELS}层分解的5个子带；每带取对数能量与相对能量"},
        "tqwt_energy": {"dimensions": channels * 12, "definition": f"各通道TQWT（Q={TQWT_Q}, redundancy={TQWT_REDUNDANCY}, levels={TQWT_LEVELS}）6个子带的对数能量与相对能量"},
        "dtcwt_energy": {"dimensions": channels * 10, "definition": f"各通道一维DTCWT {DTCWT_LEVELS}层高通及末级低通共5个子带的对数能量与相对能量"},
        "hht": {"dimensions": channels * 16, "definition": f"各通道EMD前{HHT_IMFS}个IMF的对数能量、相对能量、平均Hilbert包络、包络加权瞬时频率及瞬时频率标准差，并加残差相对能量"},
    }


def _energy_pair(coefficients: list[np.ndarray], axis: int = -1) -> np.ndarray:
    eps = np.float64(1e-12)
    energies = np.stack([np.mean(np.abs(value) ** 2, axis=axis) for value in coefficients], axis=-1)
    relative = energies / np.maximum(energies.sum(axis=-1, keepdims=True), eps)
    return np.stack((np.log(np.maximum(energies, eps)), relative), axis=-1).reshape(*energies.shape[:-1], -1)


def _spectral_groups(x: np.ndarray, sfreq: int, selected: set[str], output: dict[str, np.ndarray]) -> None:
    eps = np.float32(1e-12)
    frequency, psd = welch(x, fs=sfreq, window="hann", nperseg=sfreq, noverlap=0, nfft=sfreq,
                           detrend="constant", scaling="density", axis=-1)
    total_mask = (frequency >= 1) & (frequency < 45)
    total = psd[..., total_mask].sum(-1)
    band_values = np.stack([psd[..., (frequency >= low) & (frequency < high)].sum(-1) for _, low, high in BANDS], axis=-1)
    if "relative_power" in selected:
        output["relative_power"] = (band_values / np.maximum(total[..., None], eps)).reshape(len(x), -1).astype(np.float32)
    if "absolute_power" in selected:
        output["absolute_power"] = np.log(np.maximum(band_values, eps)).reshape(len(x), -1).astype(np.float32)
    if "band_ratios" in selected:
        theta, alpha, beta, gamma = [band_values[..., index] for index in range(4)]
        ratios = np.stack((theta / np.maximum(alpha, eps), beta / np.maximum(alpha, eps),
                           (theta + alpha) / np.maximum(beta + gamma, eps)), axis=-1)
        output["band_ratios"] = np.log(np.maximum(ratios, eps)).reshape(len(x), -1).astype(np.float32)
    if "spectral_shape" in selected:
        local_frequency = frequency[total_mask]
        probability = psd[..., total_mask] / np.maximum(psd[..., total_mask].sum(-1, keepdims=True), eps)
        entropy = -(probability * np.log(np.maximum(probability, eps))).sum(-1) / np.log(probability.shape[-1])
        centroid = (probability * local_frequency).sum(-1)
        spread = np.sqrt((probability * np.square(local_frequency - centroid[..., None])).sum(-1))
        edge95 = local_frequency[np.argmax(np.cumsum(probability, axis=-1) >= 0.95, axis=-1)]
        output["spectral_shape"] = np.stack((entropy, centroid, spread, edge95), axis=-1).reshape(len(x), -1).astype(np.float32)


def _plpcc(x: np.ndarray, sfreq: int, progress: Callable[[str], None] | None) -> np.ndarray:
    from spafe.features.rplp import plp
    from spafe.utils.preprocessing import SlidingWindow
    flattened = x.reshape(-1, x.shape[-1])
    values = np.empty((len(flattened), PLP_ORDER), dtype=np.float32)
    window = SlidingWindow(win_len=1.0, win_hop=1.0, win_type="hamming")
    report_every = max(1, len(flattened) // 10)
    for index, signal in enumerate(flattened):
        values[index] = plp(signal.astype(np.float64, copy=False), fs=sfreq, order=PLP_ORDER, pre_emph=False,
                            window=window, nfilts=PLP_FILTERS, nfft=256, low_freq=1, high_freq=45)[0]
        if progress and (index + 1) % report_every == 0:
            progress(f"PLPCC {index + 1}/{len(flattened)} channels")
    return values.reshape(len(x), -1)


def _dwt_energy(x: np.ndarray) -> np.ndarray:
    coefficients = pywt.wavedec(x, wavelet=DWT_WAVELET, level=DWT_LEVELS, axis=-1, mode="symmetric")
    return _energy_pair(list(coefficients)).reshape(len(x), -1).astype(np.float32)


def _tqwt_energy(x: np.ndarray, progress: Callable[[str], None] | None) -> np.ndarray:
    from tqwt_tools import tqwt
    flattened = x.reshape(-1, x.shape[-1])
    values = np.empty((len(flattened), 2 * (TQWT_LEVELS + 1)), dtype=np.float32)
    report_every = max(1, len(flattened) // 10)
    for index, signal in enumerate(flattened):
        coefficients = list(tqwt(signal.astype(np.float64, copy=False), q=TQWT_Q,
                                 redundancy=TQWT_REDUNDANCY, stages=TQWT_LEVELS))
        values[index] = _energy_pair(coefficients).astype(np.float32)
        if progress and (index + 1) % report_every == 0:
            progress(f"TQWT {index + 1}/{len(flattened)} channels")
    return values.reshape(len(x), -1)


def _dtcwt_energy(x: np.ndarray) -> np.ndarray:
    # dtcwt 0.14 uses this removed NumPy alias although its implementation is
    # otherwise compatible with NumPy 2.x. Keep the compatibility local to the
    # transform call so the project's MNE-compatible NumPy version is retained.
    if not hasattr(np, "asfarray"):
        np.asfarray = lambda value, dtype=None: np.asarray(value, dtype=dtype)  # type: ignore[attr-defined]
    flattened = x.reshape(-1, x.shape[-1]).T.astype(np.float64, copy=False)
    transform = dtcwt.Transform1d()
    result = transform.forward(flattened, nlevels=DTCWT_LEVELS)
    coefficients = [value.T for value in result.highpasses] + [result.lowpass.T]
    return _energy_pair(coefficients).reshape(len(x), -1).astype(np.float32)


def _hht(x: np.ndarray, sfreq: int, progress: Callable[[str], None] | None) -> np.ndarray:
    from PyEMD import EMD
    eps = 1e-12
    flattened = x.reshape(-1, x.shape[-1])
    values = np.zeros((len(flattened), HHT_IMFS * 5 + 1), dtype=np.float32)
    emd = EMD(spline_kind="linear", MAX_ITERATION=HHT_MAX_ITERATIONS)
    report_every = max(1, len(flattened) // 20)
    for index, signal in enumerate(flattened):
        components = emd.emd(signal.astype(np.float64, copy=False), max_imf=HHT_IMFS)
        imfs = components[:HHT_IMFS]
        residual = signal - imfs.sum(axis=0) if len(imfs) else signal
        energies = np.asarray([np.mean(imf ** 2) for imf in imfs], dtype=np.float64)
        residual_energy = float(np.mean(residual ** 2))
        total_energy = max(float(energies.sum()) + residual_energy, eps)
        for imf_index, imf in enumerate(imfs):
            analytic = hilbert(imf)
            amplitude = np.abs(analytic)
            frequency = np.diff(np.unwrap(np.angle(analytic))) * sfreq / (2 * np.pi)
            frequency = np.clip(np.abs(frequency), 0, sfreq / 2)
            frequency_weight = amplitude[1:]
            weighted_mean = float(np.sum(frequency * frequency_weight) / max(float(frequency_weight.sum()), eps))
            start = imf_index * 5
            values[index, start:start + 5] = (
                np.log(max(energies[imf_index], eps)),
                energies[imf_index] / total_energy,
                float(amplitude.mean()),
                weighted_mean,
                float(frequency.std()),
            )
        values[index, -1] = residual_energy / total_energy
        if progress and (index + 1) % report_every == 0:
            progress(f"HHT {index + 1}/{len(flattened)} channels")
    return values.reshape(len(x), -1)


def compute_features(x: np.ndarray, sfreq: int, selected: set[str], progress: Callable[[str], None] | None = None) -> dict[str, np.ndarray]:
    """Compute selected atomic feature groups for [window, channel, sample]."""
    unknown = selected - set(FEATURES)
    if unknown:
        raise ValueError(f"Unknown handcrafted features: {sorted(unknown)}")
    output: dict[str, np.ndarray] = {}
    spectral = {"relative_power", "absolute_power", "band_ratios", "spectral_shape"}
    if selected & spectral:
        _spectral_groups(x, sfreq, selected, output)
    eps = np.float32(1e-12)
    if selected & {"hjorth", "time_stats"}:
        dx = np.diff(x, axis=-1)
    if "hjorth" in selected:
        ddx = np.diff(dx, axis=-1)
        variance0, variance1, variance2 = np.var(x, axis=-1), np.var(dx, axis=-1), np.var(ddx, axis=-1)
        mobility = np.sqrt(variance1 / np.maximum(variance0, eps))
        complexity = np.sqrt(variance2 / np.maximum(variance1, eps)) / np.maximum(mobility, eps)
        output["hjorth"] = np.stack((variance0, mobility, complexity), axis=-1).reshape(len(x), -1).astype(np.float32)
    if "time_stats" in selected:
        mean = x.mean(-1)
        std = np.maximum(x.std(-1), eps)
        standardized = (x - mean[..., None]) / std[..., None]
        output["time_stats"] = np.stack((mean, std, np.ptp(x, axis=-1), np.mean(standardized ** 3, axis=-1),
                                          np.mean(standardized ** 4, axis=-1) - 3, np.mean(np.abs(dx), axis=-1)), axis=-1).reshape(len(x), -1).astype(np.float32)
    if "stft_power" in selected:
        temporal = []
        boundaries = np.linspace(0, x.shape[-1], 5, dtype=int)
        for segment_index in range(4):
            segment = x[..., boundaries[segment_index]:boundaries[segment_index + 1]]
            spectrum = np.abs(np.fft.rfft(segment * np.hanning(segment.shape[-1]).astype(np.float32), axis=-1)) ** 2
            frequency = np.fft.rfftfreq(segment.shape[-1], d=1 / sfreq)
            denominator = spectrum[..., (frequency >= 1) & (frequency < 45)].sum(-1)
            temporal.append(np.stack([spectrum[..., (frequency >= low) & (frequency < high)].sum(-1) / np.maximum(denominator, eps)
                                      for _, low, high in BANDS], axis=-1))
        output["stft_power"] = np.stack(temporal, axis=-2).reshape(len(x), -1).astype(np.float32)

    slow_extractors = {
        "plpcc": lambda: _plpcc(x, sfreq, progress),
        "dwt_energy": lambda: _dwt_energy(x),
        "tqwt_energy": lambda: _tqwt_energy(x, progress),
        "dtcwt_energy": lambda: _dtcwt_energy(x),
        "hht": lambda: _hht(x, sfreq, progress),
    }
    for name, extractor in slow_extractors.items():
        if name in selected:
            started = time.perf_counter()
            if progress:
                progress(f"start {name}")
            output[name] = extractor()
            if progress:
                progress(f"finish {name}, {time.perf_counter() - started:.1f}s")
    descriptions = feature_description(x.shape[1])
    for name, values in output.items():
        expected = int(descriptions[name]["dimensions"])
        if values.shape != (len(x), expected):
            raise ValueError(f"Feature {name} shape {values.shape}, expected {(len(x), expected)}")
        if not np.isfinite(values).all():
            raise ValueError(f"Non-finite values in feature group {name}")
    return output
