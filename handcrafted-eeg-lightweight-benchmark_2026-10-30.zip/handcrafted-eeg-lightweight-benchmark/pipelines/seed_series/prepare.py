"""Read original ZIPs sequentially; never extract the entire datasets."""
import argparse
import ast
import io
import json
import re
import shutil
import tempfile
import struct
import zipfile
import xml.etree.ElementTree as ET
from pathlib import Path
import numpy as np
from scipy.io import loadmat
from scipy.signal import butter,sosfiltfilt,resample_poly

LABELS={'SEED':['negative','neutral','positive'],'SEED_IV':['neutral','sad','fear','happy'],'SEED_V':['disgust','fear','sad','neutral','happy']}
def xlsx_rows(blob):
    ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
    with zipfile.ZipFile(io.BytesIO(blob)) as z:
        strings=[''.join(t.itertext()) for t in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)] if 'xl/sharedStrings.xml' in z.namelist() else []
        rows=[]
        for r in ET.fromstring(z.read('xl/worksheets/sheet1.xml')).findall('.//m:row',ns):
            row={}
            for c in r.findall('m:c',ns):
                v=c.find('m:v',ns);value=v.text if v is not None else ''
                if c.get('t')=='s':value=strings[int(value)]
                row[c.get('r')]=value
            rows.append(row)
        return rows

def selected(names,dataset):
    if dataset=='SEED':return sorted(n for n in names if '/Preprocessed_EEG/' in n and n.endswith('.mat') and not n.endswith('label.mat'))
    if dataset=='SEED_IV':return sorted(n for n in names if '/eeg_raw_data/' in n and n.endswith('.mat'))
    # Only canonical subject_session_date CNTs; the archive also contains a
    # duplicate *_repaired.cnt which must not count as an extra session.
    return sorted(n for n in names if '/EEG_raw/' in n and re.fullmatch(r'\d+_[123]_\d{8}\.cnt',Path(n).name))

def main():
    p=argparse.ArgumentParser();p.add_argument('--dataset',choices=LABELS,required=True);p.add_argument('--archive',type=Path,required=True)
    p.add_argument('--output',type=Path,default=Path('prepared'));p.add_argument('--scratch',type=Path,default=Path('scratch'))
    p.add_argument('--limit-subjects',type=int,default=0,help='Smoke preparation only; not a full dataset')
    a=p.parse_args();a.scratch.mkdir(parents=True,exist_ok=True)
    manifest=[]
    with zipfile.ZipFile(a.archive) as z:
        names=z.namelist();files=selected(names,a.dataset)
        assert len(files)==(48 if a.dataset=='SEED_V' else 45),(a.dataset,'unexpected record count',len(files))
        channel_file=next(n for n in names if n.lower().endswith('channel-order.xlsx') or n.endswith('Channel Order.xlsx'))
        channels=[next(iter(r.values())) for r in xlsx_rows(z.read(channel_file)) if r]
        assert len(channels)==62
        if a.dataset=='SEED':
            labs=loadmat(io.BytesIO(z.read(next(n for n in names if n.endswith('Preprocessed_EEG/label.mat')))))['label'].ravel().astype(int)+1
            assert len(labs)==15
        elif a.dataset=='SEED_IV':
            txt=z.read(next(n for n in names if n.endswith('/ReadMe.txt'))).decode('utf-8',errors='replace')
            labs=[ast.literal_eval(re.search(f'session{s}_label\\s*=\\s*(\\[[^]]+\\])',txt).group(1)) for s in [1,2,3]]
            assert all(len(v)==24 for v in labs)
        else:
            rows=xlsx_rows(z.read(next(n for n in names if n.endswith('emotion_label_and_stimuli_order.xlsx'))))
            table={k:v for r in rows for k,v in r.items()}
            mapping={str(table[f'B{i}']).lower():int(table[f'C{i}']) for i in range(2,7)}
            labs=[[mapping[table[f'{chr(c)}{r}'].lower()] for c in range(ord('C'),ord('Q')+1)] for r in [12,13,14]]
            txt=z.read(next(n for n in names if n.endswith('trial_start_end_timestamp.txt'))).decode()
            starts=[ast.literal_eval(s) for s in re.findall(r'start_second:\s*(\[[^]]+\])',txt)]
            ends=[ast.literal_eval(s) for s in re.findall(r'end_second:\s*(\[[^]]+\])',txt)]
            assert len(starts)==len(ends)==3
        subjects=sorted({int(Path(f).name.split('_')[0]) for f in files})
        if a.limit_subjects:subjects=subjects[:a.limit_subjects]
        for subject in subjects:
            if shutil.disk_usage(a.output if a.output.exists() else a.output.parent).free < 3*1024**3:
                raise RuntimeError('Less than 3 GiB free on preparation disk')
            paths=sorted(f for f in files if int(Path(f).name.split('_')[0])==subject)
            assert len(paths)==3
            outpaths=[a.output/f'w{w}'/a.dataset/f'sub{subject:02d}.npz' for w in [1,2,4]]
            # A manifest per subject is the completion marker, never just a partial NPZ.
            marker=a.output/'manifests'/a.dataset/f'sub{subject:02d}.json'
            if marker.exists() and all(f.exists() for f in outpaths):
                manifest.append(json.loads(marker.read_text()));print('SKIP',subject,flush=True);continue
            trials=[];ys=[];sessions=[]
            for session_index,path in enumerate(paths,1):
                print('READ',path,flush=True)
                session=int(Path(path).parent.name) if a.dataset=='SEED_IV' else (int(Path(path).stem.split('_')[1]) if a.dataset=='SEED_V' else session_index)
                if a.dataset!='SEED_V':
                    with z.open(path) as f:mat=loadmat(f)
                    keys=sorted((k for k in mat if re.search(r'_eeg\d+$',k)),key=lambda k:int(re.search(r'(\d+)$',k).group()))
                    assert len(keys)==(15 if a.dataset=='SEED' else 24)
                    for i,key in enumerate(keys):
                        x=mat[key];assert x.shape[0]==62
                        # Official MAT files are at 200Hz; retain 35s for filter context, last 28s for all lengths.
                        x=np.asarray(x[:,-35*200:],dtype=np.float64)
                        trials.append(process(x,200));ys.append(int(labs[i] if a.dataset=='SEED' else labs[session-1][i]));sessions.append(session)
                    del mat
                else:
                    import mne
                    with tempfile.TemporaryDirectory(dir=a.scratch) as td:
                        cnt=Path(td)/Path(path).name
                        with z.open(path) as src,cnt.open('wb') as dst:shutil.copyfileobj(src,dst,8*1024*1024)
                        reader_options={}
                        if cnt.name=='7_1_20180411.cnt':
                            with cnt.open('rb') as fh:header=fh.read(900)
                            nch=struct.unpack_from('<H',header,370)[0]
                            header_samples=struct.unpack_from('<i',header,864)[0]
                            event_offset=struct.unpack_from('<i',header,886)[0]
                            if header_samples<=0:
                                size=event_offset-(900+75*nch)
                                assert nch==66 and 0<event_offset<=cnt.stat().st_size
                                assert size%(nch*4)==0
                                reader_options={'data_format':'int32','recompute_n_samples':True}
                                print(f'CNT HEADER WORKAROUND: {cnt.name} header_samples={header_samples}, inferred_samples={size//(nch*4)}, int32; original file unchanged',flush=True)
                        raw=mne.io.read_raw_cnt(cnt,preload=False,verbose='ERROR',**reader_options)
                        try:
                            by_name={n.upper():n for n in raw.ch_names}
                            picks=[raw.ch_names.index(by_name[n.upper()]) for n in channels]
                            sf=float(raw.info['sfreq']);assert sf==1000
                            for i,(start,end) in enumerate(zip(starts[session-1],ends[session-1])):
                                begin=max(start,end-35)
                                assert end*sf<=raw.n_times
                                x=raw.get_data(picks=picks,start=int(begin*sf),stop=int(end*sf))*1e6
                                trials.append(process(x,1000));ys.append(labs[session-1][i]);sessions.append(session)
                        finally:raw.close()
            x=np.stack(trials).astype(np.float32);n,c,t=x.shape;assert t==7000
            one=x.reshape(n,c,28,250).transpose(0,2,1,3)
            good=(np.ptp(one,axis=-1).max(-1)<=500)&~(np.std(one,axis=-1)<0.1).any(-1)
            good4=good.reshape(n,7,4).all(-1)
            if not good4.any():raise ValueError('All trials rejected; verify physical units before continuing')
            row={'subject':subject,'dataset':a.dataset,'trials':n,'valid_4s_blocks':int(good4.sum()),'class_names':LABELS[a.dataset],'sources':paths,'sessions':sessions,'source_archive_bytes':a.archive.stat().st_size,'unit':'microvolt','duration_per_trial_s':28,'sampling_rate':250}
            for w,dest in zip([1,2,4],outpaths):
                dest.parent.mkdir(parents=True,exist_ok=True)
                np.savez(dest,eeg_uv=x.reshape(n,c,28//w,250*w).transpose(0,2,1,3).reshape(-1,c,250*w),
                         quality_ok=np.repeat(good4,4//w,axis=1).ravel(),trial_index=np.repeat(np.arange(n),28//w),
                         window_in_trial=np.tile(np.arange(28//w),n),scores=np.array(ys,dtype=np.int64)[:,None],
                         session=np.array(sessions),channel_names=np.array(channels),sfreq=np.array(250))
            marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(json.dumps(row,indent=2));manifest.append(row)
            print(f'PREPARED {a.dataset} subject={subject} trials={n} valid4s={good4.sum()}',flush=True)
    a.output.mkdir(parents=True,exist_ok=True)
    (a.output/f'{a.dataset}_manifest.json').write_text(json.dumps(manifest,indent=2))

def process(x,sfreq):
    assert x.shape[-1]>=28*sfreq and np.isfinite(x).all()
    x=sosfiltfilt(butter(4,[1,45],fs=sfreq,btype='bandpass',output='sos'),x,axis=-1)
    if sfreq==200:x=resample_poly(x,5,4,axis=-1)
    elif sfreq==1000:x=resample_poly(x,1,4,axis=-1)
    x=x[:,-7000:];x-=x.mean(0,keepdims=True)
    return x.astype(np.float32)

if __name__=='__main__':main()
