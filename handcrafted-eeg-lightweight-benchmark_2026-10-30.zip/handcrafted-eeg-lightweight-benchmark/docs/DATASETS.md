# Dataset access and local placement

The five datasets are third-party research datasets. This repository does not grant access to them and does not redistribute raw or processed participant data.

| Dataset | Task in the paper | Expected local input | Access route |
|---|---|---|---|
| DREAMER | Separate binary valence and arousal tasks | Licensed `DREAMER.mat` | Obtain from the official DREAMER record after approval and follow its terms |
| FACED | Separate binary valence and arousal tasks | Official `Data.zip` release | Obtain from the official FACED distribution and follow its terms |
| SEED | Three-class emotion recognition | Official `SEED.zip` | Apply through the official SEED dataset provider |
| SEED-IV | Four-class emotion recognition | Official `SEED_IV.zip` | Apply through the official SEED dataset provider |
| SEED-V | Five-class emotion recognition | Official `SEED-V.zip` | Apply through the official SEED dataset provider |

## Prepared NPZ schema

Each prepared subject file contains:

- `eeg_uv`: window × channel × sample EEG array in microvolts;
- `trial_index`: complete-trial membership of every window;
- `window_in_trial`: ordered position within the trial;
- `quality_ok`: fixed window-quality flag;
- `scores`: trial ratings or released discrete labels;
- `channel_names` and `sfreq`: channel metadata and sampling rate.

Splits are performed at complete-trial or complete-subject level. Windows from one trial must never be divided across train, validation, and test subsets.

## Publication note

For a public GitHub release, commit code, metadata schemas, source-data tables for figures, and instructions only. Do not commit downloaded archives, participant-level NPZ files, access tokens, approval e-mails, or licence forms. If processed data sharing is later permitted, deposit it in a suitable repository under the applicable dataset terms and add a stable identifier here.
