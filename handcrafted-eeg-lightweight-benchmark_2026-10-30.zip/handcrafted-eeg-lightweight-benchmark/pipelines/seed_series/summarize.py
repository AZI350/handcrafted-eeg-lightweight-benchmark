import argparse,csv,json
from pathlib import Path
import numpy as np
from scipy.stats import t

def main():
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);a=p.parse_args()
    rows=[];grouped={}
    for path in a.root.rglob('metrics.json'):
        d=json.loads(path.read_text());parent=next(q for q in path.parents if (q/'command_config.json').exists())
        key=(parent.name,d['dataset'],d['protocol'],d['method'],'+'.join(d['feature_set']))
        score=d['test']['trial']['overall'];row=dict(zip(['run','dataset','protocol','method','features'],key))
        row.update(fold=d['fold'],seed=d['seed'],**{k:score[k] for k in ['accuracy','macro_f1','sensitivity','specificity','roc_auc','mcc']});rows.append(row)
        grouped.setdefault(key,{}).setdefault(d['seed'],[]).append(score['macro_f1'])
    with (a.root/'all_runs.csv').open('w',newline='',encoding='utf-8') as f:
        if rows:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    lines=['# Trial-level summary','','CI describes training-seed variation with fixed splits, not population generalization. Incomplete folds are marked. No automatic winner selection.','','| Run | Method | Features | Runs | F1 (%) | 95% seed t CI (%) |','|---|---|---|---:|---:|---|']
    for key,seeds in sorted(grouped.items()):
        complete=all(len(v)==5 for v in seeds.values());v=np.array([np.mean(x) for x in seeds.values()]);half=t.ppf(.975,len(v)-1)*v.std(ddof=1)/np.sqrt(len(v)) if len(v)>1 and complete else None
        ci=f'[{100*(v.mean()-half):.2f}, {100*(v.mean()+half):.2f}]' if half is not None else 'incomplete / one seed'
        lines.append(f'| {key[0]} | {key[3]} | {key[4]} | {sum(map(len,seeds.values()))} | {100*v.mean():.2f} | {ci} |')
    (a.root/'SUMMARY.md').write_text('\n'.join(lines),encoding='utf-8')
    print('Saved',a.root/'SUMMARY.md')

if __name__=='__main__':main()
