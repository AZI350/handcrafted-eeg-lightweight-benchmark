from pathlib import Path
import csv
import sys

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audit_panel_alignment import require_matplotlib_panel_alignment


OUT = Path(__file__).resolve().parent / "figures"
DATA = Path(__file__).resolve().parent / "data"
ALIGN = OUT / "alignment_audits"
OUT.mkdir(exist_ok=True)
ALIGN.mkdir(exist_ok=True)

COLORS = {
    "eeg": "#3B7EA1",
    "feature": "#E49A3A",
    "fusion": "#2A8C82",
    "aux": "#8A6FA8",
    "dark": "#263238",
    "muted": "#71808C",
    "light": "#EEF3F5",
    "red": "#C75B5B",
    "green": "#69A84F",
}

mpl.rcParams.update(
    {
        "font.family": "Arial",
        "font.size": 8.0,
        "axes.titlesize": 8.5,
        "axes.labelsize": 8.0,
        "xtick.labelsize": 7.0,
        "ytick.labelsize": 7.0,
        "legend.fontsize": 7.0,
        "axes.linewidth": 0.7,
        "lines.linewidth": 1.0,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "savefig.facecolor": "white",
    }
)


def save(fig, name, audit_axes=None):
    if audit_axes is not None and len(audit_axes) > 1:
        require_matplotlib_panel_alignment(
            fig,
            axes=list(audit_axes),
            json_out=ALIGN / f"{name}.json",
            tolerance_pt=1.5,
            gutter_tolerance_pt=1.5,
            strict=True,
        )
    fig.savefig(OUT / f"{name}.pdf", bbox_inches="tight", pad_inches=0.03)
    fig.savefig(OUT / f"{name}.svg", bbox_inches="tight", pad_inches=0.03)
    fig.savefig(OUT / f"{name}.png", dpi=300, bbox_inches="tight", pad_inches=0.03)
    plt.close(fig)


def rounded(ax, xy, width, height, text, fc="white", ec=COLORS["dark"], lw=1.0,
            fontsize=8, radius=0.025, text_color=COLORS["dark"], weight="normal"):
    box = FancyBboxPatch(
        xy, width, height,
        boxstyle=f"round,pad=0.012,rounding_size={radius}",
        facecolor=fc, edgecolor=ec, linewidth=lw,
    )
    ax.add_patch(box)
    ax.text(xy[0] + width / 2, xy[1] + height / 2, text,
            ha="center", va="center", fontsize=fontsize,
            color=text_color, weight=weight)
    return box


def arrow(ax, start, end, color=COLORS["dark"], lw=1.1, style="-|>", rad=0.0):
    ax.add_patch(
        FancyArrowPatch(start, end, arrowstyle=style, mutation_scale=10,
                        linewidth=lw, color=color,
                        connectionstyle=f"arc3,rad={rad}")
    )


def panel_label(ax, text, x=0.01, y=0.98):
    ax.text(x, y, text, transform=ax.transAxes, ha="left", va="top",
            fontsize=9.5, weight="bold", color=COLORS["dark"])


def synthetic_eeg(ax, x0=0.03, x1=0.23, y0=0.17, y1=0.84, channels=6):
    rng = np.random.default_rng(17)
    t = np.linspace(0, 1, 700)
    for i in range(channels):
        y = (np.sin(2 * np.pi * (7 + i) * t + i * .7)
             + .45 * np.sin(2 * np.pi * (17 + i * .5) * t)
             + .28 * rng.normal(size=t.size))
        y = (y - y.mean()) / (5.7 * channels)
        base = y1 - (i + .5) * (y1 - y0) / channels
        ax.plot(x0 + (x1 - x0) * t, base + y, lw=.55,
                color=COLORS["eeg"], clip_on=False)
        ax.text(x0 - .008, base, f"Ch {i+1}", ha="right", va="center", fontsize=6.4)


def study_overview():
    fig, ax = plt.subplots(figsize=(10.8, 4.5))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")

    rounded(ax, (.015, .08), .225, .84, "", fc="#F7FBFD", ec=COLORS["eeg"], lw=1.2)
    ax.text(.025, .89, "(a) EEG trial and windows", weight="bold", fontsize=7.8)
    synthetic_eeg(ax)
    for j, x in enumerate([.047, .092, .137, .182]):
        ax.add_patch(Rectangle((x, .105), .035, .075, facecolor="#D7E9F1",
                               edgecolor=COLORS["eeg"], lw=.7))
        ax.text(x + .0175, .093, f"$X_{j+1}$", ha="center", va="top", fontsize=6.7)

    rounded(ax, (.265, .55), .31, .37, "", fc="#F5FAF3", ec=COLORS["green"], lw=1.2)
    ax.text(.278, .89, "(b) Lightweight waveform pathway", weight="bold", fontsize=7.8)
    rounded(ax, (.287, .68), .068, .12, "Temporal\nconv.", fc="white", ec=COLORS["green"], fontsize=7)
    rounded(ax, (.385, .68), .078, .12, "Efficient\nchannel mix", fc="white", ec=COLORS["green"], fontsize=7)
    rounded(ax, (.493, .68), .058, .12, "Global\npool", fc="white", ec=COLORS["green"], fontsize=7)
    arrow(ax, (.355, .74), (.385, .74), COLORS["green"])
    arrow(ax, (.463, .74), (.493, .74), COLORS["green"])
    ax.text(.418, .59, "$g_\\theta(X)$: learned EEG embedding", ha="center", fontsize=8)

    rounded(ax, (.265, .08), .31, .40, "", fc="#FFF9F1", ec=COLORS["feature"], lw=1.2)
    ax.text(.278, .45, "(c) Handcrafted-feature pathway", weight="bold", fontsize=7.8)
    rounded(ax, (.282, .27), .082, .10, "Hjorth\n(time)", fc="white", ec=COLORS["feature"], fontsize=7)
    rounded(ax, (.378, .27), .082, .10, "Band ratios\n(frequency)", fc="white", ec=COLORS["feature"], fontsize=7)
    rounded(ax, (.474, .27), .082, .10, "DTCWT energy\n(time-scale)", fc="white", ec=COLORS["feature"], fontsize=7)
    rounded(ax, (.347, .12), .145, .085, "Standardize / project $Ph(X)$", fc="#FFF2DF", ec=COLORS["feature"], fontsize=7.3)
    for x in [.323, .419, .515]: arrow(ax, (x, .27), (.42, .205), COLORS["feature"], lw=.8)

    rounded(ax, (.61, .49), .17, .43, "", fc="#F8F6FB", ec=COLORS["aux"], lw=1.2)
    ax.text(.622, .89, "(d) Participation modes", weight="bold", fontsize=7.8)
    modes = [("EEG only", COLORS["eeg"]), ("Feature only", COLORS["feature"]),
             ("Direct fusion", COLORS["fusion"]), ("Auxiliary supervision", COLORS["aux"])]
    for i, (txt, col) in enumerate(modes):
        rounded(ax, (.628, .78 - i * .085), .135, .055, txt, fc="white", ec=col, fontsize=7.2)

    rounded(ax, (.61, .08), .17, .33, "", fc="#F4FAF9", ec=COLORS["fusion"], lw=1.2)
    ax.text(.622, .38, "(e) Trial decision", weight="bold", fontsize=7.8)
    rounded(ax, (.632, .265), .126, .065, "Window probabilities", fc="white", ec=COLORS["fusion"], fontsize=7)
    rounded(ax, (.632, .17), .126, .065, "Mean over windows", fc="white", ec=COLORS["fusion"], fontsize=7)
    rounded(ax, (.632, .09), .126, .055, "Trial label", fc="#DFF2EE", ec=COLORS["fusion"], fontsize=7, weight="bold")
    arrow(ax, (.695, .265), (.695, .235), COLORS["fusion"])
    arrow(ax, (.695, .17), (.695, .145), COLORS["fusion"])

    rounded(ax, (.815, .08), .17, .84, "", fc="#FAFAFA", ec=COLORS["muted"], lw=1.2)
    ax.text(.827, .89, "(f) Four research questions", weight="bold", fontsize=7.8)
    rq = [
        ("RQ1", "Performance and source", COLORS["eeg"]),
        ("RQ2", "Feature / method choice", COLORS["feature"]),
        ("RQ3", "Generalization and stability", COLORS["aux"]),
        ("RQ4", "Deployment trade-off", COLORS["fusion"]),
    ]
    for i, (tag, text, col) in enumerate(rq):
        y = .72 - i * .17
        rounded(ax, (.835, y), .045, .075, tag, fc=col, ec=col, fontsize=7.2, text_color="white", weight="bold")
        ax.text(.892, y + .037, text, ha="left", va="center", fontsize=7.3)

    arrow(ax, (.24, .69), (.265, .74), COLORS["dark"])
    arrow(ax, (.24, .36), (.265, .31), COLORS["dark"])
    arrow(ax, (.575, .73), (.61, .73), COLORS["dark"])
    arrow(ax, (.575, .27), (.61, .67), COLORS["dark"], rad=-.18)
    arrow(ax, (.78, .63), (.815, .63), COLORS["dark"])
    arrow(ax, (.78, .24), (.815, .34), COLORS["dark"], rad=-.15)
    save(fig, "study_overview")


def label_tasks():
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.5), gridspec_kw={"width_ratios": [1, 1.18]})
    ax = axes[0]
    ax.axhline(0, color=COLORS["muted"], lw=.8); ax.axvline(0, color=COLORS["muted"], lw=.8)
    ax.set_xlim(-1.05, 1.05); ax.set_ylim(-1.05, 1.05)
    ax.set_xlabel("Valence: unpleasant  $\\rightarrow$  pleasant")
    ax.set_ylabel("Arousal: calm  $\\rightarrow$  activated")
    ax.scatter([.55, .55, -.55, -.55], [.55, -.55, .55, -.55],
               s=70, c=[COLORS["red"], COLORS["green"], COLORS["feature"], COLORS["aux"]],
               edgecolor="white", linewidth=.8, zorder=3)
    for x, y, txt in [( .55,.55,"excited joy"),(.55,-.55,"relaxed pleasure"),
                      (-.55,.55,"fear / anger"),(-.55,-.55,"sadness")]:
        ax.text(x, y + .12, txt, ha="center", fontsize=7.5)
    ax.set_xticks([]); ax.set_yticks([]); panel_label(ax, "(a) Dimensional emotion representation")

    ax = axes[1]; ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    panel_label(ax, "(b) Label systems used in this study")
    rounded(ax, (.04, .57), .39, .28, "DREAMER / FACED\n\nValence: high vs. low\nArousal: high vs. low",
            fc="#F2F8FB", ec=COLORS["eeg"], fontsize=8)
    rounded(ax, (.56, .57), .39, .28, "SEED series\n\nReleased discrete labels\n3 / 4 / 5 classes",
            fc="#FFF7EB", ec=COLORS["feature"], fontsize=8)
    rounded(ax, (.10, .18), .80, .18,
            "Seven formal tasks are reported separately;\nraw Macro-F1 is not pooled across different label spaces.",
            fc="#F5F6F7", ec=COLORS["muted"], fontsize=8)
    arrow(ax, (.24, .57), (.35, .36), COLORS["eeg"])
    arrow(ax, (.76, .57), (.65, .36), COLORS["feature"])
    save(fig, "label_tasks")


def trial_aggregation():
    fig, ax = plt.subplots(figsize=(10, 2.75))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    panel_label(ax, "EEG hierarchy and trial-level prediction")
    rounded(ax, (.025, .20), .17, .57, "", fc="#F4F9FC", ec=COLORS["eeg"])
    ax.text(.11, .70, "One stimulus trial", ha="center", weight="bold", fontsize=8)
    synthetic_eeg(ax, x0=.045, x1=.178, y0=.29, y1=.63, channels=4)
    rounded(ax, (.24, .20), .25, .57, "", fc="#FAFAFA", ec=COLORS["muted"])
    ax.text(.365, .70, "Non-overlapping windows", ha="center", weight="bold", fontsize=8)
    for i in range(5):
        ax.add_patch(Rectangle((.263 + i * .041, .34), .032, .22,
                               facecolor="#D9EAF2", edgecolor=COLORS["eeg"], lw=.8))
        ax.text(.279 + i * .041, .31, f"$X_{i+1}$", ha="center", fontsize=7)
    rounded(ax, (.54, .20), .20, .57, "", fc="#F4FAF9", ec=COLORS["fusion"])
    ax.text(.64, .70, "Window probabilities", ha="center", weight="bold", fontsize=8)
    probs = [[.73,.27],[.61,.39],[.54,.46],[.68,.32],[.59,.41]]
    for i,(p0,p1) in enumerate(probs):
        y=.58-i*.072
        ax.add_patch(Rectangle((.565,y-.0175),.145*p0,.035,facecolor=COLORS["eeg"],edgecolor="none"))
        ax.add_patch(Rectangle((.565+.145*p0,y-.0175),.145*p1,.035,facecolor=COLORS["feature"],edgecolor="none"))
    ax.text(.64, .255, "$p(y\\mid X_t)$", ha="center", fontsize=8)
    rounded(ax, (.79, .20), .18, .57, "Mean probabilities\n\n$\\bar p_k=T^{-1}\\sum_t p_{t,k}$\n\n$\\hat y=\\arg\\max_k \\bar p_k$",
            fc="#FFF8ED", ec=COLORS["feature"], fontsize=8)
    arrow(ax, (.195, .485), (.24, .485)); arrow(ax, (.49, .485), (.54, .485)); arrow(ax, (.74, .485), (.79, .485))
    ax.text(.50, .07, "Windows are training instances; the complete trial is the principal evaluation unit.",
            ha="center", fontsize=8, color=COLORS["muted"])
    save(fig, "trial_aggregation")


def feature_screening():
    fig, ax = plt.subplots(figsize=(10.2, 3.7))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    panel_label(ax, "Feature screening and the common formal comparison")
    rounded(ax, (.025, .18), .205, .68,
            "Broad candidate library\n\nTime statistics, Hjorth\nPSD / relative power\nBand ratios / spectral shape\nSTFT / PLPCC\nDWT / TQWT / DTCWT / HHT",
            fc="#F5F6F7", ec=COLORS["muted"], fontsize=7.5)
    rounded(ax, (.28, .18), .165, .68,
            "Early exploration\n\nAvailability\nNumerical stability\nInterpretability\nDimensionality\nObserved validation behavior",
            fc="#FFF9F1", ec=COLORS["feature"], fontsize=7.5)
    rounded(ax, (.495, .18), .285, .68, "", fc="#F6FAF4", ec=COLORS["green"])
    ax.text(.637, .80, "Common five-dataset candidates", ha="center", weight="bold", fontsize=8.3)
    rounded(ax, (.515, .54), .075, .16, "Hjorth\n$3C$\nTime", fc="white", ec=COLORS["eeg"], fontsize=7.2)
    rounded(ax, (.600, .54), .075, .16, "Band ratios\n$3C$\nFrequency", fc="white", ec=COLORS["feature"], fontsize=7.2)
    rounded(ax, (.685, .54), .075, .16, "DTCWT\n$10C$\nTime-scale", fc="white", ec=COLORS["aux"], fontsize=7.2)
    rounded(ax, (.535, .29), .205, .13, "Single, paired, and three-group combinations",
            fc="white", ec=COLORS["green"], fontsize=7.2)
    for x in [.552,.637,.722]: arrow(ax, (x,.54), (.637,.42), COLORS["green"], lw=.75)
    rounded(ax, (.83, .18), .145, .68,
            "Representative setting\nfor deeper analyses\n\nDTCWT energy\n\nEarly stopping\nAuxiliary weight\nBackbone\nWindow length\nPerturbation and cost",
            fc="#F8F6FB", ec=COLORS["aux"], fontsize=7.5)
    arrow(ax, (.23, .52), (.28, .52)); arrow(ax, (.445, .52), (.495, .52)); arrow(ax, (.78, .52), (.83, .52))
    ax.text(.50, .06,
            "The broad library was not a rectangular five-dataset experiment; DTCWT is a representative high-performing configuration, not a universal optimum.",
            ha="center", fontsize=7.5, color=COLORS["muted"])
    save(fig, "feature_screening")


def participation_modes():
    fig, axes = plt.subplots(2, 2, figsize=(9.8, 5.0))
    titles = ["(a) EEG only", "(b) Feature only", "(c) Direct fusion", "(d) Auxiliary supervision"]
    for ax, title in zip(axes.flat, titles):
        ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis("off"); panel_label(ax,title)
    ax=axes[0,0]
    rounded(ax,(.05,.38),.20,.20,"EEG window\n$X$",fc="#E5F1F7",ec=COLORS["eeg"])
    rounded(ax,(.37,.38),.25,.20,"1-D backbone\n$g_\\theta(X)$",fc="white",ec=COLORS["eeg"])
    rounded(ax,(.75,.38),.18,.20,"Classifier",fc="white",ec=COLORS["fusion"])
    arrow(ax,(.25,.48),(.37,.48),COLORS["eeg"]); arrow(ax,(.62,.48),(.75,.48),COLORS["fusion"])
    ax=axes[0,1]
    rounded(ax,(.05,.38),.20,.20,"Feature vector\n$h(X)$",fc="#FFF0DA",ec=COLORS["feature"])
    rounded(ax,(.37,.38),.25,.20,"Feature MLP\n$Ph(X)$",fc="white",ec=COLORS["feature"])
    rounded(ax,(.75,.38),.18,.20,"Classifier",fc="white",ec=COLORS["fusion"])
    arrow(ax,(.25,.48),(.37,.48),COLORS["feature"]); arrow(ax,(.62,.48),(.75,.48),COLORS["fusion"])
    ax=axes[1,0]
    rounded(ax,(.03,.58),.18,.17,"EEG\n$X$",fc="#E5F1F7",ec=COLORS["eeg"])
    rounded(ax,(.03,.20),.18,.17,"Features\n$h(X)$",fc="#FFF0DA",ec=COLORS["feature"])
    rounded(ax,(.31,.58),.21,.17,"Backbone",fc="white",ec=COLORS["eeg"])
    rounded(ax,(.31,.20),.21,.17,"Projection",fc="white",ec=COLORS["feature"])
    rounded(ax,(.61,.39),.13,.17,"Concat.",fc="#E1F2EF",ec=COLORS["fusion"])
    rounded(ax,(.81,.39),.15,.17,"Classifier",fc="white",ec=COLORS["fusion"])
    arrow(ax,(.21,.665),(.31,.665),COLORS["eeg"]); arrow(ax,(.21,.285),(.31,.285),COLORS["feature"])
    arrow(ax,(.52,.665),(.61,.50),COLORS["eeg"]); arrow(ax,(.52,.285),(.61,.45),COLORS["feature"]); arrow(ax,(.74,.475),(.81,.475),COLORS["fusion"])
    ax=axes[1,1]
    rounded(ax,(.04,.44),.18,.17,"EEG\n$X$",fc="#E5F1F7",ec=COLORS["eeg"])
    rounded(ax,(.31,.44),.22,.17,"Shared\nbackbone",fc="white",ec=COLORS["eeg"],fontsize=7.6)
    rounded(ax,(.72,.61),.22,.16,"Emotion head\n$\\mathcal{L}_{cls}$",fc="white",ec=COLORS["fusion"])
    rounded(ax,(.72,.21),.22,.16,"Feature head\n$\\lambda\\mathcal{L}_{feat}$",fc="#F0EAF5",ec=COLORS["aux"])
    arrow(ax,(.22,.525),(.31,.525),COLORS["eeg"]); arrow(ax,(.53,.525),(.72,.69),COLORS["fusion"]); arrow(ax,(.53,.525),(.72,.29),COLORS["aux"],style="-|>")
    ax.plot([.63,.95],[.12,.12],ls="--",lw=1,color=COLORS["aux"])
    ax.text(.79,.07,"dashed branch removed at inference",ha="center",fontsize=6.8,color=COLORS["muted"])
    fig.subplots_adjust(wspace=.12,hspace=.08)
    save(fig,"participation_modes")


def split_protocols():
    fig, axes = plt.subplots(1,2,figsize=(9.7,3.2))
    for ax in axes:
        ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis("off")
    panel_label(axes[0],"(a) Within-subject trial split")
    panel_label(axes[1],"(b) Subject-independent split")
    colors=["#8EC1D6","#F0B968","#A9CF8A"]
    labels=["train","validation","test"]
    for s in range(4):
        y=.72-s*.16
        axes[0].text(.05,y+.04,f"Subject {s+1}",ha="left",va="center",fontsize=7.5)
        x=.23
        widths=[.38,.13,.18]
        for w,c,l in zip(widths,colors,labels):
            axes[0].add_patch(Rectangle((x,y),w,.08,facecolor=c,edgecolor="white"))
            x+=w+.012
    axes[0].text(.5,.09,"Complete trials stay intact; the same participant\ncontributes different trials to all partitions.",ha="center",fontsize=7.5,color=COLORS["muted"])
    for s in range(6):
        x=.08+(s%3)*.30; y=.58-(s//3)*.28
        c=colors[0] if s<3 else (colors[1] if s==3 else colors[2])
        axes[1].add_patch(FancyBboxPatch((x,y),.16,.16,boxstyle="round,pad=.01,rounding_size=.03",facecolor=c,edgecolor="white"))
        axes[1].text(x+.08,y+.08,f"S{s+1}",ha="center",va="center",weight="bold",fontsize=8)
    axes[1].text(.5,.09,"Every test participant is absent from model fitting\nand feature normalization.",ha="center",fontsize=7.5,color=COLORS["muted"])
    handles=[Rectangle((0,0),1,1,fc=c) for c in colors]
    fig.legend(handles,labels,loc="lower center",ncol=3,frameon=False,bbox_to_anchor=(.5,-.01))
    save(fig,"split_protocols")


TASKS = ["D-A","D-V","F-A","F-V","SEED","SEED-IV","SEED-V"]


def main_scores():
    rows = read_csv("fine_grained_seed_means.csv")
    methods = METHOD_ORDER
    cols=[COLORS["eeg"],COLORS["feature"],COLORS["fusion"],COLORS["aux"]]
    fig,axes=plt.subplots(1,2,figsize=(7.2,3.25),sharey=True)
    for ax,protocol,title in zip(
        axes,
        ["subject_dependent", "subject_independent"],
        ["(a) Within-subject", "(b) Subject-independent"],
    ):
        data = {method: [] for method in methods}
        for task in TASKS:
            for method in methods:
                values = [
                    100 * float(row["trial_macro_f1"])
                    for row in rows
                    if row["protocol"] == protocol
                    and row["method"] == method
                    and task_code(row["dataset"], row["target"]) == task
                ]
                if len(values) != 5:
                    raise RuntimeError(f"Expected five seed means for {protocol}/{task}/{method}")
                data[method].append(float(np.mean(values)))
        x=np.arange(len(methods))
        for task_i,task in enumerate(TASKS):
            vals=[data[m][task_i] for m in methods]
            ax.plot(x,vals,color="#C9D2D7",lw=.65,alpha=.70,zorder=1)
            for xi,v,c in zip(x,vals,cols):
                ax.scatter(xi,v,s=22,facecolor="white",edgecolor=c,lw=1,zorder=2)
        med=[np.median(data[m]) for m in methods]
        q1=[np.percentile(data[m],25) for m in methods]; q3=[np.percentile(data[m],75) for m in methods]
        ax.errorbar(x,med,yerr=[np.array(med)-q1,np.array(q3)-np.array(med)],fmt="_",ms=13,
                    color=COLORS["dark"],elinewidth=1.4,capsize=4,zorder=4)
        ax.set_xticks(x,["EEG only", "Feature only", "Direct fusion", "Auxiliary"],rotation=18,ha="right")
        ax.set_title(title,loc="left",weight="bold")
        ax.grid(axis="y",color="#E6ECEF",lw=.7)
        ax.set_ylim(20,85)
    axes[0].set_ylabel("Trial Macro-F1 / %")
    fig.subplots_adjust(bottom=.25,wspace=.12,left=.09,right=.98,top=.92)
    save(fig,"main_scores",audit_axes=axes)


METHOD_ORDER = ["EEG only", "Feature only", "Direct fusion", "Auxiliary"]
METHOD_COLORS = [COLORS["eeg"], COLORS["feature"], COLORS["fusion"], COLORS["aux"]]


def read_csv(name):
    with (DATA / name).open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def task_code(dataset, target):
    dataset = dataset.replace("_", "-")
    if dataset == "DREAMER":
        return "D-A" if target == "arousal" else "D-V"
    if dataset == "FACED":
        return "F-A" if target == "arousal" else "F-V"
    return dataset


def seed_level_profiles(protocol, name, title):
    rows = read_csv("fine_grained_seed_means.csv")
    selected = [r for r in rows if r["protocol"] == protocol]
    lookup = {}
    for r in selected:
        key = (task_code(r["dataset"], r["target"]), int(r["seed"]), r["method"])
        lookup[key] = 100 * float(r["trial_macro_f1"])

    fig, axes = plt.subplots(2, 4, figsize=(11.2, 5.4), sharex=True, sharey=True)
    for task, ax in zip(TASKS, axes.flat[:7]):
        seeds = sorted({key[1] for key in lookup if key[0] == task})
        x = np.arange(len(METHOD_ORDER))
        for seed in seeds:
            values = [lookup[(task, seed, method)] for method in METHOD_ORDER]
            ax.plot(x, values, color="#CFD8DC", lw=.65, alpha=.78, zorder=1)
            for xi, value, color in zip(x, values, METHOD_COLORS):
                ax.scatter(xi, value, s=19, facecolor="white", edgecolor=color,
                           linewidth=.85, zorder=2)
        medians, q1, q3 = [], [], []
        for method in METHOD_ORDER:
            values = np.array([lookup[(task, seed, method)] for seed in seeds])
            medians.append(np.median(values))
            q1.append(np.percentile(values, 25))
            q3.append(np.percentile(values, 75))
        ax.errorbar(x, medians,
                    yerr=[np.array(medians) - q1, np.array(q3) - np.array(medians)],
                    fmt="_", ms=12, color=COLORS["dark"], elinewidth=1.25,
                    capsize=3, zorder=4)
        ax.set_title(task, weight="bold", loc="left")
        ax.grid(axis="y", color="#E6ECEF", lw=.65)
        ax.set_xticks(x, ["EEG", "Feature", "Fusion", "Aux."], rotation=18, ha="right")
    axes.flat[7].axis("off")
    note_ax = axes.flat[7]
    note_ax.text(.05, .78, "Fine-grained display", transform=note_ax.transAxes,
                      weight="bold", fontsize=9.5)
    note_ax.text(.05, .62,
                      "Each pale line connects the\nsame random seed after averaging\nits five outer folds.",
                      transform=note_ax.transAxes, fontsize=8,
                      color=COLORS["muted"], va="top")
    note_ax.text(.05, .29,
                      "Black marks: median and IQR\nacross five seed means.",
                      transform=note_ax.transAxes, fontsize=8,
                      color=COLORS["dark"], va="top")
    axes[0, 0].set_ylabel("Trial Macro-F1 / %")
    axes[1, 0].set_ylabel("Trial Macro-F1 / %")
    ymin = 30 if protocol == "subject_dependent" else 18
    ymax = 86 if protocol == "subject_dependent" else 72
    axes[0, 0].set_ylim(ymin, ymax)
    fig.suptitle(title, x=.065, ha="left", fontsize=9.0, weight="bold")
    fig.subplots_adjust(top=.90, bottom=.13, left=.065, right=.98, wspace=.14, hspace=.27)
    save(fig, name, audit_axes=list(axes.flat[:7]))


def paired_fusion_deltas():
    rows = read_csv("fine_grained_fusion_deltas.csv")
    summary = read_csv("fine_grained_fusion_delta_summary.csv")
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 3.9), sharey=True)
    protocols = [("subject_dependent", "(a) Within-subject"),
                 ("subject_independent", "(b) Subject-independent")]
    rng = np.random.default_rng(31)
    for ax, (protocol, title) in zip(axes, protocols):
        ax.axhline(0, color=COLORS["muted"], ls="--", lw=.9, zorder=0)
        for i, task in enumerate(TASKS):
            values = [float(r["fusion_minus_eeg_pp"]) for r in rows
                      if r["protocol"] == protocol and task_code(r["dataset"], r["target"]) == task]
            jitter = rng.uniform(-.09, .09, len(values))
            ax.scatter(i + jitter, values, s=24, facecolor="white",
                       edgecolor=COLORS["fusion"], lw=.9, alpha=.95, zorder=2)
            s = next(r for r in summary
                     if r["protocol"] == protocol and task_code(r["dataset"], r["target"]) == task)
            mean = float(s["mean_delta_pp"])
            lo = float(s["ci95_low_pp"])
            hi = float(s["ci95_high_pp"])
            ax.errorbar(i, mean, yerr=[[mean-lo], [hi-mean]], fmt="_", ms=12,
                        color=COLORS["dark"], elinewidth=1.35, capsize=3, zorder=4)
        ax.set_xticks(np.arange(len(TASKS)), TASKS, rotation=28, ha="right")
        ax.set_title(title, loc="left", weight="bold")
        ax.grid(axis="y", color="#E6ECEF", lw=.65)
        ax.set_xlabel("Task")
    axes[0].set_ylabel("Direct fusion - EEG only / percentage points")
    axes[0].set_ylim(-8, 15)
    fig.subplots_adjust(bottom=.25, wspace=.12)
    save(fig, "paired_fusion_deltas", audit_axes=axes)


def fusion_forest():
    rows = read_csv("fine_grained_fusion_delta_summary.csv")
    def values(protocol):
        return [
            tuple(
                float(next(r for r in rows
                           if r["protocol"] == protocol
                           and task_code(r["dataset"], r["target"]) == task)[key])
                for key in ("mean_delta_pp", "ci95_low_pp", "ci95_high_pp")
            )
            for task in TASKS
        ]
    within=values("subject_dependent")
    cross=values("subject_independent")
    fig,axes=plt.subplots(1,2,figsize=(10.0,4.0),sharey=True)
    y=np.arange(len(TASKS))[::-1]
    for ax,data,title,col in zip(axes,[within,cross],["(a) Within-subject","(b) Subject-independent"],[COLORS["fusion"],COLORS["aux"]]):
        m=np.array([d[0] for d in data]); lo=np.array([d[1] for d in data]); hi=np.array([d[2] for d in data])
        ax.axvline(0,color=COLORS["muted"],ls="--",lw=.9)
        ax.errorbar(m,y,xerr=[m-lo,hi-m],fmt="o",mfc="white",mec=col,ecolor=col,capsize=3,lw=1.2)
        ax.set_title(title,loc="left",weight="bold"); ax.grid(axis="x",color="#E6ECEF",lw=.7)
        ax.set_xlabel("Direct fusion - EEG only / percentage points")
    axes[0].set_yticks(y,TASKS)
    fig.subplots_adjust(wspace=.12)
    save(fig,"fusion_forest",audit_axes=axes)


def protocol_heatmap():
    rows = read_csv("fine_grained_fusion_delta_summary.csv")
    vals=np.array([
        [
            float(next(r for r in rows
                       if r["protocol"] == protocol
                       and task_code(r["dataset"], r["target"]) == task)["mean_delta_pp"])
            for protocol in ("subject_dependent", "subject_independent")
        ]
        for task in TASKS
    ])
    fig,ax=plt.subplots(figsize=(3.45,3.35))
    im=ax.imshow(vals,cmap="RdBu_r",vmin=-11,vmax=11,aspect="auto")
    ax.set_xticks([0,1],["Within-subject","Subject-independent"],rotation=12,ha="right")
    ax.set_yticks(np.arange(len(TASKS)),TASKS)
    for i in range(vals.shape[0]):
        for j in range(vals.shape[1]):
            ax.text(j,i,f"{vals[i,j]:+.2f}",ha="center",va="center",fontsize=8,
                    color="white" if abs(vals[i,j])>6 else COLORS["dark"])
    cbar=fig.colorbar(im,ax=ax,shrink=.78); cbar.set_label("Fusion - EEG / percentage points")
    ax.set_title("Direct-fusion gain by protocol",loc="left",weight="bold")
    save(fig,"protocol_heatmap")


def robustness_collapse():
    rows = read_csv("robustness_summary.csv")
    datasets=["SEED","SEED-IV","SEED-V"]
    def series(field, condition):
        return [float(next(r for r in rows if r["dataset"] == dataset and r["condition"] == condition)[field])
                for dataset in datasets]
    clean=series("trial_macro_f1_pct", "clean")
    noise=series("trial_macro_f1_pct", "snr10")
    drop=series("trial_macro_f1_pct", "drop25")
    dom_noise=series("dominant_predicted_class_pct", "snr10")
    dom_drop=series("dominant_predicted_class_pct", "drop25")
    fig,axes=plt.subplots(1,2,figsize=(7.2,3.15))
    x=np.arange(3); w=.24
    axes[0].bar(x-w,clean,w,label="Clean",color=COLORS["fusion"])
    axes[0].bar(x,noise,w,label="10-dB noise",color=COLORS["feature"])
    axes[0].bar(x+w,drop,w,label="25% channel dropout",color=COLORS["red"])
    axes[0].set_xticks(x,datasets); axes[0].set_ylabel("Trial Macro-F1 / %"); axes[0].set_ylim(0,86)
    axes[0].grid(axis="y",color="#E6ECEF",lw=.7)
    axes[0].legend(frameon=False,ncol=1,loc="upper right")
    axes[0].set_title("(a) Trial-level performance",loc="left",weight="bold")
    axes[1].bar(x-w/2,dom_noise,w,label="10-dB noise",color=COLORS["feature"])
    axes[1].bar(x+w/2,dom_drop,w,label="25% channel dropout",color=COLORS["red"])
    axes[1].plot(x,[100/3,25,20],marker="o",ms=4,ls="--",lw=.9,color=COLORS["muted"])
    axes[1].set_xticks(x,datasets); axes[1].set_ylabel("Dominant predicted class / %"); axes[1].set_ylim(0,105)
    axes[1].grid(axis="y",color="#E6ECEF",lw=.7)
    axes[1].text(.98,.97,"Dashed line: uniform-class reference",transform=axes[1].transAxes,
                 ha="right",va="top",fontsize=6.6,color=COLORS["muted"])
    axes[1].set_title("(b) Dominant predicted class",loc="left",weight="bold")
    fig.subplots_adjust(bottom=.16,wspace=.25,left=.09,right=.99,top=.91)
    save(fig,"robustness_collapse",audit_axes=axes)


def cost_tradeoff():
    rows = read_csv("deployment_cost.csv")
    fig,ax=plt.subplots(figsize=(3.45,3.15))
    markers={"SEED":"o", "DREAMER":"s", "FACED":"D"}
    for row in rows:
        dataset=row["dataset"]
        method=row["method"]
        p=float(row["parameters"])/1000
        t=float(row["processing_time_ms"])
        c=COLORS["eeg"] if method == "EEG only" else COLORS["fusion"]
        m=markers[dataset]
        ax.scatter(p,t,s=55,c=c,marker=m,edgecolor="white",lw=.7,zorder=3)
    handles=[
        Line2D([],[],marker="o",ls="",markerfacecolor=COLORS["eeg"],markeredgecolor="white",label="EEG only"),
        Line2D([],[],marker="o",ls="",markerfacecolor=COLORS["fusion"],markeredgecolor="white",label="Direct fusion"),
        Line2D([],[],marker="s",ls="",color=COLORS["dark"],label="DREAMER"),
        Line2D([],[],marker="D",ls="",color=COLORS["dark"],label="FACED"),
        Line2D([],[],marker="o",ls="",color=COLORS["dark"],label="SEED"),
    ]
    ax.legend(handles=handles,loc="upper left",frameon=False,ncol=2,columnspacing=.9,handletextpad=.4)
    ax.set_xlabel("Deployment parameters / thousand")
    ax.set_ylabel("Measured processing time / ms per window")
    ax.set_xlim(8,83)
    ax.set_ylim(.2,3.82)
    ax.grid(color="#E6ECEF",lw=.7)
    ax.set_title("Measured deployment cost",loc="left",weight="bold")
    save(fig,"cost_tradeoff")


if __name__ == "__main__":
    study_overview()
    label_tasks()
    trial_aggregation()
    feature_screening()
    participation_modes()
    split_protocols()
    main_scores()
    seed_level_profiles("subject_dependent", "seed_level_within",
                        "Seed-level participation profiles: within-subject protocol")
    seed_level_profiles("subject_independent", "seed_level_cross",
                        "Seed-level participation profiles: subject-independent protocol")
    paired_fusion_deltas()
    protocol_heatmap()
    robustness_collapse()
    cost_tradeoff()
    print(f"Wrote PDF/SVG vector figures and PNG previews to {OUT}")
