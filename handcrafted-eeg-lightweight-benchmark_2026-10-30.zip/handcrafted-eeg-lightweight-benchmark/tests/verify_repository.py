"""Static repository checks that do not require datasets or a GPU."""
import json
import py_compile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    'README.md', 'requirements.txt', 'configs/paper_protocol.json',
    'pipelines/dimensional/run_experiment.py', 'pipelines/dimensional/suite.py',
    'pipelines/seed_series/cloud.py', 'pipelines/seed_series/suite.py',
    'preprocessing/preprocess_dreamer.py', 'preprocessing/prepare_windows.py',
    'analysis/make_figures.py', 'analysis/data/fine_grained_runs.csv',
]

missing = [name for name in REQUIRED if not (ROOT / name).exists()]
if missing:
    raise SystemExit('Missing required files: ' + ', '.join(missing))

protocol = json.loads((ROOT / 'configs/paper_protocol.json').read_text(encoding='utf-8'))
assert protocol['folds'] == 5
assert len(protocol['dimensional']['training_seeds']) == 5
assert len(protocol['discrete']['training_seeds']) == 5

for path in ROOT.rglob('*.py'):
    if '__pycache__' not in path.parts:
        py_compile.compile(str(path), doraise=True)

for dataset in ('DREAMER', 'FACED', 'SEED', 'SEED_IV', 'SEED_V'):
    assert (ROOT / 'data' / dataset).is_dir()

print('Repository verification passed: files, protocol, and Python syntax are valid.')
